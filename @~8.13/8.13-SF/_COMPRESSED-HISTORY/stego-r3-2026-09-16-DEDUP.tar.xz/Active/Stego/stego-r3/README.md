# stego-r3 — deduplicated archive note (2026-09-17)

`stego-r3/output/` was byte-identical to the live `Active/Stego/stego-r4/output/`
(verified 2026-09-17: all 7 members matched, incl. runner f36e792f and cover a206aaa3),
so it was dropped from this archive to save ~4.4 MB.

Restore the unique half (old lite 1024 build 53732f/9e165c):
    tar -xJf _COMPRESSED-HISTORY/stego-r3-2026-09-16-DEDUP.tar.xz -C /home/user
For the `output/` half, use the live `Active/Stego/stego-r4/output/` — same bytes.
