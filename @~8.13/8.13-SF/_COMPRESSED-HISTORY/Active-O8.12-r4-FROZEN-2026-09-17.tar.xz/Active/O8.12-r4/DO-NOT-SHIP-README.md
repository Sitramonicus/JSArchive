# ⛔ DO NOT SHIP — FROZEN PREVIOUS LINE

This directory is **O8.12-r4**, the line that O8.13 was cut from. It is frozen, not live.

| | |
|---|---|
| bundle | `1e03f483c12f1132…` — 1,660,881 B |
| runner | `f36e792fd0447560…` — 3,362,896 B (in `_ARCHIVE_TRIM/superseded-carriers-2026-09-17.tar.gz`) |
| cover | `a206aaa39297d1ec…` — 2,359,350 B (same tarball) |

## Why it is not the deliverable

1. **O8.13 supersedes it.** Go live from `Working-Stable/O8.13/` — see `/home/user/GO-LIVE.md`.
   The live bundle is `ef1dac5e02a6…`, 1,873,322 B. This one is 1,660,881 B. They are not
   interchangeable and the sizes are close enough to misread at a glance.
2. **Its carrier is garden-broken.** The r4 carrier had a `DSEED` desync that broke the garden
   tier (`Handoff/CHANGELOG.md`, 2026-09-17 (d)). The bundle here is sound; the carrier that
   shipped with it is not.
3. **It is the rollback point.** If O8.13 misbehaves in Discord, this is what you roll back to —
   which is exactly why it stays on disk, frozen and untouched.

## Do not "clean up" this directory

Two quirks of the frozen r4 manifest, both pre-existing, neither is corruption:

- It has a **trailing size column** (`…6cc  O8.6-Final-final-bundle.js  1660881B`), so plain
  `sha256sum -c SHA256SUMS.txt` fails to parse it. Strip the column first:

```bash
cd Active/O8.12-r4/final-package && awk '{print $1, $2}' SHA256SUMS.txt | sha256sum -c -
```

- That then reports the **three bundle files OK** and the **four carrier paths FAILED open or
  read** — because `../Stego/stego-r4/output/` and `output-1024/` were retired to
  `_ARCHIVE_TRIM/superseded-carriers-2026-09-17.tar.gz` on 2026-09-17. The bundle half of this
  frozen line is intact and verifiable; the carrier half now lives only in that tarball.

Do not rename the files here and do not rewrite that sums file — the whole point of a frozen line
is that its bytes and their manifest stop changing.

