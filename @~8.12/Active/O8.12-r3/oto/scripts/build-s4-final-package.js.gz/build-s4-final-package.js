const fs = require("fs");
const path = require("path");
const zlib = require("zlib");
const REPO = path.resolve(__dirname, "..", "..", "..", "..");
const O86 = path.join(REPO, "Active", "O8.12-r3") // r3 O both;
const ENG = path.join(REPO, "Active", "engines", "node_modules");
// Engines live in Active/engines (npm install there); fall back to NODE_PATH/global.
function needEngine(name) {
  try { return require(path.join(ENG, name)); } catch (e) { /* fall through */ }
  try { return require(name); } catch (e) { /* fall through */ }
  throw new Error(`Missing engine "${name}" — run: cd ${path.join(REPO, "Active", "engines")} && npm install`);
}
const JS = needEngine("javascript-obfuscator");
const { derive: SEED } = require("./seed-lib.js"); // O8.9 G1
const { execFileSync } = require("child_process");

console.log("=== Building O8.12-r2-Final / S6 Deliverables (12 shards, 6 uniform) ===");

const OTO_ROOT = path.join(O86, "oto");
const PKG_DIR = path.join(O86, "final-package");
const SHARDS_DIR = path.join(PKG_DIR, "selected-shards");
fs.mkdirSync(SHARDS_DIR, { recursive: true });

// 1. Copy selected shards
const selection = [
  { tag: "a", file: path.join(OTO_ROOT, "v1-jso-s3matrix/shard-a-out.js"), out: "shard-a-v1.js" },
  { tag: "m", file: path.join(OTO_ROOT, "v2-jsc/shard-m-out.js"), out: "shard-m-v2.js" },
  { tag: "u", file: path.join(OTO_ROOT, "u/shard-u-out.js"), out: "shard-u-v4.js" },
  { tag: "n1", file: path.join(OTO_ROOT, "v6-esbuild/shard-n1-out.js"), out: "shard-n1-v6.js" },
  { tag: "e", file: path.join(OTO_ROOT, "v1-jso-s3matrix/shard-e-out.js"), out: "shard-e-v1.js" },
  { tag: "n2", file: path.join(OTO_ROOT, "v7-swc/shard-n2-out.js"), out: "shard-n2-v7.js" },
  { tag: "aux", file: path.join(OTO_ROOT, "v5-terser/shard-aux-out.js"), out: "shard-aux-v5.js" },
  { tag: "p-telegram", file: path.join(OTO_ROOT, "v4-closure/shard-p-telegram-out.js"), out: "shard-p-telegram-v4.js" },
  { tag: "p-teams", file: path.join(OTO_ROOT, "v6-esbuild/shard-p-teams-out.js"), out: "shard-p-teams-v6.js" },
  { tag: "p-zoom", file: path.join(OTO_ROOT, "v2-jsc/shard-p-zoom-out.js"), out: "shard-p-zoom-v2.js" },
  { tag: "p-slack", file: path.join(OTO_ROOT, "v8-uglify/shard-p-slack-out.js"), out: "shard-p-slack-v8.js" },
  { tag: "p-discord", file: path.join(OTO_ROOT, "v6-esbuild/shard-p-discord-out.js"), out: "shard-p-discord-v6.js" },
];

// 1b. Frozen v2 pin (Stego-3 G4): js-confuser is unseedable, so the consumed v2
// piece is PINNED, not rebuilt (obf-v2-jsc.js runs manually only). Refresh flow:
// run obf-v2-jsc.js, re-green battery, update EXPECTED_V2_M below.
const EXPECTED_V2_M = "c90fc83046c2bd2fb726c56a0c657f6d0e7152b9e736335d1b383880e6cf4192"; // r3 rebuilt with R2 shards
{
  const _v2m = fs.readFileSync(path.join(OTO_ROOT, "v2-jsc/shard-m-out.js"));
  const _h = require("crypto").createHash("sha256").update(_v2m).digest("hex");
  if (_h !== EXPECTED_V2_M) throw new Error(`v2 frozen pin mismatch: ${_h} != ${EXPECTED_V2_M} (refresh deliberately, see above)`);
}

for (const s of selection) {
  const content = fs.readFileSync(s.file, "utf8");
  fs.writeFileSync(path.join(SHARDS_DIR, s.out), content);
  console.log(`[Copied] ${s.out} (${(content.length / 1024).toFixed(1)} KB)`);
}

// 2. Stitch shards
const stitchedRawPath = "/tmp/stitched-raw.js";
const shardPaths = selection.map(s => path.join(SHARDS_DIR, s.out));
execFileSync("python3", [path.join(O86, "tools", "stitch-o85.py"), ...shardPaths, stitchedRawPath]);
const rawStitched = fs.readFileSync(stitchedRawPath, "utf8");
console.log(`[Stitched] Raw bundle size: ${(rawStitched.length / 1024).toFixed(1)} KB`);

// 3. Obfuscate master bundle with 5k Dictionary 2
const DICT_ALL = fs.readFileSync(path.join(OTO_ROOT, "identifiers-dictionary-5k.csv"), "utf8").split(",").map(s=>s.trim()).filter(Boolean);
const DICT_SPLIT = [DICT_ALL.slice(0,780), DICT_ALL.slice(780,1560), DICT_ALL.slice(1560,2340)]; // r3 O: 3x780 split (both P trampoline + O split decoy)
const DICT_5K_BUNDLE = DICT_ALL; // keep compat, per-shard uses DICT_SPLIT[tag%3]

console.log(`[Obfuscating Bundle] Using 5k dictionary (${DICT_5K_BUNDLE.length} words)...`);
const t0 = Date.now();
const bundleObfResult = JS.obfuscate(rawStitched, {
  compact: true,
  simplify: true,
  selfDefending: false,
  debugProtection: false,
  disableConsoleOutput: false,
  renameGlobals: false,
  renameProperties: false,
  transformObjectKeys: true,
  identifierNamesGenerator: "dictionary",
  identifiersDictionary: DICT_5K_BUNDLE,
  identifiersPrefix: "google",
  seed: SEED("s4-bundle"),
  reservedNames: ["^会員$", "^名$", "^lexMode$", "^lexProbeA$", "^lexProbeU$", "^lexProbeX$", "^lexSetPins$"], // O8.9 G8
  reservedStrings: ["佐藤 結衣", "kcolbUelgooG"],
  stringArray: false,
  controlFlowFlattening: false, // r3 P avenue: trampoline instead of split("|"),
  controlFlowFlatteningThreshold: 0.25,
  deadCodeInjection: false,
  numbersToExpressions: false
}).getObfuscatedCode();

// FIX: JSO compact mode omits space after `return` when next identifier starts with supplementary-plane unicode (e.g. gothic 𐌹 U+10339 surrogate pair)
// `return𐌹` is parsed as identifier `return𐌹`, not `return`+identifier -> SyntaxError. Old dict had no supplementary-plane starts, so it passed.
// Add space after `return` when next char is not whitespace/;/( — safe for all: `return"` -> `return "`, `return(` -> `return (` remain valid.
// FIX: JSO compact omits space after keywords when next identifier starts with supplementary-plane unicode (e.g. gothic 𐌹 U+10339)
// Affects `return`, `typeof`, `throw`, `delete`, `void`, `instanceof`, `in`, `of`, `new`, `case`, `yield`, `await`, `import`, `export`, `extends`, `super`, `function`, `class`, `const`, `let`, `var`, `if`, `while`, `for`, `switch`, `catch`, `with`, `debugger`, `continue`, `break`
let _fixedBundle = bundleObfResult;
const _kw = ['return','typeof','throw','delete','void','instanceof','in','of','new','case','yield','await','import','export','extends','super','function','class','const','let','var','if','while','for','switch','catch','with','debugger','continue','break'];
for (const k of _kw) {
  const re = new RegExp('\\b' + k + '\\b(?=[^\\s;\\(\\[\\{])', 'g');
  _fixedBundle = _fixedBundle.replace(re, k + ' ');
}
_fixedBundle = _fixedBundle.replace(/\breturn(?=[^\s;\(])/g, 'return '); // legacy, kept for safety
// Also handle `typeof` specifically for surrogate pair start (high surrogate)
_fixedBundle = _fixedBundle.replace(/typeof(?=[\uD800-\uDBFF])/g, 'typeof ');
if (_fixedBundle !== bundleObfResult) {
  console.log(`[Fix] return<->space inserted: ${bundleObfResult.length} -> ${_fixedBundle.length}`);
  // sanity: ensure still valid JS
  try { require('vm').compileFunction(_fixedBundle, []); } catch(e) { console.warn('[Fix] bundle still invalid after return fix:', e.message.slice(0,120)); }
}
const finalBundlePath = path.join(PKG_DIR, "O8.6-Final-final-bundle.js");
fs.writeFileSync(finalBundlePath, _fixedBundle);
// Also write with correct r2 name
const altBundlePath = path.join(PKG_DIR, "O8.12-r2-Final-bundle.js");
fs.writeFileSync(altBundlePath, _fixedBundle);
console.log(`[Alt] Also wrote ${altBundlePath}`);

let bundleObfResultFixed = _fixedBundle;
console.log(`[Final Bundle] Written to ${finalBundlePath} (${(bundleObfResult.length / 1024).toFixed(1)} KB in ${((Date.now() - t0)/1000).toFixed(1)}s)`);
// 3b. O8.9 G8 pins: slice shipped probe texts (string-aware), hash, append setter.
// Pins cover the probes only (never themselves); lexSetPins triggers the real verify.
{
  const bundleSrc = fs.readFileSync(finalBundlePath, 'utf8');
  const fnv = (s) => { var h = 0x811c9dc5; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i) & 255; h = Math.imul(h, 0x01000193); } return (h >>> 0).toString(16); };
  const sliceFn = (name, constId) => {
    // JSO stringArray encodes the globalThis[..] property names, so anchor on the
    // probe's unique arithmetic const (numbersToExpressions is off in all passes),
    // then back up to the nearest preceding 'function' (probe bodies nest none).
    if (bundleSrc.split(constId).length - 1 !== 1) throw new Error('G8 probe const not unique: ' + name);
    const cpos = bundleSrc.indexOf(constId);
    const a = bundleSrc.lastIndexOf('function', cpos);
    if (a < 0) throw new Error('G8 probe missing: ' + name);
    let i = bundleSrc.indexOf('{', a), d = 0, q = null;
    for (; i < bundleSrc.length; i++) {
      const c = bundleSrc[i];
      if (q) { if (c === '\\') { i++; continue; } if (c === q) q = null; continue; }
      if (c === '"' || c === "'" || c === '`') { q = c; continue; }
      if (c === '{') d++; else if (c === '}') { d--; if (d === 0) return bundleSrc.slice(a, i + 1); }
    }
    throw new Error('G8 probe unterminated: ' + name);
  };
  const probes = [['lexProbeA', '0x51ab3c09'], ['lexProbeU', '0x6f2c9d4e'], ['lexProbeX', '0x1b3c51ab']];
  const pins = probes.map(([n, c]) => { const body = sliceFn(n, c); if (!body.includes(c)) throw new Error('G8 probe mangled beyond recognition: ' + n); return fnv(body); });
  if (new Set(pins).size !== 3) throw new Error('G8 pins degenerate');
  fs.writeFileSync(finalBundlePath, bundleSrc + ';lexSetPins(' + JSON.stringify(pins) + ');');
  console.log('[G8] pins appended:', pins.join(','));
}


// 4. Transport Compression
const gzipBuffer = zlib.gzipSync(Buffer.from(bundleObfResultFixed || bundleObfResult, "utf8"), { level: 9 });
const deflateRawBuffer = zlib.deflateRawSync(Buffer.from(bundleObfResultFixed || bundleObfResult, "utf8"), { level: 9 });
const gzipB64 = gzipBuffer.toString("base64");
const deflateRawB64 = deflateRawBuffer.toString("base64");

console.log(`[Compressed] Gzip: ${(gzipB64.length / 1024).toFixed(1)} KB base64 | DeflateRaw: ${(deflateRawB64.length / 1024).toFixed(1)} KB base64`);

// 5. Build Outer Runners with 5k Dictionary 3
const DICT_5K_RUNNER = fs.readFileSync(path.join(OTO_ROOT, "identifiers-dictionary-runner-5k.csv"), "utf8")
  .split(",").map(s => s.trim()).filter(Boolean);

function buildRunner(b64, format) {
  const innerLoader = `(async () => {
  const _b = "${b64}";
  const _u = Uint8Array.from(atob(_b), c => c.charCodeAt(0));
  const _d = new DecompressionStream("${format}");
  const _w = _d.writable.getWriter();
  _w.write(_u);
  _w.close();
  const _r = _d.readable.getReader();
  const _c = [];
  while (true) {
    const { done, value } = await _r.read();
    if (done) break;
    _c.push(value);
  }
  let _l = 0;
  for (const x of _c) _l += x.length;
  const _a = new Uint8Array(_l);
  let _p = 0;
  for (const x of _c) { _a.set(x, _p); _p += x.length; }
  let _s = new TextDecoder().decode(_a);
  if (typeof 会員 !== "undefined") {
    _s = _s.replace(/会員\\s*=\\s*(0x2|2|1|0)/, "会員=" + 会員);
  }
  if (typeof 名 !== "undefined" && 名 !== "佐藤 結衣") {
    _s = _s.replace("佐藤 結衣", 名);
  }
  (0, eval)(_s);
})();`;

  const obfLoader = JS.obfuscate(innerLoader, {
    compact: true,
    simplify: true,
    selfDefending: false,
    debugProtection: false,
    disableConsoleOutput: false,
    renameGlobals: false,
    renameProperties: false,
    transformObjectKeys: true,
    identifierNamesGenerator: "dictionary",
    identifiersDictionary: DICT_5K_RUNNER,
    identifiersPrefix: "google",
    seed: SEED("s4-runner"),
    reservedNames: ["^会員$", "^名$"],
    reservedStrings: ["佐藤 結衣", format],
    stringArray: false,
    controlFlowFlattening: false,
    deadCodeInjection: false,
    numbersToExpressions: false
  }).getObfuscatedCode();

  return `var 会員 = 2; var 名 = "佐藤 結衣"; console.clear(); ` + obfLoader;
}

const gzipRunner = buildRunner(gzipB64, "gzip");
const deflateRawRunner = buildRunner(deflateRawB64, "deflate-raw");

fs.writeFileSync(path.join(PKG_DIR, "O8.6-Final-compressed-gzip.js"), gzipRunner);
fs.writeFileSync(path.join(PKG_DIR, "O8.12-r2-Final-gzip.js"), gzipRunner);
fs.writeFileSync(path.join(PKG_DIR, "O8.6-Final-compressed-deflateraw.js"), deflateRawRunner);
fs.writeFileSync(path.join(PKG_DIR, "O8.12-r2-Final-deflateraw.js"), deflateRawRunner);

console.log(`[Deliverable] O8.6-Final-compressed-gzip.js: ${(gzipRunner.length / 1024).toFixed(1)} KB`);
console.log(`[Deliverable] O8.6-Final-compressed-deflateraw.js: ${(deflateRawRunner.length / 1024).toFixed(1)} KB`);

// 6. Update SHA256SUMS.txt
const crypto = require("crypto");
const files = [
  "O8.6-Final-compressed-gzip.js",
  "O8.6-Final-compressed-deflateraw.js",
  "O8.6-Final-final-bundle.js"
];
const sums = [];
for (const f of files) {
  const buf = fs.readFileSync(path.join(PKG_DIR, f));
  const hash = crypto.createHash("sha256").update(buf).digest("hex");
  sums.push(`${hash}  ${f}`);
  console.log(`SHA256 (${f}): ${hash}`);
}
fs.writeFileSync(path.join(PKG_DIR, "SHA256SUMS.txt"), sums.join("\n") + "\n");
console.log("=== Build Finished Successfully ===");
