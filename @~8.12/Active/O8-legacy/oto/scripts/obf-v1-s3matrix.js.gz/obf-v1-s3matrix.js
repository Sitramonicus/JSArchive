// obf-v1-s3matrix.js — VARIANT 1: javascript-obfuscator per-piece with user overrides:
// - identifiersPrefix: 'google' (all shards)
// - transformObjectKeys: true (all shards)
// - Increased stringArrayWrappersCount (a:5, m:8, n1:8, e:15, n2:8)
// - dictionary applied via npm identifiersDictionary array from identifiers-dictionary-jso.csv
//
// Input : Active/O8.6/shards/shard-{a,m,n1,e,n2,aux}.js
// Output: Active/O8.6/oto/v1-jso-s3matrix/shard-<tag>-out.js
'use strict';
const fs = require('fs');
const path = require('path');
const REPO = path.resolve(__dirname, '..', '..', '..', '..');
const O86 = path.join(REPO, 'Active', 'O8.6');
const ENG = path.join(REPO, 'Active', 'engines', 'node_modules');
function needEngine(name) {
  try { return require(path.join(ENG, name)); } catch (e) { /* fall through */ }
  try { return require(name); } catch (e) { /* fall through */ }
  throw new Error(`Missing engine "${name}" — run: cd ${path.join(REPO, 'Active', 'engines')} && npm install`);
}
const JS = needEngine('javascript-obfuscator');
const { derive: SEED, deriveInt: SEEDINT } = require('./seed-lib.js'); // O8.9 G1 + O8.11 S1

const SRC = path.join(O86, 'oto', 'g7-strings'); // O8.9 G7: consume pre-encoded shards
const OUT = path.join(O86, 'oto', 'v1-jso-s3matrix');
const DICT_RAW = fs.readFileSync(path.join(O86, 'oto', 'identifiers-dictionary-jso.csv'), 'utf8')
  .split(',').map(s => s.trim()).filter(Boolean);
// S1 JSO-seed rotation (O8.11): shuffle dictionary order via SEED('jso') — determinism is seed-keyed, kills static skeleton (L2 pipeline ports)
const DICT = (() => { const a = DICT_RAW.slice(); let s = SEEDINT('jso') >>> 0; const rnd = () => { s = (s + 0x6D2B79F5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; })();

const BASE = {
  compact: true,
  selfDefending: false,
  debugProtection: false,
  disableConsoleOutput: false,
  renameGlobals: false,
  renameProperties: false,
  reservedNames: ["^会員$", "^lexMode$", "^lexProbeA$", "^lexProbeU$", "^lexProbeX$", "^lexSetPins$"], // O8.9 G8
  transformObjectKeys: true,       // OVERRIDE: Enabled
  unicodeEscapeSequence: false,
  simplify: true,
  identifiersPrefix: 'google',     // OVERRIDE: 'google'
};

const PIECES = {
  a: {
    identifierNamesGenerator: 'mangled-shuffled',
    seed: SEED('v1-a'),
    stringArray: true, stringArrayThreshold: 0.55,
    rotateStringArray: true, shuffleStringArray: true,
    stringArrayEncoding: ['base64'], stringArrayIndexShift: true,
    stringArrayIndexesType: ['hexadecimal-number'],
    stringArrayCallsTransform: true,
    stringArrayWrappersType: 'variable', stringArrayWrappersCount: 5,  // INCREASED: 5 (was 3)
    stringArrayWrappersParametersCount: 2, stringArrayWrappersChainedCalls: true,
    controlFlowFlattening: false, deadCodeInjection: false,
    splitStrings: false, numbersToExpressions: false,
  },
  m: {
    identifierNamesGenerator: 'hexadecimal',
    seed: SEED('v1-m'),
    stringArray: true, stringArrayThreshold: 0.9,
    rotateStringArray: true, shuffleStringArray: false,
    stringArrayEncoding: ['base64'], stringArrayIndexShift: true,
    stringArrayIndexesType: ['hexadecimal-numeric-string'],
    stringArrayCallsTransform: true,
    stringArrayWrappersType: 'variable', stringArrayWrappersCount: 8,  // INCREASED: 8 (was 5)
    stringArrayWrappersParametersCount: 2, stringArrayWrappersChainedCalls: false,
    controlFlowFlattening: true, controlFlowFlatteningThreshold: 0.45,
    deadCodeInjection: false, splitStrings: false, numbersToExpressions: false,
  },
  n1: {
    identifierNamesGenerator: 'dictionary',
    identifiersDictionary: DICT, seed: SEED('v1-n1'),
    stringArray: true, stringArrayThreshold: 0.75,
    rotateStringArray: true, shuffleStringArray: true,
    stringArrayEncoding: ['rc4'], stringArrayIndexShift: true,
    stringArrayIndexesType: ['hexadecimal-number', 'hexadecimal-numeric-string'],
    stringArrayCallsTransform: true,
    stringArrayWrappersType: 'function', stringArrayWrappersCount: 8,  // INCREASED: 8 (was 5)
    stringArrayWrappersParametersCount: 3, stringArrayWrappersChainedCalls: true,
    controlFlowFlattening: true, controlFlowFlatteningThreshold: 0.6,
    deadCodeInjection: true, deadCodeInjectionThreshold: 0.08,
    splitStrings: true, splitStringsChunkLength: 6, numbersToExpressions: false,
  },
  e: {
    identifierNamesGenerator: 'dictionary',
    identifiersDictionary: DICT, seed: SEED('v1-e'),
    stringArray: true, stringArrayThreshold: 1.0,
    rotateStringArray: true, shuffleStringArray: true,
    stringArrayEncoding: ['rc4'], stringArrayIndexShift: true,
    stringArrayIndexesType: ['hexadecimal-number', 'hexadecimal-numeric-string'],
    stringArrayCallsTransform: true,
    stringArrayWrappersType: 'function', stringArrayWrappersCount: 15, // INCREASED: 15 (was 12)
    stringArrayWrappersParametersCount: 2, stringArrayWrappersChainedCalls: true,
    controlFlowFlattening: true, controlFlowFlatteningThreshold: 0.75,
    deadCodeInjection: true, deadCodeInjectionThreshold: 0.12,
    splitStrings: false, numbersToExpressions: false,
  },
  n2: {
    identifierNamesGenerator: 'dictionary',
    identifiersDictionary: DICT, seed: SEED('v1-n2'),
    stringArray: true, stringArrayThreshold: 0.85,
    rotateStringArray: true, shuffleStringArray: true,
    stringArrayEncoding: ['base64'], stringArrayIndexShift: true,
    stringArrayIndexesType: ['hexadecimal-number', 'hexadecimal-numeric-string'],
    stringArrayCallsTransform: true,
    stringArrayWrappersType: 'variable', stringArrayWrappersCount: 8,  // INCREASED: 8 (was 6)
    stringArrayWrappersParametersCount: 2, stringArrayWrappersChainedCalls: true,
    controlFlowFlattening: true, controlFlowFlatteningThreshold: 0.5,
    deadCodeInjection: false,
    splitStrings: true, splitStringsChunkLength: 8, numbersToExpressions: false,
  },
  aux: {
    identifierNamesGenerator: 'mangled',
    seed: SEED('v1-aux'),
    stringArray: false,
    controlFlowFlattening: false, deadCodeInjection: false,
    splitStrings: true, splitStringsChunkLength: 5, numbersToExpressions: true,
  },
};

fs.mkdirSync(OUT, { recursive: true });
for (const [tag, cfg] of Object.entries(PIECES)) {
  const src = fs.readFileSync(path.join(SRC, `shard-${tag}.js`), 'utf8');
  const opts = { ...BASE, ...cfg };
  const t0 = Date.now();
  const out = JS.obfuscate(src, opts).getObfuscatedCode();
  fs.writeFileSync(path.join(OUT, `shard-${tag}-out.js`), out);
  console.log(`shard-${tag}: ${(src.length / 1024).toFixed(1)}KB -> ${(out.length / 1024).toFixed(1)}KB  (${((Date.now() - t0) / 1000).toFixed(1)}s)  [${cfg.identifierNamesGenerator}]`);
}
console.log('v1 done ->', OUT);
