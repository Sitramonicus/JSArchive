# pinned — the S1 measurement reference (chain A)

`/tmp` does not survive between sessions (or even between calls), and re-deriving the chain costs ~65 s each
time, so the reference input lives here instead.

* `weave-in-chainA.js` — the pre-weave payload, 2,535,176 B, sha256 `bf5f21163727850c…`
* `weave-out-chainA.js` — the landed (flags-OFF) weave output, for `cmp` regression checks: any flag-off run
  must reproduce it byte for byte.

Rebuild the same bytes any time:

```bash
ALL='fﾎﾽﾜｸ744,prairieѧ떚뾃728,bloom398,maシワザ911,Vi떚톚780,P磆airie悚492,S欞roudқ103,oRbit824,m濎Ssё虣虣1073,cInde826,cAirn6045,ON333,BI713,PLasmaь386'
EXTRACT_ONLY="$ALL" DEEPWEAVE=1 SPLIT_EXTRA=1 SPLIT_OBJECTS=1 SPLIT_ARRAYS_I=1 OUT=/tmp/deep/landA \
  bash Active/O8.15/tools/cc34-build.sh carrier
cp /tmp/cc34-weave-in.js Active/O8.15/pinned/weave-in-chainA.js
```

Then measure with the seed the build uses: `--seed=2648369387`.
