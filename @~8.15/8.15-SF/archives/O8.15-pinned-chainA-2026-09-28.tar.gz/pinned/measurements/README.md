# Measurement workspace

Derived candidates and maps are intentionally not retained here because they are reproducible and can push the
workspace over the snapshot limit. The canonical chain-A input/output remain in `../weave-in-chainA.js` and
`../weave-out-chainA.js`. Re-run the best-stack measurement with the documented flags in `../pinned/README.md`.
The accepted latest result is recorded in the deep-weave report and `reports/weave-levers-2026-09-27.json`:
45/73 windows above target at the best window-count chunk sweep, or 46/73 at the best mean-share setting.
