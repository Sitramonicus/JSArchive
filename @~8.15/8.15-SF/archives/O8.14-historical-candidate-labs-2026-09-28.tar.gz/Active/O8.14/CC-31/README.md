# CC-31 — pairwise + candidate compile (old 23+24)

**Status:** candidate-only; compilation **PASS**. **Not live.** CC-32 is operator go-live only.

Indexes CC-01…CC-14, CC-16-18, CC-29, CC-30. Current runtime profile is a **copy** of the CC-30 bundle (S1 26/9/102). No profile selected for promotion. CAR-M is **not** merged with R2-10 as one stego blob. O8.13-r3 untouched.

Museum: CC-13 exclusive-n2 profiles stay; CC-18 sequential envelope is what the current worker uses.
