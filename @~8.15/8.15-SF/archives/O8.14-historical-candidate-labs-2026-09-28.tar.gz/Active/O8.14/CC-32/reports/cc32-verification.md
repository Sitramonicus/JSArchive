# CC-32 verification

- Recoverer mix 283997716 → `Mishap`. Runtime `_anteMix` 283997716.
- 25/25 ALL PASS (S8 included).
- `Working-Stable/O8.14` SHA256SUMS OK. `Working-Stable/O8.13` frozen.
- Archives rolling copy: `Archives/packages/O8.14/`.
- Not paste-tested. No O8.14 cover/runner → 43/0 and 16/16 OTO not run.
- PLAN-H 12→18 full cut **not** done (2 pieces of `e` only; `m`/`aux` unsplit).
