# CC-32 live pack

- Stego 42/0 (skip debug-name). Cover `24b6826a`, runner `8963dc92`.
- Seed hex gone from CC-32 shards. CAR-M expanded 2-bit `embed2`. PLAN-H `e-str`+`m-str`. FaC-34 `r2.parseBrowser` off.
- Paste: `Working-Stable/O8.14/O8.14-runner-8963dc92.js`
