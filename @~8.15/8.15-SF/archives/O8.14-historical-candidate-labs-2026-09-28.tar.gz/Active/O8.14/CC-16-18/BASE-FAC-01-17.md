# Base = FaC-01 … FaC-17 (not “CC-09 only”)

CC-09 is the **latest stitched worker** that already contains most of FaC-01–10 and 16–17.  
FaC-11–15 exist as **other trees**. This file is the inventory so the base is the **FaCs**, not the CC number.

| FaC | Where it lives today | In CC-16-18 worker stitch? |
|---|---|---|
| 01 pipeline labels | CC-02+03 / CC-09 `shard-e` (partial; remainder FaC-26) | yes, partial |
| 02 evaluator census | CC-01-B0 tools + FaC-19 census in this tree | tools + this tree |
| 03 host census | CC-01-B0 | tools (not extra shard bytes) |
| 04 branch matrix | CC-01-B0 | tools |
| 05 globals | CC-02+03 / CC-09 | yes |
| 06 cleanup | CC-02+03 / CC-09 | yes |
| 07 messages | CC-02+03 / CC-09 | yes |
| 08 R2-08 H | CC-09 `shard-h.js` | yes (adapter only) |
| 09 VM-S | CC-04 / CC-05 / CC-09 `shard-e` | yes (arithmetic VM) |
| 10 parser | CC-05 / CC-09 `shard-e` | yes |
| 11 CSS sticker | CC-06 / CC-13 profile | **no** — superseded by CC-18 `shard-l` |
| 12 XML sticker | CC-07 / CC-13 | **no** — superseded by CC-18 |
| 13 GLSL sticker | CC-08 / CC-13 | **no** — superseded by CC-18 |
| 14 CAR-M | CC-10 lab only | **no stitch** — keep `Active/O8.14/CC-10-CAR-M/` as base lab |
| 15 R2-10 | CC-11 + CC-12 lab | **no stitch** — keep those dirs as base lab |
| 16 provenance | every CC report | yes (`reports/`) |
| 17 live-host | CC-02+03 / CC-09 | yes |

**Rule:** base = all of FaC-01–17 **as implemented**. Worker bytes come from the CC-09 line. Labs 14–15 stay beside the worker. Stickers 11–13 are replaced by raised CC-18, not stacked as a fourth n2 hat.
