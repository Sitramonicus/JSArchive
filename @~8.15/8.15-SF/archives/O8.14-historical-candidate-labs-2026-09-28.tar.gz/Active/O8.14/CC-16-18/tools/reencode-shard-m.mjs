import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
import { decodeAt, decodeDsAt, encodeString, encodeDs, rotFor } from './string-codec.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const file = process.argv[2];
const newMix = Number(process.argv[3] ?? 13);
const oldMix = Number(process.argv[4] ?? 0);
const oldXk = 113;
const newXk = 113 ^ (newMix & 0xff);
if (!file) throw new Error('usage: reencode-shard-m.mjs <shard-m.js> <newMix>');

let src = fs.readFileSync(file, 'utf8');
function extractCall(name) {
  const re = new RegExp(`const ${name} = (\\(s => \\{ const t = new Uint16Array[\\s\\S]*?\\}\\)\\()([\\s\\S]*?)\\);`);
  const m = src.match(re);
  if (!m) throw new Error('no ' + name);
  return { table: vm.runInNewContext(m[1] + m[2] + ')'), full: m[0], prefix: m[1] };
}
const ciMatch = src.match(/const _0xci = (\[[\s\S]*?\]);/);
const ci = vm.runInNewContext(ciMatch[1]);
const pbEx = extractCall('_0xpb');
const mbEx = extractCall('_0xmb');
const oldRot = rotFor(oldMix);
const newRot = rotFor(newMix);

const packed = [];
const newCi = [];
let cursor = 0;
for (const row of ci) {
  const nrow = [];
  for (const o of row) {
    const s = decodeAt(pbEx.table, o, oldRot);
    const enc = encodeString(s, newRot);
    nrow.push(cursor);
    packed.push(...enc);
    cursor += enc.length;
  }
  newCi.push(nrow);
}

function walkDs(t, xk) {
  const out = [];
  let o = 0;
  while (o + 2 <= t.length) {
    const n = (t[o] - 0x21) * 94 + (t[o + 1] - 0x21);
    if (n < 0 || o + 2 + n > t.length) break;
    out.push(decodeDsAt(t, o, xk));
    o += 2 + n;
  }
  return out;
}
const dsPlain = walkDs(mbEx.table, oldXk);
const dsPacked = [];
for (const s of dsPlain) dsPacked.push(...encodeDs(s, newXk));

src = src.replace(/const _0xci = \[[\s\S]*?\];/, 'const _0xci = ' + JSON.stringify(newCi) + ';');
src = src.replace(pbEx.full, 'const _0xpb = Uint16Array.from(' + JSON.stringify(packed) + ');');
src = src.replace(mbEx.full, 'const _0xmb = Uint16Array.from(' + JSON.stringify(dsPacked) + ');');

src = src.replace(
  /const _0xwd = o => \{ const t = _0xpb; const n = \(t\[o\] - 0x21\) \* 94 \+ \(t\[o \+ 1\] - 0x21\); let r = ""; for \(let j = 0; j < n; j\+\+\) \{ const c = t\[o \+ 2 \+ j\]; r \+= String\.fromCharCode\(c < 0x80 \? 0x20 \+ \(\(\(c - 0x20 - 47\) % 0x5F\) \+ 0x5F\) % 0x5F : c\); \} return r; \};/,
  `const _0xwd = o => { const t = _0xpb; const mix = (Number(_0xmod._anteMix) >>> 0) || 0; const rot = 47 + (mix % 94); const n = (t[o] - 0x21) * 94 + (t[o + 1] - 0x21); let r = ""; for (let j = 0; j < n; j++) { const c = t[o + 2 + j]; r += String.fromCharCode(c < 0x80 ? 0x20 + (((c - 0x20 - rot) % 0x5F) + 0x5F) % 0x5F : c); } return r; };`
);
src = src.replace(
  /const _0xds = o => \{ const t = _0xmb; const n = \(t\[o\] - 0x21\) \* 94 \+ \(t\[o \+ 1\] - 0x21\); let r = ""; for \(let j = 0; j < n; j\+\+\) r \+= String\.fromCharCode\(t\[o \+ 2 \+ j\] \^ 113\); return r; \};/,
  `const _0xds = o => { const t = _0xmb; const mix = (Number(_0xmod._anteMix) >>> 0) || 0; const xk = 113 ^ (mix & 0xff); const n = (t[o] - 0x21) * 94 + (t[o + 1] - 0x21); let r = ""; for (let j = 0; j < n; j++) r += String.fromCharCode(t[o + 2 + j] ^ xk); return r; };`
);

fs.writeFileSync(file, src);
console.log(JSON.stringify({ file, newMix, newRot, newXk, pbBytes: packed.length, dsBytes: dsPacked.length, dsCount: dsPlain.length }));
