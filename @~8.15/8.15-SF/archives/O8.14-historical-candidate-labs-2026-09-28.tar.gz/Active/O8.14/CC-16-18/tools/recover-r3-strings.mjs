// FaC-18 gate fixture: recover shard-m _0xwd/_0xds tables.
// mix=0, xk=113 is the r3 / pre-ante formula. Must PASS on O8.13 and FAIL on keyed CC-16.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
import { decodeAt, decodeDsAt, rotFor } from './string-codec.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..', '..', '..');
const file = process.argv[2] || path.join(ROOT, 'Active/O8.13/shards/shard-m.js');
const mix = Number(process.argv[3] ?? 0);
const xk = process.argv[4] != null ? Number(process.argv[4]) : (113 ^ (mix & 0xff));
const src = fs.readFileSync(file, 'utf8');

function extractCall(name) {
  const arr = src.match(new RegExp('const ' + name + ' = Uint16Array\\.from\\((\\[[\\s\\S]*?\\])\\);'));
  if (arr) return Uint16Array.from(vm.runInNewContext(arr[1]));
  const re = new RegExp(`const ${name} = (\\(s => \\{ const t = new Uint16Array[\\s\\S]*?\\}\\)\\()([\\s\\S]*?)\\);`);
  const m = src.match(re);
  if (!m) throw new Error('no ' + name);
  return vm.runInNewContext(m[1] + m[2] + ')');
}

const ciMatch = src.match(/const _0xci = (\[[\s\S]*?\]);/);
if (!ciMatch) throw new Error('no _0xci');
const ci = vm.runInNewContext(ciMatch[1]);
const pb = extractCall('_0xpb');
const mb = extractCall('_0xmb');
const rot = rotFor(mix);
const strings = [];
for (const row of ci) {
  for (const o of row) strings.push(decodeAt(pb, o, rot));
}
const printable = strings.filter((s) => /^[\x20-\x7e\u0080-\uFFFF]*$/.test(s) && /[A-Za-z]/.test(s));
const report = {
  file: path.relative(ROOT, file),
  mix,
  rot,
  xk,
  offsets: strings.length,
  printableAlpha: printable.length,
  sample: printable.slice(0, 24),
  dsProbe: decodeDsAt(mb, 0, xk),
};
const out = path.join(HERE, '..', 'reports', 'recover-' + path.basename(file) + '.json');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, JSON.stringify(report, null, 2));
console.log(JSON.stringify({ file: report.file, offsets: report.offsets, printableAlpha: report.printableAlpha, sample0: report.sample[0], dsProbe: report.dsProbe }, null, 2));
