// Shared _0xwd / _0xds codec for FaC-18. Mix 0 === r3 formula.
export function rotFor(mix) {
  return 47 + ((Number(mix) >>> 0) % 94);
}

export function decodePbChar(c, rot) {
  if (c >= 0x80) return c;
  return 0x20 + (((c - 0x20 - rot) % 0x5f) + 0x5f) % 0x5f;
}

export function encodePbChar(p, rot) {
  if (p >= 0x80) return p;
  const body = ((p - 0x20 + rot) % 0x5f + 0x5f) % 0x5f;
  return 0x20 + body;
}

export function decodeAt(t, o, rot) {
  const n = (t[o] - 0x21) * 94 + (t[o + 1] - 0x21);
  let r = '';
  for (let j = 0; j < n; j++) r += String.fromCharCode(decodePbChar(t[o + 2 + j], rot));
  return r;
}

export function encodeString(s, rot) {
  const n = s.length;
  if (n >= 94 * 94) throw new Error('too long');
  const out = [0x21 + Math.floor(n / 94), 0x21 + (n % 94)];
  for (let i = 0; i < n; i++) out.push(encodePbChar(s.charCodeAt(i), rot));
  return out;
}

export function decodeDsAt(t, o, xk) {
  const n = (t[o] - 0x21) * 94 + (t[o + 1] - 0x21);
  let r = '';
  for (let j = 0; j < n; j++) r += String.fromCharCode(t[o + 2 + j] ^ xk);
  return r;
}

export function encodeDs(s, xk) {
  const n = s.length;
  const out = [0x21 + Math.floor(n / 94), 0x21 + (n % 94)];
  for (let i = 0; i < n; i++) out.push(s.charCodeAt(i) ^ xk);
  return out;
}
