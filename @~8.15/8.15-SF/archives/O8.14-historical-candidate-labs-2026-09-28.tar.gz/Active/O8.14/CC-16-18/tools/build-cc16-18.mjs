import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..', '..', '..');
const target = path.join(ROOT, 'Active/O8.14/CC-16-18');
const shards = path.join(target, 'source/shards');
const tags = ['a', 'l', 'm', 'n1', 'h', 'e', 'n2', 'aux', 'u', 'p-telegram', 'p-teams', 'p-zoom', 'p-slack', 'p-discord'];
const files = tags.map((t) => path.join(shards, `shard-${t}.js`));
for (const f of files) if (!fs.existsSync(f)) throw new Error('missing ' + f);
const out = path.join(target, 'candidate', 'cc16-18-raw-bundle.js');
execFileSync('python3', [path.join(ROOT, 'Active/O8.13/tools/stitch-o85.py'), ...files, out], { stdio: 'inherit' });
execFileSync('node', ['--check', out], { stdio: 'inherit' });
for (const f of files) execFileSync('node', ['--check', f], { stdio: 'inherit' });
const buf = fs.readFileSync(out);
const report = {
  line: 'CC-16-18',
  base: 'CC-09-R2-08 (old CCs 01–09 composed; 06–08 n2 stickers retained until CC-18 envelope in shard-l supersedes them as the mix source)',
  faCs: ['16', '17', '18', '19', '20', '22', '23', '24', '25', '28', '35'],
  mix: 'FNV(851b28e5) XOR shares via VM in shard-l; bulk tables keyed by refined mix',
  stitchOrder: tags,
  bundleBytes: buf.length,
  bundleSha256: crypto.createHash('sha256').update(buf).digest('hex'),
  liveEligible: false,
  frozenO813Untouched: true,
};
fs.writeFileSync(path.join(target, 'reports', 'build.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
