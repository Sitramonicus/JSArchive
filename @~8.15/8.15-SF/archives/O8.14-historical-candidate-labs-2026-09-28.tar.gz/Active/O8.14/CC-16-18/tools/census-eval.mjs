import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const dir = process.argv[2] || path.join(HERE, '..', 'source', 'shards');
const hits = [];
for (const name of fs.readdirSync(dir).filter((f) => f.endsWith('.js'))) {
  const text = fs.readFileSync(path.join(dir, name), 'utf8');
  const lines = text.split('\n');
  lines.forEach((line, i) => {
    if (/\beval\b/.test(line) || /new\s+Function\b|\bFunction\s*\(/.test(line) || /Function\.prototype/.test(line)) {
      let kind = 'unknown';
      if (/Function\.prototype/.test(line)) kind = 'anti-harness';
      else if (/\beval\b/.test(line)) kind = 'eval-call';
      else if (/new\s+Function|\bFunction\s*\(/.test(line)) kind = 'function-ctor';
      hits.push({ file: name, line: i + 1, kind, text: line.trim().slice(0, 160) });
    }
  });
}
const decisions = hits.map((h) => {
  let decision = 'keep';
  let reason = '';
  if (h.kind === 'anti-harness') {
    decision = 'keep';
    reason = 'Function.prototype.toString native check; not an evaluator';
  } else if (h.kind === 'eval-call' && /runtime unpacked hook/.test(h.text)) {
    decision = 'keep-honey';
    reason = 'masked RC4 trap; byte compare vs 0xdeadbeef does not fire; eval token is the grep magnet on purpose (FaC-19 decoy policy)';
  } else {
    decision = 'unclassified';
    reason = 'needs review';
  }
  return { ...h, decision, reason };
});
const report = {
  policy: 'census-then-keep-or-mask; do not delete required or honey eval without replacement',
  unclassified: decisions.filter((d) => d.decision === 'unclassified').length,
  hits: decisions,
};
const out = path.join(HERE, '..', 'reports', 'fac-19-census.json');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, JSON.stringify(report, null, 2));
console.log(JSON.stringify({ hits: decisions.length, unclassified: report.unclassified, decisions: decisions.map((d) => [d.file, d.line, d.kind, d.decision]) }, null, 2));
if (report.unclassified) process.exit(1);
