# CC-16 + CC-17 scaffold + CC-18 — composed ante candidate

**Status:** candidate-only; not live-eligible  
**Base:** old CCs applied by copying **CC-09** (01–05 + 08 adapters). CC-06/07/08 n2 stickers remain in `shard-n2.js` as leftover museum bytes; the **mix** now comes from **shard-l** (CC-18).  
**Rule:** newer work may overwrite older pieces. This tree does that for the string formula.

## What landed

| CC | What |
|---|---|
| 16 | `shard-m` tables re-encoded with mix **13**. `_0xwd` / `_0xds` read `_0xmod._anteMix` at call time. r3 recoverer with mix 0 yields `Zv!un}` not `Mishap`. |
| 17 | **Scaffold only.** VM-S from CC-04/05 is still in `shard-e` (arithmetic). Decode is not yet VM opcodes. |
| 18 | `shard-l.js` stitched **before** `m`: CSS / XML / GLSL-shaped tokenizers XOR to mix 13. No CSSOM, DOMParser, WebGL. |
| 19 | Census: eval honey **kept**; `Function.prototype.toString` **kept**. Zero unclassified. |

Frozen O8.13-r3 was not written.

## Reproduce

```bash
node Active/O8.14/CC-16-18/tools/recover-r3-strings.mjs Active/O8.13/shards/shard-m.js 0
# sample0 Mishap, dsProbe memberCount

node Active/O8.14/CC-16-18/tools/recover-r3-strings.mjs Active/O8.14/CC-16-18/source/shards/shard-m.js 0
# sample0 Zv!un}  (old formula fails)

node Active/O8.14/CC-16-18/tools/recover-r3-strings.mjs Active/O8.14/CC-16-18/source/shards/shard-m.js 13
# sample0 Mishap again

node Active/O8.14/CC-16-18/tools/census-eval.mjs
node Active/O8.14/CC-16-18/tools/build-cc16-18.mjs
```

Not a paste target. No OTO/stego/password run in this pass.
