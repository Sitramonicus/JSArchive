# CC-16-18 + CC-17 remainder + CC-28 (2026-09-20)

- r3 mix 0: `Mishap` / `memberCount`
- candidate mix 0: `i&0%}-` / junk
- candidate refined `283997716`: `Mishap` / `memberCount`
- runtime shard-l `_anteMix === 283997716`
- no plaintext `--x:` / `<n>` / `const int _k` in shard-l
- FaC-19: 4 hits, 0 unclassified
- stitch syntax PASS; bundle sha256 `0d1caf84079f6512ec11c1792ce1bd04fab7ab9a9e177d34d28a20524405bb6a`
- not live; 25/25 and 43/0 not run
