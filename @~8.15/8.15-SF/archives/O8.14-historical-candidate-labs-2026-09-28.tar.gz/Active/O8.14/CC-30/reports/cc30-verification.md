# CC-30 verification

- Pre-29 + CC-29 lineage: chore-stress 25/25 on CC-29, then same battery on CC-30 after stitch.
- Worker four-way / CAR-M 4-bit unit round-trip PASS. 2-bit same-cover reject PASS.
- ESM lab: r2-10a encode/decode, r2-10b envelope + allowlist loader, carm `frameSymbols` 2-bit 3483528 (no fit) / 4-bit 1741764 (fits).
- chore-stress 25/25 ALL PASS including S8. Bundle sha `46ebd55d…`.
- 43/0 full stego pack: not run (no new cover mint).
- O8.13-r3 untouched.
