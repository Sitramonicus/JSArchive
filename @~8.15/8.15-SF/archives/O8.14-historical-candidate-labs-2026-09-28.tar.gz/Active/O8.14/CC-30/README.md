# CC-30 — carrier pack (FaC-30 four-way + FaC-31 CAR-M 4-bit)

**Base:** CC-29 mix-locked worker. **Status:** candidate. **25/25 ALL PASS.** Not live.

Four-way (`R9R0..R9R3`) lives in `shard-c` + ESM copies under `source/carrier/`. Loader is injected-sender only (CC-12 copy). CAR-M **4-bit** embeds; naive same-cover **2-bit** still over capacity (3,483,528 vs 2,260,322). Not combined into one blob.

No `fetch`, no new host route, no `WebAssembly.instantiate` on the normal path.
