# Build 25 — the complete 8.15 build (normaliser + split + weave + constraint pass), gated

**Date:** 2026-09-26 · **Line:** O8.15 / CC-34 · **Status:** complete, all gates green, **live test PASSED 2026-09-26** (pass 1 quiet → refresh → pass 2: chain `armed`, work running, ledger read out). Review + the pass-1 root cause: `LIVETEST-REVIEW-2026-09-26.md`.

Inputs: the frozen 8.14 bundle `Working-Stable/O8.14/O8.14-bundle-820f06c2.js` and the clean cover.
Nothing in `Working-Stable/O8.14/`, `Archives/packages/O8.14/` or `Archives/rollback-b22/` was written, and
`Active/Stego/` (the frozen toolchain) is untouched.

Records: this file · `board-b25.log` (one line per gate) · `build-b25.log` (the build's own stage log) ·
`repaste-b25.log` · `build-b25-repro.log` (the second, independent build).

---

## 1. In one page (plain language)

The payload is one 2.1 MB block of code. Two things made it cheap for a reader:

1. **It carried its own map.** The runner published a ~98 KB table of chunk indices — the payload's original
   order, in the clear, next to the artifact. **Arm A** (already in b24) deleted it: the loader rebuilds the
   table from the seed it already has, and the build fails if the rebuild disagrees with the cover.
2. **It was stored in large unbroken slabs, in the order it was written.** Even without the map, consecutive
   bytes were consecutive in the file: a function's statements sat end to end, and big literal arrays sat
   end to end next to them.

This build attacks the second problem, in four stages, all of them order-only:

| stage | what it does | why it follows the idea |
|---|---|---|
| **normalise** | masks the last readable vocabulary in the payload: our own residue identifiers, the mound layer's `IS_SYMBOL_NATIVE`, and the venue's `dispatch` read (built at runtime as `["\x64ispatch"]`) | a reader uses words as landmarks; after this, the names are opaque derivations and the venue key exists only once the code runs |
| **split** | 12 monolithic array statements become `declaration + one push per ~4 KB run` | one 90 KB landmark becomes ~90 movable small statements; not one literal changes and the written order is preserved |
| **weave** | inside every function body the movable statements — **1,741 hoisted function declarations** and the **96 split runs** (12 groups) — are dealt through the body by seed, keeping every declaration's text byte-identical and every run group in order | a reader who lays the file out sees *which* code is there but no longer *where it came from*: **58.2 % of the file's bytes now sit somewhere else** than they did |
| **constraint pass** | an independent re-derivation of the movable set on the woven bytes, asserting the five ways a move could be *observed* (same-name declarations, run-window privacy, order-observable calls, shared-root writes, and per-binding push order vs the pre-weave file) | "safe by analysis, not by luck": the pass is a gate, red refuses the build |

Cost and effect, measured on the shipped bytes:

| | before (8.14) | after (b25) |
|---|---:|---:|
| payload, raw | 2,384,572 B | 2,388,103 B (**+3,531 B**, +0.15 %) |
| payload, gzip | 994,234 B | **981,959 B** (−12,275 B) |
| payload, brotli-q11 | 773,363 B | **770,159 B** (−3,204 B) |
| carrier occupancy / headroom per reel | 88.63 / 88.64 % · ~63.6 KB | **87.69 / 87.70 % · 68,909 / 68,841 B** |
| longest stretch of one origin's bytes laid end to end | 163,121 B | **99,932 B** |
| worst 10 %-wide window, largest single-origin share (B13 target ≤ 0.25) | 0.776 | **0.501** |
| paste (runner) | 3,375,606 B | **3,278,667 B** (−96,939 B, arm A) |

The carrier carries the **gzip** stream, so the weave pays for itself: the reel ends up *less* full than
8.14's despite the extra content. That is also why the size objection to D6 (per-instance vocabulary,
+25–35 KB compressed) no longer holds — see `DECISIONS.md`.

**What a reader gets now:** no order map in the artifact, no vocabulary landmarks, and no contiguous slab
larger than a single function body (~92 KB, the largest statement) — where "a single function body" is a
statement that cannot be split without changing what executes when, which is the next lever (§5).

## 2. Digests (this build)

| artifact | bytes | sha256 (first 16) |
|---|---:|---|
| paste (runner) `O8.15-CC-34-runner-802c4763.js` | 3,278,667 | `802c4763011e9291` |
| cover (carrier) `O8.15-CC-34-cover-c6738275.bmp` | 2,359,350 | `c6738275b8a8ea08` |
| payload `stego11p-real.min.js` | 2,388,103 | `60316654b349ae6d` |
| decoy / honey / tube | 3,112 / 1,230 / 2,242 | `55895e58…` / `88397e56…` / `ed0db1cd…` (**unchanged from 8.14**) |
| rotation | 703 | `f9f5c4c1…` (unchanged) |
| input bundle (frozen 8.14, read-only) | 2,764,116 | `820f06c2…` |

Kept in the workspace: `Active/O8.15/CC-34/final-package/` — runner, cover, `SHA256SUMS.txt`. Everything
else in the build regenerates in ~35 s from the frozen bundle, which is why only the two files the live
test needs are kept (§8).

**Reproducible:** three independent builds (b25, b25b, b25c — the last one with the constraint stage
enabled) produced byte-identical runner, cover, payload and decoys.

```bash
OUT=/tmp/b25 bash Active/O8.15/tools/cc34-build.sh carrier   # write a build (≈35 s)
OUT=/tmp/b25 bash Active/O8.15/tools/cc34-build.sh verify    # identity gates only
BUILD=/tmp/b25 bash Active/O8.15/tools/board-815.sh b25      # the full pre-paste board (≈6 min)
```

## 3. The pipeline, stage by stage (from `build-b25.log`)

| stage | stage id | result |
|---|---|---|
| minify (terser, real) + error-path dangle repair | — | 2,101,166 chars |
| **normaliser** | `[2a-bis2]` | 2,101,166 → 2,101,159 (**−7**), **6 mask edits** `{ident:4, dispatch:2}`, 6 self-checks PASS |
| **split** | `[2a-ter]` | +1,437 chars → 2,102,596; **12 candidates, 0 skipped**; literal sequence identical (77,294 literals, same order) |
| **weave** | `[2a-quater]` | +1,859 chars → 2,104,455; seed `2648369387` (`SEEDINT('cc34-weave')`); 4 self-gates PASS |
| **constraint pass** | `[2a-quinquies]` | **5/5 checks green**; a red refuses the build |
| G8 repin + noise append + carrier/arm A + staged-vs-shipped | `[2b]` | staged payload == shipped payload (`cmp`), byte-identical |

**The masks (D2 + D5).** Before → after, each verified to leave runtime behaviour identical and the payload
re-parsing:

| written form | occurrences | after |
|---|---:|---|
| `_0xpocketsMissing` | 1 | `_0x5c91a7d2` |
| `pocketsMissing` (bare) | 1 | `_0x9f2c41b8` |
| `IS_SYMBOL_NATIVE` | 2 | `_0x41d8e6b3` |
| `.dispatch` property read | 2 | `["\x64ispatch"]` — the key only exists at run time |

Measured on the shipped payload: `_0xpocketsMissing` 0 · `pocketsMissing` 0 · `IS_SYMBOL_NATIVE` 0 ·
`dispatch` 2 (down from 4; the survivors are the mock-API *call* and the noise strings, both classified
deliberate). **`leakcensus` verdict flips FAIL → PASS** (G3 unexplained 0; G1 registry exports
`[lexProbeA, lexProbeX, lexProbeU]`, all loader-contract; the G6 foldable list is informational).

**The weave's four self-gates** (all PASS on the shipped payload): output re-parses · every body keeps its
statement count · the same statements are present (permutation only) · **fixed statements keep their
relative order and every run group keeps its order.** The last one is the gate that refused the first b25
attempt: a within-gap shuffle could invert two runs of one group. The shuffle is now group-aware (groups are
ordered against each other, never within themselves) and the check itself was not relaxed.

**The constraint pass (step 4)** — independent code path, own shape detection, runs on the woven bytes with
`--pre` pointing at the pre-weave file:

| check | result |
|---|---|
| C1 — no declaration name can be reordered by the arrangement | PASS (3,765 function bodies scanned, 0 duplicated names) |
| C2 — no executing statement inside a run; nothing order-bearing trails it | PASS (12 run groups / 108 push statements · 0 executing inside · 0 trailing · 2 *transparent* declarations dealt inside a run, which is what the weave does and cannot observe) |
| C3 — no movable statement calls an order-observable API (21 names: timers, listeners, observers, promise continuations) | PASS (0 hits) |
| C4 — a run writes only through its own binding | PASS (0 shape violations) |
| C5 — every binding is built by the same pushes in the same order, pre vs post | PASS (27 bindings compared, 0 mismatched) |
| movable set | 1,934 statements = 1,231,133 B = 58.5 % of the file — **unchanged by the pass** |

Negative control: two pushes of one binding were deliberately swapped in the woven bytes — C5 fails as
designed (`mismatched: 1`), so the gate is not a rubber stamp.

## 4. Battery on the built bytes

Board log `board-b25.log` (`FAIL lines: 1` = the intended T2 fail-closed under `--debug-name=ripcord`: a
pasted debug name is a decoder tell and *must* fail).

| gate | 8.14 baseline | b25 | verdict |
|---|---|---|---|
| `gate-replay --spec` | 17/17 | **17/17** | same |
| gate matrix (real loader, t=5 / post-window) | unlocks 2/2 · verbs rejected 3/3 · teardown 5/5 | **unlocks 2/2 · verbs rejected 3/3 · teardown 5/5** | same |
| `test-stego11-matrix` (8.15 copy) | 25/0 → 26/0 (+1 new FRAG row) | **26/0** | same +1 documented |
| `test-stego11-tiers` | 42/0 (1 skipped) | **42/0 (1 skipped)** | same |
| `tiers --debug-name=ripcord` | exactly 1 failure (T2) | **exactly 1 failure (T2)** | same |
| `hold-check` | PASS (9/9) | **PASS (9/9)** | same |
| `carrier-flip-check` | 14/0 | **14/0** | same |
| `detector-replay` | PASS | **PASS** | same |
| `netwatch` bundle + payload | 0 calls / no URLs | **0 calls / no URLs** | same |
| `dangling-refs` payload / runner / bundle | 61/**0** · clean · 36/**0** | **61/0 · clean · 36/0** | same |
| `decoy-parity` k=0,1,2 | PASS ×3 | **PASS ×3** | same |
| golden trace (split-equivalence, 400 rounds) | 25 events | **25 events** | same |
| `chain-revive-check` (shards) | 14/14 | **14/14** (C11 "channel labels survive a table wipe" green) | same |
| `leakcensus` payload | **G3 unexplained = 4** (standing red) | **PASS** (unexplained 0) | **fixed by the normaliser** |
| constraint pass payload | — (new) | **PASS 5/5** | new gate |
| `repaste-check` | 5/5 | **5/5** — entry published, survived the stand-down, one garden, garden printed once at the window (16 generations, same signature as 8.14) | same |
| `frag-derive-check` | no published deal; snapshot == cover | **MATCH** (`c6738275…`) | arm A intact |
| `runner-wire-probe` | staged == payload digest | staged `60316654…` **== the shipped payload file** | end-to-end identity |
| runtime (`fullwire-probe`) | — | 2,104,455 B, **1,243 ms**, logs `CLEAR` + `[Host 8.14] … worker instance 06118ef1`, `GoogleUblock(pwd) → false` | green |

**Seed robustness:** the weave was re-run with seeds 11, 4242 and 999,983 — each re-parses, and each runs
green in `fullwire` with the same log signature (`CLEAR` + the host banner). The shipped seed is the
default `SEEDINT('cc34-weave')`, so the arrangement is reproducible and not a fixed fingerprint.

"No regression" therefore holds in the strict form the operator asked for: every number that was 8.14's is
still 8.14's, and the two count changes are the documented ones (matrix +1 for the new FRAG row; leakcensus
green instead of a known-4 red).

## 5. What the weave cannot do yet (measured, not hidden)

Movable mass: **1,222,969 B = 58.2 %** of the payload. The other 41.8 % is, in size order:

| bytes | what it is | why it is stuck |
|---:|---|---|
| 169,896 | `!function(Cinde826){ … }(…)` — the top-level shard IIFE | a statement expression: it is not hoistable, and moving it moves when it runs |
| 92,246 | `var emb451=function(){ … }` (contains an 88,407 B base64 table) | a `var` bound to a function *expression*: moving the statement moves the binding |
| 85,489 / 78,229 / 70,160 / 69,134 | four more `var X=function(){ … }` table-builders | same |
| remainder | statements that follow a non-hoistable statement inside a run group (their order is fixed by it), plus the prologue/epilogue | no proof yet |

The metric consequence is honest and simple: **the floor is one statement.** A function body is one
contiguous span of original text; the weave reorders spans, it does not split them, so the longest
single-origin run after the weave (99,932 B) is bounded below by the largest function body (~92 KB). Two
levers exist and are recorded, not guessed:

- **B27 — level 2: shuffle statements *inside* bodies** (not just hoisted declarations), which is exactly
  what §1.5's property-aware constraints in the roadmap were written for. The constraint pass that now
  exists is the safety harness for it.
- **B23 — extend the split** to the held classes (strings, objects), which shrinks the interior of the big
  table-builders above.

Neither is needed for the live test; both are the next measurable step, with numbers to beat
(99,932 B run / 0.501 window share vs the 0.25 target).

## 6. The 8.15 tools (all under `Active/O8.15/`)

| file | role |
|---|---|
| `tools/normalise-payload.mjs` | stage `[2a-bis2]`; mask table in §3; refuses to write if any self-check fails |
| `tools/split-runs.mjs` | stage `[2a-ter]`; order-preserving array split + literal-sequence gate |
| `tools/weave-payload.mjs` | stage `[2a-quater]`; `--measure` / `--apply`, `--seed=N`, `WEAVE_DEBUG=1|2`, four self-gates, refuses to write on red |
| `tools/constraint-pass.mjs` | stage `[2a-quinquies]`; C1–C5, exit 1 on red; `--pre=` enables the order comparison |
| `tools/cc34-build.sh` | the build: normalise → split → weave → constraint → carrier → identity gates |
| `tools/board-815.sh` | the full pre-paste board against a built directory (`BUILD=<dir> LABEL`) |
| `carrier/build-stego13-r2.mjs` | stage order wired; switches `NORMALISE=0`, `SPLIT_MIN`/`SPLIT_RUN`, `WEAVE=0`, `WEAVE_SEED`, `CONSTRAINT=0` |
| `carrier/test-stego11-matrix.mjs` · `test-stego11-tiers.mjs` | the two runner tests, frag-shape aware |

## 7. Known-benign log noise (so nobody re-chases it)

- `[WARN] gzReal 981959 != 743751 (r3)` and the `gzHoney`/`gzTube` variants: inherited stale expectation
  constants. They are re-pinned only when a build is deliberately re-baselined; the gate that matters
  (`staged payload == shipped payload`) is green.
- `[SPLIT] minReal 2102596 chars after the split (-278852)`: the builder's own delta line compares against a
  stale reference. The splitter's numbers (+1,437 chars, sequence gate PASS) and the final file are
  authoritative — same as b24, not re-chased.
- Two residual `dispatch` hits and the G6 foldable list (`GoogleUblock`, `GoogleVault`, `webpackChunk*`, …)
  are deliberate and load-bearing; the census classifies them, it does not ignore them.

## 8. Snapshot budget

The workspace tracks ~123.5 MB against a ~128 MB snapshot cap, so this report is the record and only the two
files the live test needs are kept (`final-package/`). Everything else — the payload set, rotation, the
runner — regenerates from the frozen bundle by command; the digests in §2 are what to compare against.

## 9. Owed

1. **The operator's live paste** of `O8.15-CC-34-runner-802c4763.js` with
   `O8.15-CC-34-cover-c6738275.bmp` — the only row that cannot be run here.
2. After a clean live pass: promote build 25 (it becomes the 8.15 record) and decide on the next levers
   (B27 level-2 weave, B23 held split classes). The D-ledger is closed: `Active/O8.15/DECISIONS.md`.
